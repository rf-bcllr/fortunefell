/* P1 scene integration repair.
 * Insert inside the game's existing IIFE, after character_expansion and before
 * its closing `})();`. Do not put this in a separate script/global scope.
 * The original stampDeco assignment ran before Art.load's installFinalArt(),
 * whose base implementation replaces stampDeco. Install this hook afterwards.
 * Coordinates below intentionally use WORLD PIXELS, not tile coordinates.
 */
const installBeforeP1ScenePlacement = installFinalArt;
installFinalArt = function () {
  installBeforeP1ScenePlacement();
  const stampBeforeP1ScenePlacement = stampDeco;
  stampDeco = function (x, decor, theme, map) {
    if (decor.kind === 'regionalHouse' && (map?.id === 'gh' || map?.id === 'eh')) {
      const image = Art.get(decor.art);
      if (!image) return;
      x.save();
      x.imageSmoothingEnabled = false;
      x.drawImage(image, Math.round(decor.center - image.width / 2), Math.round(decor.ground - image.height));
      x.restore();
      return;
    }
    if (map?.id === 'gm' && decor.kind === 'monument' && decor.x === 6) {
      const image = Art.get('monument_gilead_b');
      if (image) {
        x.save(); x.imageSmoothingEnabled = false;
        x.drawImage(image, Math.round(decor.x * TS + 8 - 35), Math.round(decor.y * TS - 90));
        x.restore(); return;
      }
    }
    if (map?.id === 'workshop' && (decor.kind === 'anvil' || decor.kind === 'weapons')) {
      const image = Art.get('halberd_forge');
      if (image) {
        // Both original decorations belong to one composition; draw it once.
        if (decor.kind === 'anvil') {
          x.save(); x.imageSmoothingEnabled = false;
          x.drawImage(image, 184, 48); x.restore();
        }
        return;
      }
    }
    return stampBeforeP1ScenePlacement(x, decor, theme, map);
  };
  // A fresh load has no map canvases yet. Also permit controlled reinstallation
  // in a development session without reusing a canvas that omitted these props.
  for (const id of ['gh', 'eh', 'workshop', 'gm']) delete _mapCache[id];
};

/* REQUIRED SOURCE EDIT FOR PARALLAX (do not solve with another global override):
 * In loadMap replace background cache-key assignment with:
 *   const bgKey = m.id === 'ga' ? 'gilead_archive' : (m.bgTheme || m.theme);
 * In character_expansion.makeBackground replace ONLY:
 *   key === 'gileadD'
 * with:
 *   key === 'gilead_archive'
 * and make its fallback:
 *   previousBackground(key === 'gilead_archive' ? 'gileadD' : key)
 * Do not set ga.bgTheme: drawWorld suppresses foreground when bgTheme exists.
 * The original gileadD branch stays available to gd, including original PNGs;
 * loadMap caches ga and gd separately. Missing archive image safely falls back.
 */
