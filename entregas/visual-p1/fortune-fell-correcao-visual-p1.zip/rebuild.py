"""Re-export existing source artwork and apply narrowly scoped integration repairs."""
from pathlib import Path
from PIL import Image,ImageEnhance,ImageDraw
import re,json,base64,io,hashlib
R=Path(__file__).parent;S=(R/'fontes') if (R/'fontes').is_dir() else Path('/workspace/fortune-expansion/assets/generated_sources');src=(R/'current.html').read_text();m=re.search(r'const ART_PNG\s*=\s*',src);assets,end=json.JSONDecoder().raw_decode(src[m.end():]);end+=m.end();out=R/'assets-fixed';out.mkdir(exist_ok=True);log={}
def cells(file,top,bottom):
 im=Image.open(S/file).convert('RGBA');result=[]
 for i in range(4):
  c=im.crop((round(i*im.width/4),top,round((i+1)*im.width/4),bottom));c.putalpha(c.getchannel('A').point(lambda v:255 if v>=128 else 0));b=c.getbbox();assert b;result.append(c.crop(b))
 return result

def export(key,cs,target,width=40,cool=False):
 # One scale and one source-derived palette per animation, no frame stretching/dither.
 scale=target/cs[0].height
 toned=[]
 for c in cs:
  if cool:
   c=c.copy();c=ImageEnhance.Color(c).enhance(.88)
   px=list(c.getdata());c.putdata([(round(r*.96),round(g*.97),min(255,round(b*1.025+2)),a) for r,g,b,a in px])
  toned.append(c)
 sample=[]
 for c in toned:
  small=c.resize((max(1,c.width//2),max(1,c.height//2)),Image.Resampling.NEAREST)
  sample.extend(p[:3] for p in small.getdata() if p[3]>=128)
 pool=Image.new('RGB',(len(sample),1));pool.putdata(sample);pal=pool.quantize(colors=40,method=Image.Quantize.MEDIANCUT)
 strip=Image.new('RGBA',(width*4,48));boxes=[]
 for i,c in enumerate(toned):
  w,h=round(c.width*scale),round(c.height*scale);assert w<=width and h<=47,(key,w,h)
  small=c.resize((w,h),Image.Resampling.BOX);q=small.convert('RGB').quantize(palette=pal,dither=Image.Dither.NONE).convert('RGBA');q.putalpha(small.getchannel('A').point(lambda v:255 if v>=128 else 0));strip.alpha_composite(q,(width*i+(width-w)//2,48-h));boxes.append([w,h])
 strip.save(out/f'{key}.png');b=io.BytesIO();strip.save(b,format='PNG');assets[key]='data:image/png;base64,'+base64.b64encode(b.getvalue()).decode();log[key]={'source_dimensions':[c.size for c in cs],'target_visible':boxes,'cell':[width,48],'shared_scale':scale,'palette_limit':40,'method':'BOX area reduction mapped to shared source palette; no dither; binary alpha','cool_light':cool}
for row,name in enumerate(['king','hag','governor','inys','queen']):
 im=Image.open(S/'five_characters_idle_source.png');cs=cells('five_characters_idle_source.png',round(row*im.height/5),round((row+1)*im.height/5));export('exp_'+name+'_idle',cs,28 if name=='inys' else 39)
rows=[0,345,703,1060,Image.open(S/'four_adults_actions_source.png').height]
for row,name in enumerate(['king','hag','governor','queen']):
 if name=='king':
  f='king_weigh_corrected_source.png';cs=cells(f,0,Image.open(S/f).height)
 else:cs=cells('four_adults_actions_source.png',rows[row],rows[row+1])
 export('exp_'+name+'_gesture',cs,39)
b=[0,308,612,941,Image.open(S/'lote04_idle_actions_source.png').height]
for row,name,kind,t in [(0,'artificer','idle',30),(1,'artificer','hammer',30),(2,'oracle','idle',39),(3,'oracle','gesture',39)]:
 export('exp_'+name+'_'+kind,cells('lote04_idle_actions_source.png',b[row],b[row+1]),t,48 if kind=='hammer' else 40,name=='oracle')
# Rebuild only the embedded asset object; all other asset bytes remain untouched.
s=src[:m.end()]+json.dumps(assets,separators=(',',':'),ensure_ascii=False)+src[end:]
def once(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b,1)
once("const bgKey = m.bgTheme || m.theme;", "const bgKey = m.id === 'ga' ? 'gilead_archive' : (m.bgTheme || m.theme);")
once("const sky = key === 'gileadD' && Art.get('bg_gilead_archive_sky');", "const sky = key === 'gilead_archive' && Art.get('bg_gilead_archive_sky');")
once("return sky ? [{c: sky, par: 0, final: true}] : previousBackground(key);", "return sky ? [{c: sky, par: 0, final: true}] : previousBackground(key === 'gilead_archive' ? 'gileadD' : key);")
# Restore approved archivist until a high-resolution source is available.
once("if(name!=='archivist'||!Art.get('archivist_idle_overhaul'))return previous(name,frame);", "if(name==='archivist'||!Art.get('archivist_idle_overhaul'))return previous(name,frame);")
# Remove the whole rejected override instead of leaving an always-bypassed body.
a=s.index('// ---- 99_zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz_archivist_idle.js ----');z=s.index('// ---- ',a+10);s=s[:a]+s[z:]
# Native decoration must not inherit another renderer's smoothing state/filter.
once("x.filter = 'saturate(76%) brightness(78%)';", "x.imageSmoothingEnabled = false;")
patch="const forgeChandelier = LEVELS.workshop.deco.find(d=>d.kind==='chandelier'); if(forgeChandelier) forgeChandelier.x=7;\n"+(R/'scene-fixes.js').read_text();pos=s.rfind('})();</script>');assert pos!=-1;s=s[:pos]+patch+'\n'+s[pos:]
(R/'fortune-fell-corrigido.html').write_text(s)
(R/'reexport-manifest.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n')
# Testing-only hooks; do not include these extra hooks in the deliverable.
pos=s.rfind('})();</script>');qa=s[:pos]+"window.__visualQA=Object.assign({},window.__ff,{npcSprite:(...a)=>npcSprite(...a),portrait:(...a)=>portrait(...a),makeBackground:(...a)=>makeBackground(...a),stampDeco:(...a)=>stampDeco(...a),buildMapCanvas:(...a)=>buildMapCanvas(...a),_bgCache,_mapCache,render,drawWorld,ctx,canvas});\n"+s[pos:];(R/'qa.html').write_text(qa)
js='\n'.join(re.findall(r'<script[^>]*>([\s\S]*?)</script>',s));(R/'check.js').write_text(js)
print('Re-exported',len(log),'sheets; repaired HTML',len(s.encode()),'bytes')
