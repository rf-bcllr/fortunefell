const G={opts:{sound:true},state:'play',map:null};
const Snd = {
  ctx: null, gain: null, song: null, step: 0, next: 0,
  unlock() {
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        this.gain = this.ctx.createGain(); this.gain.connect(this.ctx.destination);
        this.gain.gain.value = G.opts.sound ? .5 : 0;
        this.bus = this.ctx.createGain(); this.bus.gain.value = 1; this.bus.connect(this.gain);
        setInterval(() => this.tickMusic(), 80);
      } catch (e) { this.ctx = null; }
    }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  },
  setOn(v) { G.opts.sound = v; if (this.gain) this.gain.gain.value = v ? .5 : 0; },
  tone(f, d = .1, type = 'square', v = .12, slide = 0, at = 0, bus = null) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + at, o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + d);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.001, t + d);
    o.connect(g); g.connect(bus || this.gain); o.start(t); o.stop(t + d + .02);
  },
  noise(d = .15, v = .15) {
    if (!this.ctx) return;
    const n = Math.floor(this.ctx.sampleRate * d), b = this.ctx.createBuffer(1, n, this.ctx.sampleRate), a = b.getChannelData(0);
    for (let i = 0; i < n; i++) a[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const s = this.ctx.createBufferSource(), g = this.ctx.createGain(); s.buffer = b; g.gain.value = v; s.connect(g); g.connect(this.gain); s.start();
  },
  fx(k) {
    const m = {
      jump: () => this.tone(260, .1, 'square', .05, 200), shoot: () => this.tone(760, .08, 'triangle', .1, -360), gild: () => { this.tone(880, .1, 'triangle', .1); this.tone(1320, .14, 'triangle', .08, 0, .05); },
      gilded: () => [880, 1109, 1320, 1760].forEach((f, i) => this.tone(f, .14, 'triangle', .08, 0, i * .05)), melee: () => this.noise(.07, .1), shatter: () => { this.noise(.18, .2); [1800, 1400, 2200].forEach((f, i) => this.tone(f, .05, 'square', .04, 0, i * .03)); },
      coin: () => this.tone(1400, .05, 'square', .035), hurt: () => { this.tone(200, .22, 'sawtooth', .12, -120); this.noise(.12, .1); }, tink: () => this.tone(2200, .04, 'square', .04),
      tempo: () => this.tone(520, .4, 'sine', .14, -300), perc: () => { this.tone(660, .3, 'sine', .1, 660); this.tone(990, .3, 'sine', .06, 660, .05); }, swap: () => this.tone(620, .06, 'square', .05, 200),
      slam: () => { this.tone(90, .35, 'sawtooth', .22, -50); this.noise(.3, .24); }, check: () => [523, 659, 784].forEach((f, i) => this.tone(f, .16, 'triangle', .09, 0, i * .08)), text: () => this.tone(520, .02, 'square', .012),
      door: () => this.tone(180, .2, 'triangle', .1, 120), ring: () => [392, 523, 659, 784, 1047].forEach((f, i) => this.tone(f, .5, 'triangle', .1, 0, i * .12)), boom: () => { this.tone(60, 1.2, 'sawtooth', .3, -30); this.noise(1, .3); },
    };
    if (m[k]) m[k]();
  },
  songs: {
    // Tudo gerado: escala modal + progressão por região. Sem recriar nenhuma trilha existente.
    myriadd: { base: 220, scale: [0, 2, 4, 7, 9, 12, 14, 16], prog: [0, 3, 5, 2], tempo: 7 }, gilead: { base: 174.6, scale: [0, 2, 3, 7, 8, 12, 14, 15], prog: [0, 2, 4, 1], tempo: 8 },
    iomadh: { base: 196, scale: [0, 2, 4, 5, 7, 9, 11, 12], prog: [0, 4, 5, 3], tempo: 6 }, ehrein: { base: 146.8, scale: [0, 3, 5, 7, 10, 12, 15, 17], prog: [0, 0, 3, 2], tempo: 9 },
    boss: { base: 130.8, scale: [0, 1, 5, 7, 8, 12, 13, 17], prog: [0, 1, 0, 3], tempo: 4, pulse: 1 },
    title: { base: 196, scale: [0, 2, 4, 7, 9, 12, 14, 16], prog: [0, 3, 5, 4], tempo: 9, pad: 1 },
    history: { base: 146.8, scale: [0, 2, 3, 7, 8, 12, 14, 15], prog: [0, 5, 3, 4], tempo: 11, pad: 1, sparse: 1 },
    court: { base: 220, scale: [0, 2, 4, 5, 7, 9, 11, 12], prog: [0, 3, 4, 0], tempo: 8, pad: 1 },
    tension: { base: 110, scale: [0, 1, 3, 6, 7, 10, 12, 13], prog: [0, 0, 1, 0], tempo: 5, pulse: 1, sparse: 1 },
    shadow: { base: 69.3, scale: [0, 1, 6, 7, 12, 13, 18, 19], prog: [0, 1, 0, 2], tempo: 12, drone: 1, sparse: 1 },
    ring: { base: 261.6, scale: [0, 2, 4, 6, 7, 9, 11, 12], prog: [0, 1, 2, 4], tempo: 5, pad: 1 },
    bridge: { base: 293.7, scale: [0, 2, 4, 7, 9, 12, 14, 16], prog: [0, 2, 3, 1], tempo: 4 },
    fall: { base: 98, scale: [0, 2, 3, 5, 7, 8, 10, 12], prog: [0, 5, 3, 1], tempo: 12, pad: 1, drone: 1, sparse: 1 },
  },
  // Troca com fade curto, para a música acompanhar a cena sem cortes secos.
  music(name) {
    if (this.want === name) return;
    this.want = name;
    if (!this.ctx) { this.song = name; this.step = 0; return; }
    const t = this.ctx.currentTime;
    this.bus.gain.cancelScheduledValues(t); this.bus.gain.setValueAtTime(this.bus.gain.value, t); this.bus.gain.linearRampToValueAtTime(0, t + .35);
    clearTimeout(this.swap);
    this.swap = setTimeout(() => { this.song = this.want; this.step = 0; this.next = 0; const n = this.ctx.currentTime; this.bus.gain.cancelScheduledValues(n); this.bus.gain.setValueAtTime(0, n); this.bus.gain.linearRampToValueAtTime(1, n + .7); }, 380);
  },
  tickMusic() {
    if (!this.ctx || !this.song || !G.opts.sound || G.state === 'paused') return;
    const s = this.songs[this.song]; if (!s) return;
    const now = this.ctx.currentTime, dur = s.tempo * .035;
    if (this.next < now) this.next = now + .02;
    while (this.next < now + .2) {
      const st = this.step++, bar = Math.floor(st / 16) % s.prog.length, root = s.prog[bar], at = this.next - now;
      const note = i => s.base * Math.pow(2, s.scale[(i + root) % s.scale.length] / 12);
      const B = this.bus;
      if (st % 8 === 0) this.tone(note(0) / 2, dur * 6, 'triangle', .06, 0, at, B);
      if (st % (s.sparse ? 4 : 2) === 0) this.tone(note([0, 2, 4, 2, 5, 4, 2, 3][(st / 2) % 8 | 0]) * 2, dur * 1.8, 'triangle', .022, 0, at, B);
      if (st % 16 === 12) this.tone(note(5) * 2, dur * 5, 'sine', .028, 0, at, B);
      if (s.pad && st % 16 === 0) for (const i of [0, 2, 4]) this.tone(note(i), dur * 15, 'sine', .018, 0, at, B);
      if (s.pulse && st % 4 === 0) this.tone(s.base / 2, dur * 2, 'sawtooth', .03, -8, at, B);
      if (s.drone && st % 32 === 0) { this.tone(s.base / 2, dur * 32, 'sawtooth', .012, 0, at, B); this.tone(s.base / 2 * 1.012, dur * 32, 'sine', .04, 0, at, B); }
      this.next += dur;
    }
  },
};

const MODES = {
  ionian: [0, 2, 4, 5, 7, 9, 11], lydian: [0, 2, 4, 6, 7, 9, 11], mixo: [0, 2, 4, 5, 7, 9, 10], dorian: [0, 2, 3, 5, 7, 9, 10],
  aeolian: [0, 2, 3, 5, 7, 8, 10], phrygian: [0, 1, 3, 5, 7, 8, 10], harm: [0, 2, 3, 5, 7, 8, 11],
};
const SONGS27 = {
  title: { bpm: 72, root: 50, mode: 'ionian', pad: 'choir', lead: 'brass', harp: 2, bass: 1, drum: 'timp',
    chords: [[1, 2], [4, 2], [6, 2], [5, 2]],
    mel: '1 - - - 5 - - - | 4 - 3 - 2 - 3 - | 5 - - - 8 - - - | 7 - 6 - 5 - - - | 6 - - 7 8 - 9 - | 10 - 9 - 8 - 6 - | 5 - - 4 3 - 2 - | 1 - - - - - - -' },
  myriadd: { bpm: 84, root: 51, mode: 'lydian', pad: 'strings', lead: 'flute', harp: 1, bass: 1,
    chords: [[1, 2], [2, 2], [6, 2], [5, 2]],
    mel: '5 - 8 - 9 - 10 - | 11 - 10 9 8 - 5 - | 6 - 7 - 9 - 8 - | 7 - 5 - - - r r | 5 - 8 - 9 - 10 - | 12 - 11 10 9 - 11 - | 10 - 9 - 8 - 7 - | 8 - - - - - r r' },
  gilead: { bpm: 66, root: 57, mode: 'dorian', pad: 'choir', lead: 'bell', harp: 2, bass: 1,
    chords: [[1, 2], [3, 1], [7, 1], [4, 2], [1, 2]],
    mel: '1 - 3 - 5 - 4 3 | 2 - - - 1 - r r | 3 - 5 - 7 - 8 - | 7 - 6 5 4 - - - | 5 - 4 - 3 - 4 - | 5 - 6 - 7 - 5 - | 4 - 3 - 2 - 0 - | 1 - - - - - r r' },
  iomadh: { bpm: 96, root: 55, mode: 'mixo', pad: 'strings', lead: 'flute', harp: 1, bass: 1, drum: 'frame',
    chords: [[1, 1], [7, 1], [4, 1], [1, 1]],
    mel: '5 6 8 - 7 5 6 - | 5 4 3 - 4 5 r r | 5 6 8 - 9 8 7 - | 8 - 5 - - - r r | 3 4 5 - 7 6 5 - | 4 3 2 - 3 4 r r | 5 - 7 - 8 - 9 - | 8 - - - - - r r' },
  ehrein: { bpm: 76, root: 52, mode: 'phrygian', pad: 'strings', lead: 'brass', harp: 2, bass: 1, drum: 'timp',
    chords: [[1, 2], [2, 1], [7, 1], [6, 2], [1, 2]],
    mel: '1 - - 2 3 - 5 - | 4 - 3 - 2 - - - | 1 - - 2 3 - 6 - | 5 - - - - - r r | 8 - 7 - 6 - 5 - | 4 - 5 - 6 - 3 - | 2 - 3 - 4 - 2 - | 1 - - - - - r r' },
  court: { bpm: 80, root: 53, mode: 'ionian', pad: 'strings', lead: 'bell', harp: 1, bass: 1,
    chords: [[1, 1], [5, 1], [6, 1], [4, 1]],
    mel: '3 - 4 5 - 3 1 - | 2 - 3 4 - 2 0 - | 1 - 3 5 - 8 7 - | 6 - 5 - - - r r' },
  history: { bpm: 60, root: 50, mode: 'aeolian', pad: 'choir', lead: 'bell', harp: 2, bass: 1,
    chords: [[1, 2], [6, 2], [3, 2], [7, 2]],
    mel: '5 - - - 4 - 3 - | 2 - - - - - r r | 3 - - - 5 - 4 - | 1 - - - - - r r' },
  tension: { bpm: 92, root: 48, mode: 'harm', pad: 'strings', lead: null, harp: 0, bass: 2, drum: 'timp',
    chords: [[1, 2], [6, 1], [5, 1]], mel: 'r' },
  shadow: { bpm: 54, root: 45, mode: 'phrygian', pad: 'choir', lead: 'bell', harp: 0, bass: 1, sparse: 1,
    chords: [[1, 4], [2, 4]], mel: 'r r r r 2 - - - | r r r r r r r r | r r 1 - - - - - | r r r r r r r r' },
  boss: { bpm: 138, root: 50, mode: 'harm', pad: 'choir', lead: 'brass', harp: 0, bass: 2, drum: 'march',
    chords: [[1, 2], [6, 1], [7, 1], [4, 2], [5, 2]],
    mel: '1 - 1 2 3 - 2 1 | 0 - 1 - 5 - - - | 6 - 5 4 3 - 4 5 | 5 - - - r r r r | 8 - 7 - 6 - 5 - | 6 - 5 - 4 - 3 - | 2 - 3 - 4 - 0 - | 1 - - - r r r r' },
  ring: { bpm: 70, root: 60, mode: 'lydian', pad: 'choir', lead: 'bell', harp: 1, bass: 1,
    chords: [[1, 2], [2, 2]], mel: '1 - 3 - 5 - 7 - | 9 - - - 8 - - - | 6 - 5 - 4 - 5 - | 3 - - - - - r r' },
  bridge: { bpm: 110, root: 57, mode: 'ionian', pad: 'strings', lead: 'brass', harp: 1, bass: 1, drum: 'frame',
    chords: [[1, 1], [5, 1], [4, 1], [1, 1]], mel: '5 8 7 8 9 - 8 - | 6 - 5 - 3 - 5 - | 4 5 6 - 8 - 7 - | 8 - - - r r r r' },
  fall: { bpm: 56, root: 47, mode: 'aeolian', pad: 'choir', lead: 'flute', harp: 2, bass: 1,
    chords: [[1, 2], [4, 2], [6, 2], [5, 2]], mel: '8 - - - 7 - 6 - | 5 - - - - - 4 - | 3 - 4 - 5 - 3 - | 2 - - - 1 - - -' },
};
for (const k in SONGS27) { // pré-processa: tokens da melodia e mapa colcheia -> acorde
  const s = SONGS27[k];
  s.tok = s.mel.split(/\s+/).filter(t => t && t !== '|');
  s.bars = s.chords.reduce((n, c) => n + c[1], 0);
  s.chordAt = []; for (const [deg, n] of s.chords) for (let i = 0; i < n; i++) s.chordAt.push(deg);
}
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
const degMidi = (s, d) => { const sc = MODES[s.mode], i = d - 1, o = Math.floor(i / 7); return s.root + sc[((i % 7) + 7) % 7] + 12 * o; };

Object.assign(Snd, {
  songs: SONGS27,
  room() { // sala: reverberação gerada (ruído com decaimento) em paralelo ao som seco
    if (this.rev || !this.ctx) return;
    const c = this.ctx, len = Math.floor(c.sampleRate * 3.2), ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.8); }
    this.rev = c.createConvolver(); this.rev.buffer = ir;
    this.wet = c.createGain(); this.wet.gain.value = .8; this.dry = c.createGain(); this.dry.gain.value = 1.05;
    this.bus.disconnect(); this.bus.connect(this.dry); this.bus.connect(this.rev); this.rev.connect(this.wet);
    this.dry.connect(this.gain); this.wet.connect(this.gain);
  },
  voice(T, f, dur, o) { // um oscilador (ou vários, desafinados) -> filtro -> envelope -> bus
    const c = this.ctx, g = c.createGain(), out = o.filter ? c.createBiquadFilter() : null;
    if (out) { out.type = o.filter; out.frequency.setValueAtTime(o.fq, T); if (o.fq2) out.frequency.linearRampToValueAtTime(o.fq2, T + (o.a || .01) * 1.5); out.Q.value = o.q || .7; out.connect(g); }
    const a = o.a || .01, r = o.r || .3, v = o.v;
    g.gain.setValueAtTime(0, T); g.gain.linearRampToValueAtTime(v, T + a);
    if (o.pluck) g.gain.exponentialRampToValueAtTime(.0005, T + dur + r);
    else { g.gain.setValueAtTime(v, T + Math.max(a, dur)); g.gain.linearRampToValueAtTime(0, T + Math.max(a, dur) + r); }
    g.connect(this.bus);
    const end = T + Math.max(a, dur) + r + .05;
    for (const [type, mul, det, lvl] of o.osc) {
      const s = c.createOscillator(), sg = c.createGain(); s.type = type; s.frequency.setValueAtTime(f * mul, T); s.detune.value = det || 0; sg.gain.value = lvl ?? 1;
      if (o.vib) { const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = o.vib; lg.gain.setValueAtTime(0, T); lg.gain.linearRampToValueAtTime(o.vd || 6, T + .4); l.connect(lg); lg.connect(s.detune); l.start(T); l.stop(end); }
      s.connect(sg); sg.connect(out || g); s.start(T); s.stop(end);
    }
  },
  inst(name, T, m, dur, vel = 1) {
    const f = mtof(m);
    switch (name) {
      case 'strings': return this.voice(T, f, dur, { osc: [['sawtooth', 1, -7, .5], ['sawtooth', 1, 7, .5]], filter: 'lowpass', fq: 1300, a: .5, r: .9, v: .022 * vel, vib: 5, vd: 4 });
      case 'choir': return this.voice(T, f, dur, { osc: [['sawtooth', 1, -9, .4], ['sawtooth', 1, 0, .4], ['sawtooth', 1, 9, .4]], filter: 'bandpass', fq: 820, q: 1.6, a: .8, r: 1.2, v: .06 * vel, vib: 5.3, vd: 7 });
      case 'harp': return this.voice(T, f, .05, { osc: [['triangle', 1, 0, 1], ['sine', 2, 0, .35]], a: .004, r: 1.5, v: .05 * vel, pluck: 1 });
      case 'flute': return this.voice(T, f, dur, { osc: [['sine', 1, 0, 1], ['triangle', 2, 0, .12]], filter: 'lowpass', fq: 3200, a: .08, r: .25, v: .05 * vel, vib: 5.5, vd: 10 });
      case 'brass': return this.voice(T, f, dur, { osc: [['sawtooth', 1, -4, .6], ['sawtooth', 1, 4, .6]], filter: 'lowpass', fq: 500, fq2: 1900, a: .12, r: .3, v: .035 * vel, vib: 4.5, vd: 5 });
      case 'bell': return this.voice(T, f, .05, { osc: [['sine', 1, 0, 1], ['sine', 2.76, 0, .35], ['sine', 5.4, 0, .12]], a: .005, r: 2.4, v: .045 * vel, pluck: 1 });
      case 'piano': return this.voice(T, f, .05, { osc: [['triangle', 1, 0, 1], ['sine', 2, 0, .25], ['sine', 1, 3, .5]], filter: 'lowpass', fq: 1800, a: .006, r: 2.2, v: .055 * vel, pluck: 1 }); // piano abafado
      case 'bass': return this.voice(T, f, dur, { osc: [['triangle', 1, 0, 1], ['sine', .5, 0, .5]], filter: 'lowpass', fq: 600, a: .02, r: .2, v: .07 * vel });
    }
  },
  drum(kind, T, accent) {
    const c = this.ctx;
    if (kind === 'timp' || (kind === 'march' && accent)) { // tímpano: seno que cai de afinação + ruído grave
      const o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(accent ? 98 : 82, T); o.frequency.exponentialRampToValueAtTime(52, T + .5);
      g.gain.setValueAtTime(accent ? .22 : .12, T); g.gain.exponentialRampToValueAtTime(.001, T + .9); o.connect(g); g.connect(this.bus); o.start(T); o.stop(T + 1);
    }
    if (kind === 'frame' || kind === 'march') { // tambor de moldura / caixa abafada
      const n = Math.floor(c.sampleRate * .16), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 3);
      const s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain(); s.buffer = b; fl.type = 'bandpass'; fl.frequency.value = kind === 'march' ? 1400 : 300; fl.Q.value = 1.2; g.gain.value = (accent ? .16 : .08) * (kind === 'march' ? .8 : 1);
      s.connect(fl); fl.connect(g); g.connect(this.bus); s.start(T);
    }
  },
  tickMusic() {
    if (!this.ctx || !this.song || !G.opts.sound || G.state === 'paused') return;
    const s = SONGS27[this.song]; if (!s) return;
    this.room();
    const now = this.ctx.currentTime, e8 = 60 / s.bpm / 2;
    if (this.next < now) this.next = now + .05;
    while (this.next < now + .3) {
      const st = this.step++, T = this.next, bar = Math.floor(st / 8) % s.bars, pos = st % 8, deg = s.chordAt[bar];
      const chordStart = pos === 0 && (bar === 0 || s.chordAt[bar - 1] !== deg);
      const tones = [0, 2, 4].map(k => degMidi(s, deg + k));
      if (chordStart) { // pad segura o acorde inteiro
        let n = 1; while (bar + n < s.bars && s.chordAt[bar + n] === deg) n++;
        const len = n * 8 * e8;
        tones.forEach((m, i) => this.inst(s.pad, T, m - 12 + (i === 0 ? 0 : 12) * (s.pad === 'choir' ? 0 : 0), len, i === 0 ? .9 : .75));
        if (s.pad === 'choir') this.inst('strings', T, tones[0] - 24, len, .7);
      }
      if (s.bass === 2 && pos % 1 === 0) this.inst('bass', T, tones[0] - 24 + (pos % 4 === 3 ? 7 : 0), e8 * .9, pos % 2 ? .7 : 1); // ostinato em colcheias
      else if (s.bass && pos % 4 === 0) this.inst('bass', T, tones[0] - 24, e8 * 3.6);
      if (s.harp && (s.harp === 1 || pos % 2 === 0)) { const ar = [0, 1, 2, 3, 2, 1, 2, 1][pos], m = ar === 3 ? tones[0] + 12 : tones[ar]; this.inst('harp', T, m + (s.harp === 1 ? 12 : 0), e8, s.sparse ? .4 : .6); }
      if (s.lead) {
        const k = st % s.tok.length, t = s.tok[k];
        if (t !== '-' && t !== 'r') { let n = 1; while (s.tok[(k + n) % s.tok.length] === '-' && n < 16) n++; this.inst(s.lead, T, degMidi(s, +t) + (s.lead === 'bass' ? -12 : 0), n * e8 * .95); }
      }
      if (s.drum === 'timp' && pos === 0 && bar % 2 === 0) this.drum('timp', T, bar === 0);
      if (s.drum === 'frame' && (pos === 0 || pos === 3 || pos === 6)) this.drum('frame', T, pos === 0);
      if (s.drum === 'march') this.drum('march', T, pos === 0 || pos === 4);
      this.next += e8;
    }
  },
});
// Clima geral (pedido do autor): calmo, relaxante e um pouco melancólico. Andamentos lentos, modos menores,
// piano abafado, flauta e sinos no lugar dos metais, quase sem percussão; só o Guardião mantém algum pulso.
const CHILL = {
  title: { bpm: 56, mode: 'aeolian', lead: 'piano', drum: null, harp: 2 },
  myriadd: { bpm: 62, mode: 'dorian', lead: 'flute', harp: 2 },
  gilead: { bpm: 54, mode: 'aeolian', lead: 'piano' },
  iomadh: { bpm: 68, mode: 'dorian', lead: 'flute', drum: null, harp: 2 },
  ehrein: { bpm: 56, mode: 'aeolian', lead: 'flute', drum: null },
  court: { bpm: 60, mode: 'dorian', lead: 'piano', harp: 2 },
  history: { bpm: 52, lead: 'piano' },
  tension: { bpm: 66, bass: 1, drum: null, lead: null },
  shadow: { bpm: 48 },
  boss: { bpm: 104, lead: 'strings', drum: 'timp', bass: 2 },
  ring: { bpm: 58, mode: 'dorian', lead: 'piano' },
  bridge: { bpm: 76, mode: 'mixo', lead: 'flute', drum: null },
  fall: { bpm: 50, lead: 'piano' },
};
for (const k in CHILL) Object.assign(SONGS27[k], CHILL[k]);
// Variações por tipo de área (pedido do autor): a mesma melodia do reino muda de modo, andamento e instrumentos.
//   palácio de Myriadd: palaciano e tranquilo · exterior de Myriadd: bucólico · hubs: calmos (os temas acima)
//   regiões selvagens (Campo, Mata, Charneca): melancólicas · santuários: densos · chefes: versão alucinante do tema
const prep = s => { s.tok = s.mel.split(/\s+/).filter(t => t && t !== '|'); s.bars = s.chords.reduce((n, c) => n + c[1], 0); s.chordAt = []; for (const [deg, n] of s.chords) for (let i = 0; i < n; i++) s.chordAt.push(deg); return s; };
const variant = (base, over) => prep({ ...SONGS27[base], ...over });
Object.assign(SONGS27, {
  myriadd_palace: variant('myriadd', { bpm: 58, mode: 'ionian', pad: 'strings', lead: 'piano', harp: 1, bass: 1, drum: null }),
  myriadd_out: variant('myriadd', { bpm: 72, mode: 'mixo', pad: 'strings', lead: 'flute', harp: 2, bass: 1, drum: 'frame' }),
});
for (const k of ['myriadd', 'gilead', 'iomadh', 'ehrein']) {
  SONGS27[k + '_wild'] = variant(k, { bpm: Math.round(SONGS27[k].bpm * .9), mode: 'aeolian', pad: 'choir', lead: 'flute', harp: 2, bass: 1, drum: null, sparse: 1 });
  SONGS27[k + '_shrine'] = variant(k, { bpm: SONGS27[k].bpm + 6, mode: k === 'iomadh' ? 'dorian' : 'phrygian', pad: 'choir', lead: 'strings', harp: 1, bass: 2, drum: 'timp' });
  SONGS27['boss_' + k] = variant(k, { bpm: 138, mode: 'harm', pad: 'choir', lead: 'brass', harp: 1, bass: 2, drum: 'march', root: SONGS27[k].root - 2 });
}
const music0 = Snd.music.bind(Snd);
Snd.music = function (name) { // a luta de chefe toca a versão alucinante do tema do reino onde ela acontece
  if (name === 'boss' && G.map) { const k = FA_themeKingdom(G.map.theme), v = 'boss_' + k; if (SONGS27[v]) return music0(v); }
  return music0(name);
};
if (window.__ff) window.__ff.Snd = Snd;

