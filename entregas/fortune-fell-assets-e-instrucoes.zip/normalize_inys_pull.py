"""Separate Ínys's already-generated pulling poses from a composite reference guide."""
from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).resolve().parent;src=R/'assets/generated_sources/lote04_inys_pull_guide_source.png';im=Image.open(src).convert('RGBA');out=R/'assets/action_candidates';out.mkdir(exist_ok=True)
cw,ch=im.width/3,im.height/2
raw=[];girls=[]
for row in range(2):
 for col in range(3):
  c=im.crop((round(col*cw),round(row*ch),round((col+1)*cw),round((row+1)*ch)));c.putalpha(c.getchannel('A').point(lambda a:255 if a>=128 else 0));raw.append(c);girls.append(c.crop((378,100,min(c.width,590),420)))
b=girls[0].getbbox();scale=25/(b[3]-b[1]);frames=[];guides=[];sheet=Image.new('RGBA',(240,48));guide_sheet=Image.new('RGBA',(576,48));anchor=(480,373)
for i,(c,girl) in enumerate(zip(raw,girls)):
 def scaled(image):
  q=image.resize((round(image.width*scale),round(image.height*scale)),Image.Resampling.LANCZOS);q.putalpha(q.getchannel('A').point(lambda a:255 if a>=128 else 0));return q
 f=Image.new('RGBA',(40,48));f.alpha_composite(scaled(girl),(round(20-(anchor[0]-378)*scale),round(47-(anchor[1]-100)*scale)));sheet.alpha_composite(f,(i*40,0));frames.append(f)
 group=Image.new('RGBA',(96,48));group.alpha_composite(scaled(c),(round(48-(cw/2)*scale),round(47-anchor[1]*scale)));guide_sheet.alpha_composite(group,(i*96,0));guides.append(group)
sheet.save(out/'inys_pull_candidate.png');frames[0].save(out/'inys_pull_review.gif',save_all=True,append_images=frames[1:],duration=150,loop=0,disposal=2)
guide_sheet.save(R/'assets/lote04-review/inys_pull_group_guide.png');guides[0].save(R/'assets/lote04-review/inys_pull_group_guide.gif',save_all=True,append_images=guides[1:],duration=150,loop=0,disposal=2)
data={'file':'assets/action_candidates/inys_pull_candidate.png','cell':[40,48],'frames':6,'pivot':[20,47],'duration_ms':150,'visible_height_goal':25,'source':str(src.relative_to(R)),'source_anchor':list(anchor),'source_crop_each_cell':[378,100,590,420],'shared_scale':scale,'rope_join_anchor_candidate':[round(20-(480-378)*scale),round(47-(373-292)*scale)],'status':'GENERATED_CANDIDATE; not a validated walk cycle','notes':['Short cord/tassel fragment remains with her hand; dynamic cord should meet the cropped join, not draw another complete rope over it.','Contact-leg alternation, foot support, alpha fringes and loop need integrator review.','Composite guide includes doll/wheels and is reference only, not the modular runtime sprite.','No visual paint or ring-dependent recolour on Ínys.','Stop/play/turn transitions and held-doll manipulation not yet generated.']}
(R/'assets/action_candidates/inys_pull_manifest.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n');m=json.loads((R/'assets/manifest.json').read_text());m['inys']['pull_candidate']=data;(R/'assets/manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
print('Six pulling poses40x48 and composite guide exported as candidates; not integrated.')
