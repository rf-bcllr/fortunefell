"""Normalize generated source art to native game dimensions; never modifies the source."""
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
import json, shutil
ROOT=Path(__file__).resolve().parent
src=ROOT/'assets/generated_sources/characters_reference_derived_atlas.png'
source=ROOT/'assets/generated_sources';source.mkdir(parents=True,exist_ok=True)
im=Image.open(src).convert('RGBA')
ids=['king','hag','governor','inys','queen']
edges=[0,390,790,1190,1580,1983]
native=ROOT/'assets/native';native.mkdir(parents=True,exist_ok=True)
manifest={}
def clean(image):
 a=image.getchannel('A').point(lambda v:255 if v>=128 else 0);image.putalpha(a)
 return image
for i,name in enumerate(ids):
 body=im.crop((edges[i],0,edges[i+1],430));body=body.crop(body.getbbox())
 h=25 if name=='inys' else 39
 w=round(body.width*h/body.height)
 cell=Image.new('RGBA',(40,48));body=clean(body.resize((w,h),Image.Resampling.LANCZOS));cell.alpha_composite(body,((40-w)//2,47-h));cell.save(native/f'{name}_idle_seed.png')
 face=im.crop((edges[i],440,edges[i+1],793));face=face.crop(face.getbbox());face.thumbnail((124,124),Image.Resampling.LANCZOS)
 portrait=Image.new('RGBA',(128,128));portrait.alpha_composite(clean(face),((128-face.width)//2,128-face.height));portrait.save(native/f'portrait_{name}.png')
 manifest[name]={'sprite':f'assets/native/{name}_idle_seed.png','cell':[40,48],'visible_height':h,'pivot':[20,47],'frames':1,'portrait':f'assets/native/portrait_{name}.png','portrait_size':[128,128],'state':'generated-static-derived-reference; not integrated; not walk animation'}
preview=Image.new('RGBA',(800,400),(30,24,38,255));d=ImageDraw.Draw(preview)
for i,name in enumerate(ids):
 seed=Image.open(native/f'{name}_idle_seed.png');preview.alpha_composite(seed,(i*160+60,30));preview.alpha_composite(seed.resize((120,144),Image.Resampling.NEAREST),(i*160+20,100));preview.alpha_composite(Image.open(native/f'portrait_{name}.png').resize((112,112)),(i*160+24,270));d.text((i*160+20,5),name,fill='white')
preview.save(ROOT/'assets/native-review.png')
(ROOT/'assets/manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print('5 sprites 40x48, 5 portraits 128x128, manifest and native review written.')
