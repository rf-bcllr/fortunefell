# Lote02 — continuação de produção

Pacote acumulado: inclui os assets do lote01 e as novidades abaixo. O arquivo anterior fortune-fell-assets-passagem-lote01.zip permanece preservado. O lote02 contém assets e instruções, sem integração/publicação do jogo.

## Novidades

- Quatro ações candidatas de interação, em assets/action_candidates: king_weigh, hag_herbs, governor_write e queen_ceremonial. Cada PNG160×48 contém quatro células40×48; GIFs e fontes incluídos. O integrador deve conferir leitura nativa, continuidade dos acessórios e timing.
- specs/optional-dialogues-lote02.json: 21 falas opcionais PT/EN, três por personagem, com nota de condição e expressão sugerida. São conteúdo para integrar, não gatilhos de runtime. Não substituir o diálogo obrigatório da chave/evacuação por falas opcionais.
- specs/inys-carriage-doll.json: três entidades, estados pull/stop/play/talk/turn, rodas por deslocamento, âncoras e cinco estados de cabelo do boneco baseados no código existente. Tinta apenas em diálogo; design de Ínys imutável. Dimensões sugeridas de carruagem/boneco são provisórias, não aprovadas.
- normalize_actions.py e package_assets.py para reproduzir exportação e pacote usando fontes locais.

## Limites

Sem novos testes de implementação nesta rodada, por orientação do autor. A conferência foi apenas de arquivos de arte. As caminhadas do lote01 continuam candidatas, e ações novas não devem ser descritas como aprovadas em engine.

Seyrín, Halberd, carruagem/boneco e movimentos próprios de Ínys continuam faltando. Para manter os designs exatos, usar as artes originais do autor como referência de identidade, nunca os placeholders antigos do jogo.

Consultar PASSAGEM_OUTRO_CODEX.md e FICHAS_IMPLEMENTACAO.md para a matriz completa de progresso e pendências.
