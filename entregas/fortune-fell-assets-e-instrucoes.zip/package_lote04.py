"""Create a small incremental archive over immutable lote03, not another oversized cumulative bundle."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent;base=R/'fortune-fell-assets-passagem-lote03.zip'
with zipfile.ZipFile(base) as z:baseline=json.loads(z.read('CHECKSUMS.json'))
files=[p for folder in ('assets','specs') for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [R/n for n in ['LEIA_PRIMEIRO.md','PASSAGEM_OUTRO_CODEX.md','FICHAS_IMPLEMENTACAO.md','FICHAS_PRINCIPES_EHREIN.md','DECISOES_ATUAIS.md','PEDIDO_PRINCIPES.txt','LOTE04.md','LISTA_PRODUCAO.md','normalize_lote04.py','normalize_inys_pull.py','package_lote04.py'] if (R/n).is_file()]
changed={str(p.relative_to(R)):p for p in files if hashlib.sha256(p.read_bytes()).hexdigest()!=baseline.get(str(p.relative_to(R)))}
checks={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in sorted(changed.items())}
full=dict(baseline);full.update(checks)
(R/'CHECKSUMS.json').write_text(json.dumps(full,indent=2,ensure_ascii=False)+'\n');changed['CHECKSUMS.json']=R/'CHECKSUMS.json';checks['CHECKSUMS.json']=hashlib.sha256((R/'CHECKSUMS.json').read_bytes()).hexdigest()
manifest={'type':'incremental','base_archive':base.name,'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'extract_order':[base.name,'fortune-fell-assets-lote04.zip'],'files':checks,'integration':'not performed; assets and instructions only'}
(R/'LOTE04-CHECKSUMS.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n');changed['LOTE04-CHECKSUMS.json']=R/'LOTE04-CHECKSUMS.json'
zpath=R/'fortune-fell-assets-lote04.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(changed.items()):z.write(p,name)
with zipfile.ZipFile(zpath) as z:
 if z.testzip():raise RuntimeError('ZIP integrity failed')
print(json.dumps({'file':str(zpath),'files':len(changed),'MiB':round(zpath.stat().st_size/1048576,2),'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest()},indent=2))
