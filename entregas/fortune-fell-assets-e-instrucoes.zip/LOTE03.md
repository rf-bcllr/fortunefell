# Lote03 — cabana da Bruxa das Charnecas

Este pacote acumulado inclui os lotes01/02 e a nova arte da cabana. Os ZIPs anteriores permanecem preservados. Não inclui alteração no jogo publicado.

## Produzido

Em assets/environment/:

- witch_hut_body.png: exterior aberto, canvas176×144, arte150×131; âncora(88,140).
- witch_hut_door.png: folha fechada32×48, pivô(16,47), altura visível46; posição no corpo(107,140).
- witch_hut_door_mask.png: máscara geométrica para recortar a folha atrás da moldura de pedra.
- witch_hut_closed.png: composição estática fechada. Escolher esta OU corpo+folha; não desenhar as duas portas ao mesmo tempo.
- witch_hut_heather.png: módulo de urzes96×24, âncora(48,24); não esconder jogador, porta ou lane.
- witch_hut_herbs_jars.png: ervas/potes40×40, âncora(20,40), decoração sem colisão própria.
- witch_hut_interior.png: plate opaca400×225, piso192. Porta interna revisada≈30×51; posição/hotspot final ainda cabe ao integrador.
- Manifestos, review de arte e referência de escala. Referência de escala é composição estática, NÃO screenshot ou playtest.

As fontes de geração permanecem em assets/generated_sources. A versão inicial do interior tinha porta grande e foi substituída pela versão corrigida na exportação nativa. Use witch_hut_interior_source.png para reprocessar; não a initial_source.

## Integrar depois

FICHA_CABANA.md explica renderização, camadas, portais, posição sugerida no interior e progressão. A cabana pertence a em, mas não há tx/ty exterior aprovado nem novo mapa de interior criado. Uma sala25×14tiles com piso na linha12 é apenas sugestão compatível com a arte. Não alterar globalmente o tema ehreinC, pois ele serve outros ambientes.

Acesso às Charnecas não é chave do Santuário. A consulta fecha a flag correta e o jogador ainda retorna a Lúgham para receber a chave. A Bruxa deve continuar acessível como contraponto mesmo se Seyrín foi a consulta oficial.

## Próximos obrigatórios

Seyrín e Halberd; carruagem e boneco de Idhrí; estados visuais e ações de Ínys com o conjunto. As referências exatas desses itens precisam estar disponíveis em PNG para geração fiel. O cenário novo não substitui essas pendências.

Sem testes novos de implementação: nesta sessão só houve produção e conferência dos arquivos de arte, conforme orientação do autor.
