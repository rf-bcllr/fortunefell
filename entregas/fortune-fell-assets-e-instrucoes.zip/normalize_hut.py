"""Export a native cottage kit, calibrated by the painted doorway rather than stretching the building."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageChops
import json
R=Path(__file__).resolve().parent;out=R/'assets/environment';out.mkdir(exist_ok=True)
im=Image.open(R/'assets/generated_sources/witch_hut_kit_source.png').convert('RGBA')
def cut(box):
 c=im.crop(box);c.putalpha(c.getchannel('A').point(lambda x:255 if x>=128 else 0));b=c.getbbox();return c.crop(b),(box[0]+b[0],box[1]+b[1],box[0]+b[2],box[1]+b[3])
def resized(c,size):
 c=c.resize(size,Image.Resampling.LANCZOS);c.putalpha(c.getchannel('A').point(lambda x:255 if x>=128 else 0));return c
body,bbox=cut((40,20,830,710));scale=46/(660-445)
w,h=round(body.width*scale),round(body.height*scale);ox,oy=(176-w)//2,140-h
body_canvas=Image.new('RGBA',(176,144));body_canvas.alpha_composite(resized(body,(w,h)),(ox,oy));body_canvas.save(out/'witch_hut_body.png')
portal=(round((524-bbox[0])*scale)+ox,round((660-bbox[1])*scale)+oy)
leaf,_=cut((900,280,1240,710));s=46/leaf.height;w,h=round(leaf.width*s),46
panel=Image.new('RGBA',(32,48));panel.alpha_composite(resized(leaf,(w,h)),((32-w)//2,47-h));panel.save(out/'witch_hut_door.png')
# Geometry mask restricts an oversized separate leaf behind the existing stone arch.
mask=Image.new('L',(32,48));d=ImageDraw.Draw(mask);d.ellipse((4,1,28,25),fill=255);d.rectangle((4,13,28,46),fill=255);mask.save(out/'witch_hut_door_mask.png')
visible=panel.copy();visible.putalpha(ImageChops.multiply(visible.getchannel('A'),mask));closed=body_canvas.copy();closed.alpha_composite(visible,(portal[0]-16,portal[1]-47));closed.save(out/'witch_hut_closed.png')
for name,box,canvas,maxsize in [('witch_hut_heather',(50,875,760,1145),(96,24),(96,24)),('witch_hut_herbs_jars',(865,760,1300,1150),(40,40),(36,36))]:
 prop,_=cut(box);s=min(maxsize[0]/prop.width,maxsize[1]/prop.height);w,h=round(prop.width*s),round(prop.height*s);target=Image.new('RGBA',canvas);target.alpha_composite(resized(prop,(w,h)),((canvas[0]-w)//2,canvas[1]-h));target.save(out/(name+'.png'))
# Composition at actual native size and 3x is for art review only, not a game screenshot.
review=Image.new('RGBA',(720,620),(28,30,46,255));review.alpha_composite(body_canvas,(15,20));review.alpha_composite(closed,(205,20));review.alpha_composite(closed.resize((528,432),Image.Resampling.NEAREST),(15,170));review=review.crop((0,0,720,620));review.save(out/'witch_hut_review.png')
data={'art_source':'host_image','source':'assets/generated_sources/witch_hut_kit_source.png','status':'GENERATED_ART; placement/collision not integrated','body':{'file':'assets/environment/witch_hut_body.png','canvas':[176,144],'painted_size':[round(body.width*scale),round(body.height*scale)],'anchor':[88,140],'uniform_source_scale':scale,'source_box':bbox},'door':{'file':'assets/environment/witch_hut_door.png','canvas':[32,48],'pivot':[16,47],'visible_height':46,'opening_width_approx':24,'anchor_in_body':list(portal),'clip_mask':'assets/environment/witch_hut_door_mask.png','note':'Door leaf clips behind stone arch; opening trace approximate, final fit may need 1px adjustment.'},'closed_composite':'assets/environment/witch_hut_closed.png','props':[{'file':'assets/environment/witch_hut_heather.png','canvas':[96,24],'anchor':[48,24],'layer':'behind actors; foreground only outside walking/door lane'},{'file':'assets/environment/witch_hut_herbs_jars.png','canvas':[40,40],'anchor':[20,40],'layer':'back wall/decor, non-colliding'}],'placement':{'map':'em','tx':None,'ty':None,'approved':False},'render_note':'Choose open body plus door layer OR closed composite; never draw both door representations. No royal heraldry or new game mechanic.'}
(out/'witch_hut_manifest.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'body_canvas':[176,144],'painted_size':data['body']['painted_size'],'body_bbox_source':bbox,'door_anchor_body':portal,'door_visible_height':46},indent=2))
