# Lote04 — Halberd, Seyrín, conjunto de Ínys e fila dos príncipes

Entrega INCREMENTAL sobre o ZIP acumulado lote03: extraia primeiro o lote03 e depois este lote04 na mesma pasta, aceitando as atualizações de documentação e manifestos. Não é preciso reenviar os lotes01/02. Nenhuma integração ou publicação do jogo foi realizada nesta rodada. Este checkpoint substitui os estados de pendência descritos historicamente nos lotes anteriores.

## Produzido a partir das três referências reenviadas

### Halberd — `artificer`

- Idle4: assets/native/artificer_idle.png,160×48, células40×48,pivô20/47,altura-alvo30px.
- Martelar4: assets/action_candidates/artificer_hammer.png,192×48,células48×48,pivô24/47. O martelo sai das costas e está na mão nessa ação; não duplicar o objeto na implementação.
- Walk6 candidato: assets/walk_candidates/artificer_walk_candidate.png,240×48. Não aprovado em engine.
- Três portraits128×128: neutral/listening/reaction, folha384×128 e alias neutro.
- Cabelo/barba brancos,tranças/óculos na testa, avental e emblema pessoal preservados. Não voltar ao artífice ruivo antigo.

### Seyrín — `oracle`

- Idle4 e gesto de conselho4:160×48 cada,células40×48,pivô20/47,altura-alvo39px.
- Walk6 candidato240×48.
- Três portraits128×128,folha384×128 e alias neutro. Olhos/orelhas continuam escondidos em todas as expressões; variação ocorre no queixo/boca/inclinação, sem revelar a entidade.

### Carruagem e boneco

assets/props/inys_carriage_manifest.json reúne os dados reais dos recortes:

- Corpo64×40,pivô32/39; altura pintada≈30px.
- Quatro rodas separadas: três8×8 e uma6×6,com centros/pivôs. São quatro visíveis, não quatro totais; o design representa sete rodas.
- Referência de cordão16×8; o cordão dinâmico deve juntar os pontos atuais da mão e da carruagem, não ser um sprite rígido em qualquer distância.
- Boneco-base branco sentado16×20,pivô8/19,12px visíveis. Sem assento embutido; encaixe na âncora do manifesto.
- Referência estática vazia e composição com boneco em assets/lote04-review; não são screenshots do jogo.

### Ínys

- Candidato de puxar: assets/action_candidates/inys_pull_candidate.png,240×48,seis células40×48,pivô20/47,altura-alvo25px.
- GIF e manifesto detalham a âncora candidata de junção. Há um curto trecho dourado/tassel junto à mão no recorte: revisar a junção e não sobrepor outro cordão completo.
- A folha de grupo em lote04-review é guia de registro/pose, não substituir as três entidades independentes por um sprite único.

## Limite de geração encontrado

A chamada para os cinco estados de cabelo do boneco foi recusada com429/usage_limit_reached e não produziu imagem. Não houve repetição da chamada nem substituição por arte genérica. Portanto, só o estado branco sentado foi produzido. Faltam quatro estados coloridos (ou máscaras de mechas precisamente traçadas), pose segurada e ações stop/play/turn/talk do conjunto. A ferramenta informou previsão de reset para18/11/2026 às01:41:43 em America/Maceio; é observação da ferramenta, não garantia de liberação antecipada.

specs/DOLL_HAIR_IMPLEMENTATION.md preserva o mapeamento exato de anéis e oferece duas rotas ao integrador: variantes do mesmo master ou camada de mechas restrita ao cabelo. Nunca recolorir Ínys; tinta nas mãos só no diálogo.

## Fila nova: Llewlás e Llúpin

FICHAS_PRINCIPES_EHREIN.md e PEDIDO_PRINCIPES.txt guardam a solicitação completa. Os dois estão NA FILA, com zero assets produzidos nesta rodada. Portar também as fichas visuais oficiais anexadas pelo autor quando encaminhar para outra conversa.

- Llúpin substitui o herdeiro genérico em ec20/12. Óculos apenas na leitura; livro vermelho sem torre; ciclo contextual13estados.
- Llewlás começa nas Charnecas perto da cabana, em ponto a escolher. Caça, movimentação, acompanhamento e combate opcionais exigem produção maior, com lança/projétil/corno separados. Não definir morte definitiva nem inferi-la da flag genérica de habitantes.

## Conferência e próximos passos

Conferência nesta rodada restrita aos arquivos exportados: tamanho, alpha, recorte e inventário. Não houve testes de integração ou playtest, conforme orientação do autor. Todos os ciclos novos continuam candidatos para continuidade de pernas, contato com props, timing, apoio e registro final na outra conta.

Para Halberd martelar a bigorna existente em16/12, ajustar sua posição de trabalho: o NPC original está em19/12, distante demais para um golpe visual. Não alterar o comportamento de compra/upgrades só para animar o martelo.

Carregar as novas artes com chaves exclusivas exp_artificer_*/exp_oracle_*/exp_portrait_*; o loader antigo pode escolher _up e mostrar o retrato anterior se a troca não for explícita. Não ativar narrative.js sem criar NPCs/portais e revisar progressão/saves.
