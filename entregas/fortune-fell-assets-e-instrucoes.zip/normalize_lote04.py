"""Normalize already-generated Halberd/Seyrín art and decompose the approved cart. No image generation or game integration."""
from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).resolve().parent;S=R/'assets/generated_sources';N=R/'assets/native';A=R/'assets/action_candidates';W=R/'assets/walk_candidates';P=R/'assets/props';V=R/'assets/lote04-review'
for p in (N,A,W,P,V):p.mkdir(exist_ok=True)
def alpha(c):
 c=c.convert('RGBA');c.putalpha(c.getchannel('A').point(lambda x:255 if x>=128 else 0));return c
def crop(c,box):
 c=alpha(c.crop(box));b=c.getbbox()
 if b is None:raise ValueError('Empty source region')
 return c.crop(b),(box[0]+b[0],box[1]+b[1],box[0]+b[2],box[1]+b[3])
def resize(c,size):return alpha(c.resize(size,Image.Resampling.LANCZOS))
def export_strip(cells,scale,size,path,timings):
 frames=[];sheet=Image.new('RGBA',(size[0]*len(cells),size[1]))
 for i,c in enumerate(cells):
  w,h=round(c.width*scale),round(c.height*scale)
  if w>size[0] or h>size[1]-1:raise ValueError((path.name,i,w,h,'Do not shrink individual frames'))
  f=Image.new('RGBA',size);f.alpha_composite(resize(c,(w,h)),((size[0]-w)//2,size[1]-1-h));sheet.alpha_composite(f,(i*size[0],0));frames.append(f)
 sheet.save(path);frames[0].save(path.with_name(path.stem+'_review.gif'),save_all=True,append_images=frames[1:],duration=timings,loop=0,disposal=2)
 return frames
m=json.loads((R/'assets/manifest.json').read_text())
body=Image.open(S/'lote04_idle_actions_source.png');bounds=[0,308,612,941,body.height]
character_scales={}
for row,name,target,kind in [(0,'artificer',30,'idle'),(1,'artificer',30,'hammer'),(2,'oracle',39,'idle'),(3,'oracle',39,'counsel')]:
 cells=[crop(body,(round(i*body.width/4),bounds[row],round((i+1)*body.width/4),bounds[row+1]))[0] for i in range(4)]
 if kind=='idle':character_scales[name]=target/cells[0].height
 scale=character_scales[name];size=(48,48) if kind=='hammer' else (40,48);dest=N if kind=='idle' else A
 timings=[350,220,180,220] if kind=='idle' else [180,220,90,240] if kind=='hammer' else [350,250,450,300]
 frames=export_strip(cells,scale,size,dest/f'{name}_{kind}.png',timings)
 if kind=='idle':
  frames[0].save(N/f'{name}_idle_seed.png');m[name]={'name':'Halberd' if name=='artificer' else 'Seyrín','sprite':f'assets/native/{name}_idle.png','cell':list(size),'frames':4,'pivot':[size[0]//2,47],'visible_height_goal':target,'visible_height':target,'runtime_key_prefix':'exp_'+name,'portrait_key_prefix':'exp_portrait_'+name,'duration_ms':timings,'state':'GENERATED_CANDIDATE; no engine integration'}
 else:m[name]['interaction_candidate']={'action':kind,'file':f'assets/action_candidates/{name}_{kind}.png','cell':list(size),'frames':4,'pivot':[size[0]//2,47],'duration_ms':timings,'status':'Generated; timing/prop continuity/anchor review left to integrator','impact_frame':2 if kind=='hammer' else None,'event_note':'Hammer impact is workshop visual/audio only, not combat damage.' if kind=='hammer' else 'No magical effects or identity reveal.'}
walk=Image.open(S/'lote04_walks_source.png');wb=[0,325,walk.height]
for row,name,target in [(0,'artificer',30),(1,'oracle',39)]:
 cells=[crop(walk,(round(i*walk.width/6),wb[row],round((i+1)*walk.width/6),wb[row+1]))[0] for i in range(6)]
 export_strip(cells,target/cells[0].height,(40,48),W/f'{name}_walk_candidate.png',[140]*6)
 m[name]['walk_candidate']={'file':f'assets/walk_candidates/{name}_walk_candidate.png','cell':[40,48],'frames':6,'pivot':[20,47],'duration_ms':140,'status':'REVIEW REQUIRED: leg alternation, sliding and costume/prop continuity not approved in engine.'}
por=Image.open(S/'lote04_portraits_source.png');pb=[0,499,por.height];labels=['neutral','listening','reaction'];review=Image.new('RGBA',(430,290),(30,24,38,255));d=ImageDraw.Draw(review)
for row,name in enumerate(['artificer','oracle']):
 cells=[crop(por,(i*512,pb[row],(i+1)*512,pb[row+1]))[0] for i in range(3)]
 scale=min(124/max(c.width for c in cells),124/max(c.height for c in cells));sheet=Image.new('RGBA',(384,128));files={}
 for i,(label,c) in enumerate(zip(labels,cells)):
  w,h=round(c.width*scale),round(c.height*scale);f=Image.new('RGBA',(128,128));f.alpha_composite(resize(c,(w,h)),((128-w)//2,128-h));f.save(N/f'portrait_{name}_{label}.png');sheet.alpha_composite(f,(i*128,0));review.alpha_composite(f,(i*140+4,row*144+14));files[label]=f'assets/native/portrait_{name}_{label}.png'
  if i==0:f.save(N/f'portrait_{name}.png')
 sheet.save(N/f'portrait_{name}_expressions.png');m[name].update(portrait=files['neutral'],portrait_size=[128,128],portrait_expression_cell=[128,128],portrait_expressions=files,portrait_sheet=f'assets/native/portrait_{name}_expressions.png');d.text((4,row*144),name,fill='white')
review.save(V/'portraits.png')
master=Image.open(S/'lote04_master_atlas.png');toy,_=crop(master,(1040,550,1536,1024));sc=12/toy.height;w,h=round(toy.width*sc),12;f=Image.new('RGBA',(16,20));f.alpha_composite(resize(toy,(w,h)),((16-w)//2,19-h));f.save(P/'idhri_ragdoll_seated_0.png')
cart,bbox=crop(master,(900,0,1536,530));scale=30/cart.height;w,h=round(cart.width*scale),30;off=((64-w)//2,39-h)
def cart_native(c):
 out=Image.new('RGBA',(64,40));out.alpha_composite(resize(c,(w,h)),off);return out
cart_native(cart).save(P/'inys_carriage_empty_complete_reference.png')
chassis=cart.copy();mask=chassis.getchannel('A');md=ImageDraw.Draw(mask);wheel_defs=[(1055,449,55),(1159,449,55),(1262,449,55),(1376,464,44)];wheels=[]
for i,(cx,cy,radius) in enumerate(wheel_defs):
 x,y=cx-bbox[0],cy-bbox[1];md.ellipse((x-radius,y-radius,x+radius,y+radius),fill=0)
 c=master.crop((cx-radius,cy-radius,cx+radius,cy+radius)).convert('RGBA');wm=Image.new('L',c.size);ImageDraw.Draw(wm).ellipse((0,0,c.width-1,c.height-1),fill=255)
 from PIL import ImageChops
 c.putalpha(ImageChops.multiply(alpha(c).getchannel('A'),wm));diam=8 if i<3 else 6;resize(c,(diam,diam)).save(P/f'inys_carriage_wheel_{i}.png');wheels.append({'file':f'assets/props/inys_carriage_wheel_{i}.png','canvas':[diam,diam],'pivot':[diam/2,diam/2],'center_in_carriage':[off[0]+round(x*scale),off[1]+round(y*scale)],'radius':diam/2})
# Rope is a separate visual. Masking source pixels is decomposition, not repainting the design.
md.rectangle((1390-bbox[0],0,cart.width,435-bbox[1]),fill=0);chassis.putalpha(mask);cart_native(chassis).save(P/'inys_carriage_body.png')
rope,_=crop(master,(1390,350,1536,438));rs=min(16/rope.width,8/rope.height);rw,rh=round(rope.width*rs),round(rope.height*rs);rf=Image.new('RGBA',(16,8));rf.alpha_composite(resize(rope,(rw,rh)),(0,(8-rh)//2));rf.save(P/'inys_carriage_cord_reference.png')
seat=[off[0]+round((1165-bbox[0])*scale),off[1]+round((343-bbox[1])*scale)];hitch=[off[0]+round((1380-bbox[0])*scale),off[1]+round((391-bbox[1])*scale)]
carriage={'art_source':'host_image; source-based layer decomposition','source':'assets/generated_sources/lote04_master_atlas.png','body':'assets/props/inys_carriage_body.png','canvas':[64,40],'pivot':[32,39],'visible_height_goal':30,'body_source_box':bbox,'uniform_source_scale':scale,'wheels_visible':4,'wheels_total':7,'wheels':wheels,'seat_anchor':seat,'hitch_anchor':hitch,'cord_reference':'assets/props/inys_carriage_cord_reference.png','cord_note':'Runtime cord should join hitch to current hand anchor; this crop is reference/style, not a rigid universal rope. Wheels rotate from actual displacement and stop on idle.','doll_base':{'file':'assets/props/idhri_ragdoll_seated_0.png','cell':[16,20],'pivot':[8,19],'visible_height':12,'state':'white hair only; coloured streak states and held pose not generated because quota429'},'status':'GENERATED MODULAR CANDIDATE; wheel seams/seat fit/loop not approved in game'}
(P/'inys_carriage_manifest.json').write_text(json.dumps(carriage,indent=2,ensure_ascii=False)+'\n')
assembled=cart_native(chassis)
for item in wheels:
 wheel=Image.open(R/item['file']);assembled.alpha_composite(wheel,(round(item['center_in_carriage'][0]-item['pivot'][0]),round(item['center_in_carriage'][1]-item['pivot'][1])))
assembled.alpha_composite(f,(seat[0]-8,seat[1]-19));assembled.save(V/'carriage_with_base_doll.png')
(R/'assets/manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n');print('Halberd/Seyrín: idle/actions/walks,6portraits; cart layers4wheels/cord and white-haired cloth doll exported. Not integrated.')
