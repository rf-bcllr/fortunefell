from pathlib import Path
from PIL import Image
import json,shutil,hashlib
R=Path(__file__).resolve().parent
src=R/'assets/generated_sources/five_characters_idle_source.png'
im=Image.open(src).convert('RGBA');ids=['king','hag','governor','inys','queen'];manifest=json.loads((R/'assets/manifest.json').read_text())
report={}
for row,name in enumerate(ids):
 crops=[]
 for col in range(4):
  cell=im.crop((round(col*im.width/4),round(row*im.height/5),round((col+1)*im.width/4),round((row+1)*im.height/5)))
  alpha=cell.getchannel('A').point(lambda v:255 if v>=128 else 0);cell.putalpha(alpha)
  crops.append(cell.crop(cell.getbbox()))
 scale=(25 if name=='inys' else 39)/crops[0].height
 strip=Image.new('RGBA',(160,48));frames=[]
 for i,crop in enumerate(crops):
  w,h=round(crop.width*scale),round(crop.height*scale)
  assert w<=40 and h<=47,(name,w,h)
  frame=Image.new('RGBA',(40,48));crop=crop.resize((w,h),Image.Resampling.LANCZOS);crop.putalpha(crop.getchannel('A').point(lambda v:255 if v>=128 else 0));frame.alpha_composite(crop,((40-w)//2,47-h));frames.append(frame);strip.alpha_composite(frame,(40*i,0))
 strip.save(R/f'assets/native/{name}_idle.png')
 frames[0].save(R/f'assets/native/{name}_idle_review.gif',save_all=True,append_images=frames[1:],duration=[350,220,180,220],loop=0,disposal=2)
 hashes=[hashlib.sha256(f.tobytes()).hexdigest() for f in frames]
 report[name]={'frames':4,'distinct_frames':len(set(hashes)),'size':list(strip.size),'alpha_binary':set(strip.getchannel('A').getdata()).issubset({0,255}),'shared_scale':scale,'review':'Idle poses visually differ; no walk generated; in-engine review pending.'}
 manifest[name].update(sprite=f'assets/native/{name}_idle.png',frames=4,state='derived four-pose idle; in-engine review pending',duration_ms=[350,220,180,220])
(R/'assets/manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n');(R/'assets/idle-qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
