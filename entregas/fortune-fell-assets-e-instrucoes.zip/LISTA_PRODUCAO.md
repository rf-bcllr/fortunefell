# Lista de produção — checkpoint04 parcial/exportado; integração pendente

Estados abaixo significam produção de arquivos, não integração ou publicação.

**Bloqueio atual:** imagegen devolveu HTTP429/usage_limit_reached ao tentar cinco estados do boneco; sem arte dessa tentativa e sem retry até reset. Referências PNG já estão acessíveis. Lote04 normalizado/exportado; walks/ações/pull são candidatos, não aprovação em engine. Pacote04 incremental exige extrair ZIP03 antes.

| Prioridade | Item | Estado e próximo passo |
|---|---|---|
| P0 | Seyrín | Lote04 exportado: oracle idle4/39px, portraits3, walk6/counsel4 candidatos. Integração/revisão pendentes. |
| P0 | Halberd | Lote04 exportado: artificer idle4/30px, portraits3, walk6/hammer4 candidatos. Não usar ruivo antigo; mover ator19/12 junto à bigorna16/12 antes de martelar. |
| P0 | Carruagem de Ínys | Lote04 exportado: corpo64×40, quatro rodas separadas, cordref e referência completa; junções/rotação runtime a revisar. |
| P0 | Boneco de pano de Idhrí | Lote04 exportado: boneco-base branco sentado16×20. Quatro estados coloridos/held pendentes; geração5hair bloqueada por quota429. |
| P0 | Ínys com o conjunto | Pull6 candidato exportado; junção cordão/apoio/loop a revisar. Play/held/stop/talk/turn específicos não concluídos. Tinta só em fala. |
| P1 | Lúgham | Idle4, portraits3, walk6 candidato e ação balança4 produzidos; integração/revisão pela outra conta. |
| P1 | Bruxa | Idle4, portraits3, walk6 candidato e ação ervas4 produzidos; integração/revisão pela outra conta. |
| P1 | A'Maídhe | Idle4, portraits3, walk6 candidato e ação escrita4 produzidos; integração/revisão pela outra conta. |
| P1 | Niobhán | Idle4, portraits3, walk6 candidato e gesto cerimonial4 produzidos; integração/revisão pela outra conta. |
| Produzido | Cabana — exterior modular | Corpo, porta, máscara, estado fechado, urzes e ervas/potes exportados. Falta posicionar em em. |
| Produzido | Cabana — interior | Arte400×225/piso192 exportada. Falta criar mapa, atores, colisões e portais. |
| Produzido | Falas opcionais | 21 entradas PT/EN; integrar gatilhos/expressões sem substituir a missão obrigatória. |
| Rascunho | Consulta/chave/evacuação | narrative.js e12 testes isolados com stubs; integração real e migração de saves ainda faltam. |
| Na fila | Llewlás | Sprites/portraits/props e animações extensas de caça/companhia/combate opcionais; nenhum asset gerado. em perto Bruxa, tx/ty pendentes; sem morte definitiva. |
| Na fila | Llúpin | Sprites/portraits e ciclo13estados leitura; nenhum asset gerado. Substituir heir em ec20/12; idle sem óculos, sem combate. |
| Outro Codex | Conferência e publicação | Revisar escala, animação, diálogos, progressão e duas ordens de visita; publicar só na identidade do site existente. |

Detalhes: PASSAGEM_OUTRO_CODEX.md, FICHAS_IMPLEMENTACAO.md, FICHA_CABANA.md, FICHAS_PRINCIPES_EHREIN.md e manifests dos assets.

Lote04 fechado como incremental SOBRE lote03 preservado19,42MiB; consultar LEIA_PRIMEIRO.md, LOTE04.md e package_lote04.py. Não há geração em execução após quota429. `specs/DOLL_HAIR_IMPLEMENTATION.md` é alternativa futura, não variantes PNG produzidas. Pendências reais: quatro cores/held/play/stop/talk/turn do conjunto Ínys, revisão dos candidatos, integração/testes/publicação; príncipes apenas na fila. Referências PNG atuais recebidas, bloqueio antigo resolvido.
