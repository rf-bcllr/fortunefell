/* Expansion: consultation and evacuation. Existing maps and combat retained. */
Object.assign(NAMES,{artificer:['Halberd','Halberd'],queen:['Niobhán','Niobhán'],governor:["A'Maídhe","A'Maídhe"],king:['Lúgham','Lúgham'],oracle:['Seyrín','Seyrín'],hag:['Velha Bruxa das Charnecas','The Old Hag of the Moors'],inys:['Ínys','Ínys']});
for(const e of LEVELS.eh.ents)if(e.type==='gate'&&e.needs==='auth_ehrein')e.needs='moors_open';
const expansionUseDoor=Story.useDoor;
Story.useDoor=function(d){
 if(G.map?.id==='em'&&d.to==='ed'&&!flag('auth_ehrein'))return run(say('idhri','Ainda preciso voltar a Lúgham e receber a chave do Santuário.','I still need to return to Lúgham and receive the Shrine key.'));
 return expansionUseDoor.call(this,d);
};
Talk.king=()=> (function*(){
 if(flag('auth_ehrein')){
  if(!flag('evacuation_decided')){
   yield* say('king','A chave já está convosco. Mas a balança não para. Devo pedir ao povo que abandone suas casas?','You have the key. Yet the scales will not settle. Must I ask my people to leave their homes?');
   const answer=yield* choose('idhri','O que Idhrí sugere?','What does Idhrí suggest?',[['Evacue o reino pela ponte que ainda está de pé.','Evacuate through the bridge that still stands.'],['Não recomendo a evacuação.','I do not recommend evacuation.'],['Preciso pensar.','I need to think.']]);
   if(answer===2)return;
   setFlag('evacuation_decided');setFlag('evacuation_ordered',answer===0?1:0);
   if(answer===0){G.flags.evacuation_destination=flag('cut_gilead')?'iomadh':'gilead';yield* say('king',`Então darei a ordem. Seguiremos para ${KNAME[G.flags.evacuation_destination]}. A balança terá de viajar comigo.`,`Then I shall give the order. We shall go to ${KNAME[G.flags.evacuation_destination]}. The scales must travel with me.`);}
   else yield* say('king','Ficaremos. Que eu saiba responder por esta decisão.','We shall stay. May I be able to answer for this decision.');
   saveGame();return;
  }
  yield* say('king',flag('evacuation_ordered')?'A ordem foi dada. Levaremos os cidadãos pela última ponte.':'Meu povo permanece. Ide ao Santuário.',flag('evacuation_ordered')?'The order is given. We will take our citizens across the last bridge.':'My people remain. Go to the Shrine.');return;
 }
 setFlag('moors_open');
 if(!flag('consultation_requested')){
  setFlag('consultation_requested');G.flags.consultation_required=flag('cut_gilead')?'hag':'oracle';
  yield* say('king','Uma balança feita por Halberd, presente de vosso pai. Pesa metal com perfeição. Decisões, nem tanto.','Scales made by Halberd, a gift from your father. They weigh metal perfectly. Decisions, less so.');
 }
 const who=G.flags.consultation_required;
 if(!flag('consulted_'+who)){
  yield* say('king',who==='hag'?'A ponte de Gileád caiu. Procurai a velha bruxa nas Charnecas. Abro esse caminho, mas guardo a chave até ouvir seu conselho.':'A ponte de Gileád ainda resiste. Consultai Seyrín, a Oráculo, antes que eu vos entregue a chave. As Charnecas estão abertas.',who==='hag'?'The Gileád bridge has fallen. Seek the old hag in the Moors. I open that way, but keep the key until I hear her counsel.':'The Gileád bridge still stands. Consult Seyrín, the Oracle, before I give you the key. The Moors are open.');return;
 }
 yield* say('idhri',who==='hag'?'Ela pediu que eu questionasse as certezas e não confiasse nas palavras de Seyrín.':'Seyrín aconselhou que o povo permanecesse em Éhrein.',who==='hag'?'She asked me to question certainty and distrust Seyrín’s words.':'Seyrín advised that the people remain in Éhrein.');
 yield* say('king','Tendes a chave do Santuário. E eu, mais uma decisão a pesar. Falai comigo antes de partir, se tiverdes conselho para meu povo.','You have the Shrine key. And I have another decision to weigh. Speak to me before leaving if you have counsel for my people.');
 setFlag('auth_ehrein');saveGame();
}());
Talk.oracle=()=> (function*(){
 yield* say('oracle','Nem toda salvação toma a forma de uma partida. Às vezes, a raiz sustenta o que o vento deseja levar.','Not every salvation takes the shape of departure. Sometimes the root sustains what the wind would carry away.');
 if(flag('consultation_requested')){yield* say('oracle','Dizei a Lúgham: que Éhrein conserve seu povo junto à Roda. Uma casa abandonada já começou a cair.','Tell Lúgham: let Éhrein keep its people beside the Wheel. An abandoned home has already begun to fall.');setFlag('consulted_oracle');saveGame();}
}());
Talk.hag=()=> (function*(){
 yield* say('hag','Seyrín tem palavras macias. Bom para travesseiro; ruim para enxergar onde se pisa. Não confieis nelas só porque soam como destino.','Seyrín has soft words. Good for a pillow; poor for seeing where you step. Do not trust them merely because they sound like fate.');
 if(flag('consultation_requested')){yield* say('hag','Levai ao rei o que ouvistes, não uma certeza emprestada. Ainda há uma ponte. Pedras não precisam dela; gente precisa.','Take the king what you heard, not borrowed certainty. There is still a bridge. Stones have no need of it; people do.');setFlag('consulted_hag');saveGame();}
}());
const expansionFinale=Story.finale;
Story.finale=function(boss){G.flags.ehrein_citizens_fate=flag('evacuation_ordered')?'evacuated':'perished';saveGame();return expansionFinale.call(this,boss);};
