"""Fit the authored cottage plate to the native viewport without stretching its geometry."""
from pathlib import Path
from PIL import Image
import json
R=Path(__file__).resolve().parent
src=R/'assets/generated_sources/witch_hut_interior_source.png';im=Image.open(src).convert('RGB')
# Source floor traced at y768. A uniform quarter scale places it at native y192.
assert im.size==(1672,941),'Source dimensions changed: measure the floor before re-export.'
box=(36,0,1636,900)
plate=im.crop(box).resize((400,225),Image.Resampling.LANCZOS)
plate.save(R/'assets/environment/witch_hut_interior.png')
data={'art_source':'host_image','source':'assets/generated_sources/witch_hut_interior_source.png','prior_source':'assets/generated_sources/witch_hut_interior_initial_source.png','file':'assets/environment/witch_hut_interior.png','canvas':[400,225],'opaque':True,'source_crop':box,'uniform_scale':0.25,'floor_y':192,'interior_door_leaf_approx':{'rect':[21,141,30,51],'note':'Smaller revised doorway; approximate image measurement, final hotspot/fit needs integrator review.'},'actor_positions_suggested':{'hero':[190,192],'witch':[260,192],'enter_spawn':[72,192]},'status':'GENERATED_PLATE; no map, colliders or portal implemented','layering':'Background only. Painted shelves/herbs/hearth are not collision geometry. Add solid floor and independent actors in the new room. Do not replace ehreinC globally.','suggested_room_tiles':{'width':25,'height':14,'tile_size':16,'floor_row':12,'note':'Suggestion matching400px viewport and floor192; room creation remains an integration task.'}}
(R/'assets/environment/witch_hut_interior_manifest.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n');print('Native interior400x225 exported, floor192, uniform quarter scale; not integrated.')
