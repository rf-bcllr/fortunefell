# Fortune Fell — checkpoint lote04

## Como receber os arquivos

Este ZIP único já reúne o lote03 acumulado e as atualizações do lote04 na ordem correta. Basta extrair uma vez; não é necessário baixar ou sobrepor outros lotes.

## Produzido

- Sete identidades com idle: Lúgham, Bruxa, A'Maídhe, Ínys, Niobhán, Halberd e Seyrín.
- 21 portraits128×128 (três expressões por personagem), folhas/aliases e fontes.
- Seis sequências de caminhada dos adultos, candidatas para revisão.
- Seis ações de interação: balança, ervas, escrita, gesto cerimonial, martelo e conselho.
- Ínys puxando o conjunto: seis poses candidatas, sprite separado e guia de grupo.
- Carruagem modular com quatro rodas visíveis, cordão de referência e boneco branco sentado separado.
- Cabana da Bruxa, exterior modular e interior400×225.
- Falas PT/EN, manifestos, fontes e instruções. Assets produzidos não significam integração ou publicação do jogo.

## Falta produzir ou concluir

- Quatro estados coloridos do cabelo do boneco ou máscaras precisas de mechas; pose segurada e ações de brincar/parar/virar com o conjunto.
- Revisão final de ciclos, junções de roda/cordão/assento, timings e contato com a bigorna. Não ativar todos os candidatos automaticamente.
- Llewlás e Llúpin entraram NA FILA: fichas completas, mas sem assets produzidos nesta rodada. Portar também as fichas visuais oficiais do autor para a conta que fará a produção.
- Integração, personagens/portais/mapa da cabana, progressão, saves e publicação pela conta autorizada.

A geração de estados do boneco foi bloqueada por429/usage_limit_reached. Nenhum PNG colorido foi inventado ou marcado como produzido. Não há mais bloqueio de referência para Halberd/Seyrín/carruagem: suas artes-base já foram geradas das três referências reenviadas.

## Ler

- PASSAGEM_OUTRO_CODEX.md: estado atual e limites reais.
- LOTE04.md: novidades, dimensões e instruções de extração.
- FICHAS_IMPLEMENTACAO.md: sete personagens atuais.
- FICHAS_PRINCIPES_EHREIN.md: fila dos dois príncipes e implementação futura.
- FICHA_CABANA.md: cenário e progressão, sem mapa instalado.
- LISTA_PRODUCAO.md: pronto × pendente.
- specs/DOLL_HAIR_IMPLEMENTATION.md e specs/inys-carriage-doll.json: três entidades e estados do boneco. Tinta só no diálogo; só o boneco muda com os anéis.

## Integração

Use native PNGs, não masters grandes como sprites. Respeite pivôs e células dos manifestos. Halberd tem30px de altura-alvo, Seyrín39px e Ínys25px. Ação hammer usa célula48×48; não presumir40×48 para tudo.

Evite colisões de nomes e variantes _up antigas: use chaves exp_artificer_*, exp_oracle_* e seleção explícita das expressões. Para martelar, aproximar o ator da bigorna16/12; sua posição original19/12 é distante demais.

narrative.js permanece rascunho lexical para inserir dentro da IIFE/módulo equivalente. O teste de12 combinações com stubs foi feito em rodada anterior; não é teste de integração. Não ativar a missão sem NPCs acessíveis, migração de save e progressão correta. As flags genéricas de habitantes não devem decidir o destino definitivo de Llewlás.

## Reprocessar e empacotar

Os PNGs já estão exportados; não é obrigatório executar scripts. Se reprocessar tudo, preservar ajustes manuais e seguir: normalize_assets.py → normalize_idle.py → normalize_portraits.py → normalize_walk.py → normalize_actions.py → normalize_hut.py → normalize_hut_interior.py → normalize_lote04.py → normalize_inys_pull.py. A primeira etapa recria o manifesto; passos04 precisam vir no fim.

package_lote04.py empacota só arquivos novos/alterados em relação ao ZIP03. LOTE04-CHECKSUMS.json descreve o delta e a base; CHECKSUMS.json reúne hashes atualizados. Reprocessamento usa Pillow, não gera novas imagens nem consome quota.

Nenhuma publicação foi feita nesta conta. A integração/testes finais ficaram para o outro Codex conforme pedido do autor.
