"""Package generated art and handoff only; exclude experimental game bundles."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent
files=[p for folder in ('assets','specs') for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for name in ('LEIA_PRIMEIRO.md','PASSAGEM_OUTRO_CODEX.md','FICHAS_IMPLEMENTACAO.md','DECISOES_ATUAIS.md','PEDIDO_ORIGINAL.txt','LOTE02.md','LOTE03.md','FICHA_CABANA.md','LISTA_PRODUCAO.md','narrative.js','test_narrative.cjs','normalize_assets.py','normalize_idle.py','normalize_portraits.py','normalize_walk.py','normalize_actions.py','normalize_hut.py','normalize_hut_interior.py','package_assets.py'):
 p=R/name
 if p.is_file():files.append(p)
checks={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(R/'CHECKSUMS.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False)+'\n');files.append(R/'CHECKSUMS.json')
zpath=R/'fortune-fell-assets-passagem-lote03.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(R))
with zipfile.ZipFile(zpath) as z:
 bad=z.testzip()
 if bad:raise RuntimeError('Corrupt ZIP member: '+bad)
print(json.dumps({'file':str(zpath),'files':len(files),'MiB':round(zpath.stat().st_size/1048576,2),'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest()},indent=2))
