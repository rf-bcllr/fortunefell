# Llewlás e Llúpin — fila de produção e implementação futura

**Estado: NA FILA. Nenhum sprite, portrait ou animação destes dois foi produzido nesta etapa.** O pedido atual é registrar as duas fichas oficiais e instruções, e retomar a produção prioritária do lote04 (Seyrín, Halberd, carruagem/boneco). O texto anexado pede implementação completa como objetivo futuro; não amplia a execução atual além da fila.

Fonte lida integralmente: `/workspace/attachments/1bef08cf-f45f-46fb-861d-f5b0a94d19ea/Texto colado.txt`. As duas ilustrações anexadas são referências definitivas de identidade, não modelos a simplesmente reduzir/pixelizar/vetorizar. Produzir pixel art sidescroller consistente com Idhrí, alpha real, âncoras e acessórios estáveis, sem misturar partes de outros designs.

## Contexto e cânone

Filhos de Lúgham, príncipes de Éhrein. Reino medieval decadente, pedra/madeira, chuva e charnecas; cor anil, emblema oficial torre de castelo. Irmãos de personalidades solar/lunar contrastantes, **afetuosos e admiradores um do outro, não rivais**.

Não definir morte definitiva de Llewlás. A flag genérica `ehrein_citizens_fate` do rascunho não pode ser usada para inferir a morte de Llewlás ou fechar seu destino individual; preservar a ressalva explícita mais recente. Não inventar destinos ou revelações dos irmãos.

## Llewlás — O Leão Azul de Éhrein

Nome curto Llew; título EN **The Blue Lion of Éhrein**. Corajoso, carismático, viril, extrovertido, caçador e guerreiro, prefere Charnecas às formalidades da corte. Aliado opcional de Idhrí, nunca substitui o protagonismo dele.

### Contrato visual em fila

Alvo39px visíveis compatível com Idhrí, preservando corpo atlético/musculoso e ficha oficial: cabelo/barbicha louros, armadura assimétrica e parte do peitoral descoberta, ombreira dourada de cabeça de leão, capa/roupa anil, couro marrom/ouro, lança e corno de caça. **Leão é símbolo pessoal; torre continua emblema oficial.** Não transferir trajes/corpo de Idhrí ou outro NPC. Portraits próprios, escala e enquadramento consistentes com o padrão in-game; expressões e contagem de quadros devem ser definidas na produção, não consideradas prontas.

### Local e comportamento futuros

Primeira aparição em `em`, nas Charnecas, caçando perto da área expandida da cabana da Bruxa. **tx/ty ainda pendentes de medição**, sem sobrepor cabana, passagem, inimigos ou checkpoint. Apoio no confronto com Guardião de Éhrein é opcional e condicionado à escolha narrativa.

Estados de comportamento a preparar futuramente: caça autônoma, patrulha, conversa, acompanhamento, travessia de plataformas/obstáculos, detecção de inimigos, combate cooperativo, recuperação de dano e retorno passivo. Não bloquear o jogador, disputar coletáveis ou trivializar o chefe. Pode correr em acompanhamento/combate; essa exceção não libera corrida de protagonista para os demais NPCs.

### Animações na fila

- Passivo: idle com lança, idle alternate ajustando lança, walk natural, talk, laugh.
- Caça: hunting idle atento, hunting walk cauteloso, tracking ajoelhado, spear aim, spear throw, spear thrust, hunting recovery, horn blow.
- Travessia: run, jump start, jump rise, jump apex, fall, land, hard landing, turn, crouch.
- Combate: combat idle, attack01 estocada frontal, attack02 golpe amplo, attack03 estocada descendente, charged attack, aerial attack, dodge, block com lança, hit, knockback, stagger, recovery, exhausted, knockdown temporário.

**Sem animação/estado de morte definitiva.** Lança arremessada deve virar asset/projétil independente, sem duplicação na mão durante o voo. Assets complementares em fila: lança, lança projétil e corno.

### Integração futura e aceitação

Inspecionar infraestrutura real antes de ampliar. Configurar clips, transições, hit/hurtboxes e âncoras conforme o jogo; preservar PT/EN. Validar duas direções sem trocar a identidade/posição dos acessórios, acompanhar sem bloquear, recuperar após dano, lançar sem duplicar lança e coop opcional no chefe. Nenhuma dessas verificações foi executada nesta etapa.

## Llúpin — O Pequeno Lobo de Éhrein

Título EN **The Little Wolf of Éhrein**. Jovem introspectivo, taciturno, reservado, estudioso e diligente, preocupado com responsabilidades e futuro do reino. Melancolia sem rivalidade com o irmão.

### Contrato visual em fila

Alvo39px visíveis, físico esguio, cabelo castanho-escuro até os ombros, olhos escuros, rosto **imberbe**, roupa anil, ornamentos prateados, broche de lua crescente, capa longa ligeiramente desengonçada, couro/animal print/cintos/botas altas. Livro de capa vermelha **sem torre de Éhrein**. Óculos medievais prateados intricados, **sem hastes convencionais**, usados **apenas na leitura**. Idle padrão sem óculos. Não envelhecer, adicionar barba ou transformar em combatente. Portraits próprios seguindo estilo do jogo, não simples redução da ilustração.

### Local futuro

Substituir a entidade genérica `heir` existente em `ec`, tx20/ty12, coordenada confirmada no HTML. Preservar integração com mapa, posição e qualquer referência funcional; renomear identidade/assets adequadamente em vez de duplicar o herdeiro. Não confundir essa posição com Lúgham em ec29/11. O fato de ser fig atual não comprova diálogo novo implementado.

### Treze estados de animação na fila

1. Idle reservado/contemplativo, sem óculos.
2. Idle Alternate ajusta capa/postura.
3. Take Book.
4. Put On Glasses.
5. Open Book.
6. Reading Idle.
7. Turn Page.
8. Close Book.
9. Remove Glasses.
10. Store Book.
11. Yawn discreto.
12. Talk.
13. Sigh.

Ciclo: idle→pega livro→coloca óculos→abre→lê→vira páginas→fecha→retira óculos→guarda→idle. Bocejo/suspiro em intervalos variados; evitar loop curto, exagerado ou mecânico. Ao ser chamado por Idhrí, interromper leitura naturalmente e conversar; depois pode retomar. Não deixar óculos permanentemente no idle ou desaparecer livro/óculos sem transição.

Assets complementares em fila: livro vermelho fechado, livro aberto e óculos prateados. **Sem combate ou movimentação complexa solicitada.**

### Integração futura e aceitação

Reutilizar entidades e diálogo existentes; definir novos estados sem criar infraestrutura especulativa além do necessário. Conferir enquadramento/âncora, ordem livro/óculos, interrupção e retomada, interação PT/EN e ausência de óculos no idle. Nada implementado/testado nesta etapa.

## Instrução de produção para a outra conta

1. Priorizar primeiro lote04 obrigatório atual; estes príncipes entram na fila, não em produção automática.
2. Preservar as duas fichas oficiais recebidas; se não estiverem acessíveis na outra conta, solicitá-las em vez de redesenhar por descrição.
3. Medir sprites/âncoras do projeto atual e aprovar um seed por identidade antes de desdobrar ações. Props independentes e escala comum entre clips.
4. Determinar frames, dimensões e timing conforme o padrão real e a amplitude das ações;39px é altura do corpo, não obrigação de cortar lança/capa/gesto numa célula estreita.
5. Produzir sprites/portraits/props e previews; registrar produzido/candidato/aprovado separadamente. Só depois integrar, testar os estados e publicar no site autorizado.
6. Não alegar que a lista extensa de animações foi feita por existir esta ficha ou um seed.
