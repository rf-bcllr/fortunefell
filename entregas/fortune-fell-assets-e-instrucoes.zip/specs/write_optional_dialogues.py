from pathlib import Path
import json
R=Path(__file__).resolve().parent
D={
'artificer':[
('workshop_return','neutral','Retorno à oficina, antes de abrir upgrades.','O bom de um martelo é que ele nunca pede para eu explicar a solução duas vezes.','The nice thing about a hammer is that it never asks me to explain the solution twice.'),
('bow_resonance','listening','Após uma nova ressonância, sem declarar remoção do anel da Roda.','Myrdhórin mudou de voz. Não, não estou ouvindo coisas. Metal também tem seu jeito de responder.','Myrdhórin has changed its voice. No, I am not hearing things. Metal has its own way of answering.'),
('scale_authorship','reaction','Conversa opcional sobre a balança, sem criar missão.','A balança de Lúgham? Trabalho meu, encomenda de Midhra. Equilibrada à perfeição. O dono é que não vinha incluído na garantia.','Lúgham’s scales? My work, commissioned by Midhra. Perfectly balanced. The owner was not covered by the warranty.')],
'inys':[
('garden_play','reaction','Parada de brincadeira; o boneco está na carruagem.','Hoje ele vai atravessar todos os canteiros sem pisar nas flores. É a parte mais difícil da aventura!','Today he will cross every flower bed without stepping on the flowers. That is the hardest part of the adventure!'),
('doll_streaks','listening','Depois de o boneco ganhar mechas correspondentes às ressonâncias reais.','Ele também precisava ficar com o cabelo bonito. Para as aventuras, eu digo!','He needed pretty hair too. For the adventures, I mean!'),
('sibling_return','neutral','Retorno aos jardins; sem sugerir resultado específico da evacuação.','Você voltou! Eu guardei seu lugar. O de verdade, não o do boneco.','You came back! I saved your place. Your real one, not the doll’s.')],
'queen':[
('court_return','neutral','Retorno à corte, fora do diálogo obrigatório de autorização.','Uma audiência pode terminar. O que foi dito nela costuma demorar mais a sair da sala.','An audience may end. What was said in it usually takes longer to leave the room.'),
('archives','listening','Pergunta opcional sobre os arquivos, sem inventar fato histórico novo.','Um arquivo guarda tanto o que alguém quis lembrar quanto aquilo que não conseguiu apagar. Leia com cuidado.','An archive keeps both what someone wished to remember and what they could not erase. Read carefully.'),
('counsel','reaction','Conversa diplomática; sem insinuar cumplicidade ou antagonismo.','Ouvir um conselho não o dispensa de escolher, Idhrí. Nem a mim.','Hearing counsel does not spare you from choosing, Idhrí. Nor does it spare me.')],
'oracle':[
('greeting','neutral','Apresentação gentil; não revelar natureza divina nem rosto sob o capuz.','Sente-se por um momento. Até quem atravessa pontes precisa encontrar chão para os próprios pensamentos.','Rest for a moment. Even those who cross bridges need ground beneath their thoughts.'),
('uncertainty','listening','Pergunta sobre uma profecia; sem afirmar poderes novos ou causalidade.','Uma visão não traz todas as margens desenhadas. Há quem veja uma partida; há quem veja aquilo que ficou para trás.','A vision does not show every shore. Some see a departure; others see what was left behind.'),
('stay_counsel','reaction','Consulta oficial de Lúgham: defender permanência de forma enigmática.','Diga ao rei que não desfaça o coração de Éhrein antes de tentar ampará-lo. Que seu povo permaneça junto à Roda.','Tell the king not to scatter Éhrein’s heart before trying to sustain it. Let his people remain beside the Wheel.')],
'governor':[
('council_return','neutral','Retorno ao Conselho; sem impor escolhas do jogador.','Escutar leva tempo. Decidir sem escutar costuma custar ainda mais.','Listening takes time. Deciding without listening usually costs even more.'),
('notebook','listening','Durante a ação de escrever; o caderno não é objeto coletável.','Anoto as objeções também. Uma decisão não fica melhor só porque escondemos quem discordou.','I write down the objections too. A decision does not improve just because we hide those who disagreed.'),
('responsibility','reaction','Conversa política opcional, sem inventar evento futuro de refugiados.','Não prometo que todos sairão satisfeitos desta mesa. Prometo que ninguém precisa de uma coroa para ser ouvido.','I cannot promise everyone will leave this table satisfied. I promise that no one needs a crown to be heard.')],
'king':[
('small_choice','neutral','Conversa opcional antes da crise decisiva; não abrir submenu de evacuação aqui.','Às vezes penso em guardar a balança. Mas então preciso decidir em qual gaveta.','Sometimes I think of putting the scales away. But then I must decide which drawer to use.'),
('scales','listening','Ao examinar a balança; não transformar item em sistema jogável.','Se eu pudesse pôr uma consequência em cada prato... Não. Também haveria a consequência de ter escolhido os pratos errados.','If I could place a consequence in each pan... No. There would still be the consequence of choosing the wrong pans.'),
('key_given','reaction','Chave já recebida; a decisão continua em outra interação, sem autoescolha.','A chave coube na vossa mão com tanta facilidade. Quisera eu que a decisão coubesse na minha.','The key fitted your hand so easily. I wish the decision would fit mine.')],
'hag':[
('herbs','reaction','Conversa opcional durante manipulação de ervas; não criar cura, receita ou coleta.','Essa aqui amarga. Não faça essa cara: nem tudo que faz bem se esforça para agradar.','This one is bitter. Do not make that face: not everything good for you tries to please.'),
('counsel','neutral','Contraponto acessível mesmo quando a consulta oficial é Seyrín.','Desconfie de conselho que deixa a cabeça leve demais. Pode ser que alguém tenha tirado a pergunta de dentro dela.','Distrust counsel that makes your head feel too light. Someone may have taken the question out of it.'),
('seyrin_words','listening','Pergunta opcional sobre Seyrín; sem revelar passado ou natureza divina.','Não confie nas palavras de Seyrín só porque elas soam como destino. Palavras também sabem vestir roupa de cerimônia.','Do not trust Seyrín’s words merely because they sound like fate. Words know how to wear ceremonial robes too.')]
}
entries=[]
for who,rows in D.items():
 for key,expr,condition,pt,en in rows:entries.append({'id':f'exp_{who}_{key}','speaker':who,'suggested_expression':expr,'condition_note_pt':condition,'pt':pt,'en':en})
(R/'optional-dialogues-lote02.json').write_text(json.dumps({'status':'dialogue drafts for integration; conditions are notes, not executable rules','count':len(entries),'note':'Do not auto-trigger all lines. Preserve mandatory consultation and evacuation generators. The paint-on-hands exchange remains dialogue-only. Portraits for oracle/artificer are still pending.','entries':entries},indent=2,ensure_ascii=False)+'\n')
print(len(entries),'optional PT/EN dialogue entries written.')
