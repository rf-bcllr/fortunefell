# Boneco — completar as mechas sem redesenhar a identidade

O asset produzido é `assets/props/idhri_ragdoll_seated_0.png` (16×20, pivô8/19,12px visíveis). A tentativa de gerar os cinco estados em imagem falhou com429/usage_limit_reached; portanto nenhum PNG colorido foi entregue como pronto.

O integrador pode escolher gerar as quatro variantes restantes a partir deste mesmo master, ou usar uma camada/máscara de mechas sobre o sprite-base. Na segunda opção, a máscara deve ser traçada SOMENTE sobre mechas do cabelo do boneco. Não recolorir rosto, olhos, pele, gola, roupa, carruagem ou Ínys. Preserve contorno e sombreado da mesma arte, em vez de desenhar outro boneco por estado.

| `artHairState(G.rings)` | Visual do boneco |
|---|---|
| idhri_0 | Cabelo branco original |
| idhri_v | Base branca + mecha violeta |
| idhri_o | Base branca + mecha laranja |
| idhri_vo | Primeira mecha violeta, segunda laranja |
| idhri_ov | Primeira mecha laranja, segunda violeta |

Reutilizar RING_COL do jogo: tempo#b98cf5/sombra#7d45c4, perc#ffc27a/sombra#f4882f. A ordem de aquisição deve vir da função existente, não de ordenação alfabética. Se houver espelhamento da carruagem/boneco, espelhar a arte sem trocar o estado lógicovo/ov.

Nunca dar poderes reais ao boneco. A mudança é uma brincadeira de Ínys e seu comentário de “tinta mágica”; as manchas nas mãos só existem no diálogo. Não adicionar tintas ao sprite ou aos portraits dela.

A pose segurada/pendurada também não foi produzida. É possível usar provisoriamente a mesma pose sentada como objeto em sua mão, mas isso não constitui uma nova animação de manipulação: registrar como adaptação e revisar o contato antes de chamar a personagem concluída.
