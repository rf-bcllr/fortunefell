# Decisões atuais do autor — prevalecem sobre o pedido colado quando divergirem

1. Escopo desta sessão passou a ser produção de assets e passagem; implementação, ajustes e publicação podem ser feitos pela outra conta.
2. Preservar o design de cada personagem enviado. Sprites e portraits devem manter a direção artística do jogo. Portraits no tamanho atual, com expressões.
3. Gileád primeiro: ponte Gileád–Éhrein destruída; Lúgham manda consultar a Bruxa. Abre as Charnecas, mas só entrega a chave do Santuário depois da consulta.
4. Gileád depois, ponte intacta: consulta oficial Seyrín antes da chave. A Bruxa pode ser ouvida mesmo sem ser a consulta oficial e adverte contra confiar em Seyrín.
5. Após receber a chave, outra interação com Lúgham permite sugerir evacuação ou não. Se sugerida, ele leva os cidadãos ao reino cuja ponte ainda está de pé. Consequências futuras diferentes conforme destino ficam fora da demo. Sem sugestão de evacuação, os habitantes de Éhrein morrem na queda. Não inventar epílogos futuros.
6. Seyrín aconselha de modo profético/enigmático que Éhrein NÃO seja evacuado, sem revelar a antagonista nem parecer caricaturalmente maligna.
7. Ínys deve puxar ou brincar com sua carruagem, com boneco de Idhrí separado. O boneco acompanha os poderes adquiridos com mechas correspondentes, reutilizando as cores/estados do jogo.
8. Tinta nas mãos de Ínys é APENAS fala. Não pintar mãos, roupa, cabelo ou design de Ínys. Só o boneco muda visualmente conforme os anéis.
9. Documentação precisa permanecer pronta no encerramento, distinguindo produzido, integrado, testado, publicado e pendente.

O arquivo PEDIDO_ORIGINAL.txt é contexto de implementação autorizado pelo pedido do autor, sujeito às correções acima e ao cânone mais recente. Não implementar automaticamente regras antigas conflitantes com a base vigente.

## Adição à fila — príncipes de Éhrein

10. Llewlás e Llúpin são filhos de Lúgham, com designs oficiais nas fichas enviadas. Têm afeto e admiração mútuos, sem rivalidade. Produção/implementação foi adicionada à fila; nenhum asset deles foi produzido no lote04.
11. Llúpin substituirá o herdeiro genérico de ec20/12. Os óculos medievais de prata são exclusivos da leitura, ausentes no idle padrão. Livro vermelho sem torre. Não criar combate complexo para ele.
12. Llewlás será caçador nas Charnecas perto da cabana, em ponto ainda a definir. Acompanhamento/combate cooperativo com Idhrí e ajuda no Guardião serão opcionais conforme escolhas. Não definir morte definitiva nem inferir seu destino a partir de ehrein_citizens_fate.
13. A ficha visual é design de personagem, não sprite pronto: a produção futura precisa de pixel art própria no padrão de Idhrí, não simples redução/vetorização das ilustrações. Leão/lua são motivos pessoais; a torre permanece emblema de Éhrein.
