# Fortune Fell — fichas checkpoint04 parcial/exportado; integração pendente

Escopo final reforçado pelo autor: entregar **assets e instruções**, deixando implementação/publicação para a outra conta. Este documento contém propostas de falas compatíveis com o pedido atual; não significa que já estejam todas no jogo. As falas implementadas no rascunho são as que constam em `narrative.js`.

Assets produzidos para sete personagens após lote04: idle, portraits e candidatos de movimento/ações. Carruagem, rodas, cordref e boneco-base independentes também exportados; estados coloridos/held/play de Ínys continuam pendentes. Candidatos não são aprovação em engine. Não substituir designs aprovados por placeholders.

## Contrato comum dos assets disponíveis

- Sheets: `assets/native/{king,hag,governor,inys,queen}_idle.png`, 160×48, quatro células 40×48.
- Pivô: (20,47); adultos 39 px visíveis, Ínys 25 px.
- Portraits iniciais: `assets/native/portrait_{id}.png`, 128×128.
- Variações de expressão solicitadas pelo autor: **neutro, escuta e reação contextual adequada** para cada uma das cinco identidades. A geração de 3 colunas × 5 linhas usou atlas de identidade e portraits existentes queen/artificer como referência de estilo/enquadramento. Produção concluída no fechamento: quinze PNGs individuais e cinco folhas; ver inventário final abaixo. Manter cabeça/ombros com escala consistente dentro de cada linha/personagem e compatível com o padrão artístico in-game.
- Timing sugerido do manifesto: 350/220/180/220 ms.
- Carregar em `ART_PNG` + `ASSET_SPEC` antes de `Art.preload`; usar `Art.cell(assetId,frame,40,48,4)` no mesmo escopo IIFE.
- Rever em 1×, cenário e diálogo antes de aprovar. QA estrutural não prova qualidade artística. Preview experimental não validado visualmente para king: mesmo após asserts passarem, screenshot ainda mostrou portrait antigo. Não usar os asserts para alegar diálogo/portrait aprovado. Por instrução atual do autor, parar investigação browser e deixar integração/testes com a outra conta; priorizar produção e inventário dos assets.

## Halberd — Artífice Real

**Identidade:** Dvern de Airgeád, branco de cabelo/barba, robusto, tranças, óculos na testa, avental e engrenagem com martelos cruzados. Seu símbolo pessoal não substitui a bigorna de Airgeád.

**Arte lote04 produzida:** artificer_idle160×48/4quadros40×48/30px,pivô20/47; portraits128×128×3 e folha384×128; walk240×48/6 e hammer192×48/4×48,pivô24/47 como candidatos. Preservar o design enviado. Criar idle de trabalho, martelar, examinar ferramenta e riso; só idle não deve ser descrito como essas ações concluídas. Portrait deve seguir o padrão in-game.

**Posição existente conferida pelo agente principal:** mapa `workshop`, tx19/ty12. Reutilizar NPC `artificer`; nome exibido Halberd. Manter `openWorkshop()`, preços, ouro, pepitas e limites existentes.

**Comportamento/estados:** primeira visita apresenta o ofício; retornos reagem a ouro e upgrades; balança de Lúgham rende comentário posterior. Não adicionar tecnologia eletrônica. Evolução visual da oficina deve depender de investimentos reais, sem reinventar economia.

**Falas PT-BR / EN propostas:**

- “Halberd, Artífice Real. Se a peça range, eu escuto. Se não range, também desconfio.” / “Halberd, Royal Artificer. If a part creaks, I listen. If it does not, I get suspicious too.”
- “Myrdhórin não segue as regras da minha oficina. É a primeira ferramenta que me olha como aprendiz.” / “Myrdhórin follows none of my workshop’s rules. It is the first tool that makes me feel like an apprentice.”
- “A balança de Lúgham? Obra minha, encomenda de Midhra. Garanto a precisão dos pratos, não das decisões.” / “Lúgham’s scales? My work, commissioned by Midhra. I guarantee the pans’ precision, not the decisions.”
- “Pepitas na bancada. Faíscas para trás. Vamos trabalhar.” / “Nuggets on the bench. Sparks behind us. Let us work.”

**Aceitação:** conversa abre a oficina original; recursos descontados uma vez; emblema pessoal correto; ferramenta/gesto não invade o chão nem cobre Idhrí.

## Ínys — Princesa de Myriadd

**Identidade:** criança branca pequena, cabelos brancos cacheados com rosado, olhos iridescentes, traje verde/branco/dourado. Não usar proporções adultas.

**Arte disponível:** `inys_idle.png`, `portrait_inys.png`, seed e GIF. **Lote04:** corpo carruagem64×40/pivô32/39, quatro rodas separadas, cordref16×8 e boneco-base branco sentado16×20/pivô8/19 exportados; pull240×48/6 candidato. Estados coloridos/held/play específicos continuam pendentes. Design da carruagem: três rodas de cada lado e uma dianteira central; quatro visíveis em lateral, estandarte branco, madeira com dourado/branco/roxo. Não improvisar carro de outra geometria.

**Local:** mapa `garden` confirmado. Piso base ty13; spawns west[6,13], palace[36,13], east[66,13]. **tx de implantação ainda não medido/aprovado**: escolher trecho livre após conferir props e NPCs atuais. Não afirmar posição final. Evitar portas e a fonte; não atravessar o gate leste antes da progressão.

**Comportamento/estados:** passeio lento restrito a uma faixa segura, pausa perto do boneco; conversa opcional não bloqueia campanha. Três entidades independentes obrigatórias: Ínys, carruagem e boneco. Carruagem/boneco devem acompanhar por âncoras, não ser fundidos ao sprite. No passeio, Ínys puxa o cordão dourado e as rodas giram de acordo com o deslocamento; ao pausar, solta/afrouxa o cordão e pode brincar com o boneco, sentar e gesticular. O boneco permanece sentado na carruagem quando transportado, sem flutuar ou deslizar em relação ao assento. Alterar mechas do boneco somente para anéis que o jogador realmente ressoou. Na demo, respeitar Tempo e Percepção e obter as cores do mapeamento real de `G.rings` / `RING_COL`; não inventar correspondências ou antecipar poderes. A tinta nas mãos é **somente diálogo**, conforme correção explícita do autor. Não modificar o visual de Ínys por causa da tinta. Apenas o boneco muda visualmente conforme os anéis realmente adquiridos. Não mover Ínys com run de Idhrí.

**Falas PT-BR / EN propostas:**

- Ínys: “Não pise no canteiro! Esse é um reino inteiro.” / “Do not step on the flowerbed! That is a whole kingdom.”
- Idhrí: “E quem governa aquele vaso?” / “And who rules that flowerpot?”
- Ínys: “Eu. Mas só até você voltar.” / “I do. But only until you come back.”
- Idhrí: “Ínys, você pintou o cabelo dele?” / “Ínys, did you paint his hair?”
- Ínys: “Não!” / “No!”
- Idhrí: “Então por que está com tinta nas mãos?” / “Then why is there paint on your hands?”
- Ínys: “É tinta mágica!” / “It is magic paint!”
- Após notícias de evacuação: “Se precisarem de um reino por um tempo, meus canteiros têm espaço.” / “If they need a kingdom for a while, my flowerbeds have room.”

**Pendência obrigatória:** produzir carruagem, boneco e movimentos de puxar/brincar; o idle isolado de Ínys não satisfaz a entrega completa deste personagem.

**Aceitação:** tamanho infantil preservado; carruagem segue no piso sem saltar; interação não desaparece por movimento; nenhuma mecha representa poder ainda não adquirido.

## Niobhán — Rainha de Gileád

**Identidade:** rainha negra, rosto angular, tranças com ouro, violeta/creme e cetro de ampulheta. Preservar autoridade e ambiguidade sem sugerir automaticamente cumplicidade com Seyrín.

**Arte disponível:** `queen_idle.png`, `portrait_queen.png`, seed e GIF.

**Posição existente:** mapa `gc`, tx29/ty11, `id/look: queen`, face -1. Coordenada conferida no HTML original. Não deslocar pódio, friso, trono ou colisão.

**Comportamento/estados:** preservar audiência que concede `auth_gilead` e `credential_gilead`; manter reações a `g_won`, `tone_queen` e ordem de visita. Acrescentar cortesia e política sem alterar requisitos do Santuário.

**Falas PT-BR / EN propostas:**

- “Minhas antecessoras deixaram arquivos, não respostas prontas. É uma diferença que os visitantes costumam esquecer.” / “My predecessors left records, not ready-made answers. Visitors often forget the difference.”
- “Seyrín encontrará tempo para ouvi-lo. Eu encontrarei tempo para ouvir o que escolheu fazer.” / “Seyrín will find time to hear you. I will find time to hear what you chose to do.”
- Se refugiados destinados a Gileád: “Abriremos abrigo. Depois discutiremos as contas. Essa ordem importa.” / “We will open shelters. Then we will discuss the cost. That order matters.”

**Aceitação:** poder real de Gileád e credenciais continuam funcionando nas duas ordens; sem revelação de vilania/cumplicidade; portrait não altera tom de pele ou identidade.

## Seyrín — Oráculo de Gileád

**Identidade:** adulta elegante, capuz vinho, sombra nos olhos, orelhas cobertas, cabelo branco, creme/dourado/violeta. Não revelar a natureza secreta.

**Arte lote04 produzida:** oracle_idle160×48/4quadros40×48/39px,pivô20/47; portraits128×128×3 e folha384×128; walk240×48/6 e counsel160×48/4 como candidatos. Não usar queen ou hag como substituta. Criar portrait compatível e idle/gesto delicado; nenhuma animação divina explícita na demo.

**Local:** Gileád, próximo à corte, **mapa/tx/ty exatos a definir após conferir circulação**. Uma colocação em `gc` é opção de integração, não posição já aprovada. Deve permanecer acessível para quem entra vindo da ponte intacta. Registrar `id/look: oracle`, `NAMES.oracle`, `Talk.oracle`.

**Comportamento/estados:** conversa disponível antes/depois da missão; `consulted_oracle` só satisfaz a chave quando `consultation_required === 'oracle'`. Não transformar consulta errada em bloqueio permanente. Em qualquer estado, evitar acusações ou pistas óbvias da identidade secreta.

**Falas PT-BR / EN já no rascunho:**

- “Nem toda salvação toma a forma de uma partida. Às vezes, a raiz sustenta o que o vento deseja levar.” / “Not every salvation takes the shape of departure. Sometimes the root sustains what the wind would carry away.”
- “Dizei a Lúgham: que Éhrein conserve seu povo junto à Roda. Uma casa abandonada já começou a cair.” / “Tell Lúgham: let Éhrein keep its people beside the Wheel. An abandoned home has already begun to fall.”

**Aceitação:** consulta registrada, caminho de retorno viável, nenhuma chave antes do retorno ao rei, conselho contrário à evacuação mas sem linguagem caricaturalmente maligna.

## A'Maídhe — Líder eleita do Conselho de Iomadh

**Identidade:** canina negra de orelhas longas caídas, marcas brancas discretas, olhos castanhos, monóculo e traje outonal com olho. Sem coroa/trono.

**Arte disponível:** `governor_idle.png`, `portrait_governor.png`, seed e GIF.

**Posição existente:** mapa `ic`, tx22/ty12, `id/look: governor`, face -1, entre membros do conselho. Coordenada conferida no HTML. Preservar mesa e diversidade das entidades atuais.

**Comportamento/estados:** manter votação, `auth_iomadh`, `credential_iomadh`, `tone_council` e `i_won`. Acrescentar comentários posteriores sem tirar a palavra de councilA/B. Ação de escrita já existe como candidato governor_write, sem aprovação em engine; ajustar monóculo específico continua pendente, não implícito no idle.

**Falas PT-BR / EN propostas:**

- “Meu lugar nesta mesa foi emprestado pela confiança dos outros. Preciso merecê-lo todos os dias.” / “My place at this table was lent by other people’s trust. I must earn it every day.”
- “Escutar não impede a urgência. Impede que a urgência fale por todos.” / “Listening does not stop urgency. It stops urgency from speaking for everyone.”
- Se refugiados destinados a Iomadh: “Primeiro abrigo e comida. Cada povo terá voz na forma de acolher quem chega.” / “Shelter and food first. Every people will have a voice in how we welcome those who arrive.”

**Aceitação:** votação preservada; sem estética monárquica; monóculo e marcas claras legíveis em 1×; diálogo não exclui os outros conselheiros.

## Lúgham — Rei de Éhrein

**Identidade:** meia-idade, magro, castanho, bigode/barbicha grisalha, sem óculos; anil/couro/peles, coroa simples e balança dourada.

**Arte disponível:** `king_idle.png`, `portrait_king.png`, seed e GIF. Ponderar/examinar balança são gestos futuros a revisar; o idle não comprova animação funcional da balança.

**Posição existente:** mapa `ec`, tx29/ty11, `id/look: king`, face -1. Coordenada conferida no HTML; preservar pódio.

**Fluxo exato:**

1. Primeiro encontro abre `moors_open`, não `auth_ehrein`.
2. `cut_gilead` verdadeiro → consulta oficial Bruxa; falso → Seyrín.
3. Outra consulta pode dar pistas, mas não entrega chave.
4. Consulta correta + retorno ao rei → `auth_ehrein`.
5. Outra interação depois da chave → evacuar/ficar/adiar.
6. Evacuar: destino `iomadh` se ponte Gileád caiu, senão `gilead`. Adiar não fixa escolha. Não sugerir/recusar mantém cidadãos no reino; na queda, `perished`.
7. Fora da demo, consumir destino para consequências futuras sem inventá-las agora.

**Falas PT-BR / EN já no rascunho:**

- “Uma balança feita por Halberd, presente de vosso pai. Pesa metal com perfeição. Decisões, nem tanto.” / “Scales made by Halberd, a gift from your father. They weigh metal perfectly. Decisions, less so.”
- “Tendes a chave do Santuário. E eu, mais uma decisão a pesar. Falai comigo antes de partir, se tiverdes conselho para meu povo.” / “You have the Shrine key. And I have another decision to weigh. Speak to me before leaving if you have counsel for my people.”
- Escolhas: “Evacue o reino pela ponte que ainda está de pé.” / “Evacuate through the bridge that still stands.”; “Não recomendo a evacuação.” / “I do not recommend evacuation.”; “Preciso pensar.” / “I need to think.”

**Aceitação:** 12 casos isolados já passam; falta executar no jogo real, save/load real, topologia, diálogo e consequência visível. Não confundir flags com evacuação encenada.

## Velha Bruxa das Charnecas

**Identidade:** idosa curvada, cabelos grisalhos volumosos, cajado retorcido, amuletos/ervas e tecido rústico. Não confirmar raça, nome ou passado em exposição.

**Arte disponível:** `hag_idle.png`, `portrait_hag.png`, seed e GIF. Walk com cajado e ação ervas existem como candidatos, sem aprovação em engine; rituais adicionais não foram produzidos.

**Local:** mapa `em` (Charnecas) confirmado; **cabana e tx/ty finais ainda a definir**. O começo de em tem caminho de volta em tx2 e piso17, mas isso não é aprovação para colocar cabana sobre porta, inimigo ou prop. Medir uma área segura no projeto real. Usar `id/look: hag` com interação sempre disponível, inclusive quando Seyrín é a consulta oficial.

**Comportamento/estados:** não hostil, conversa opcional antes da missão, crítica a Seyrín disponível mesmo sem consulta oficial; só `consulted_hag` satisfaz o requisito quando ele foi escolhido pela topologia. Não revelar motivos de sua saída de Gileád.

**Falas PT-BR / EN já no rascunho:**

- “Seyrín tem palavras macias. Bom para travesseiro; ruim para enxergar onde se pisa. Não confieis nelas só porque soam como destino.” / “Seyrín has soft words. Good for a pillow; poor for seeing where you step. Do not trust them merely because they sound like fate.”
- “Levai ao rei o que ouvistes, não uma certeza emprestada. Ainda há uma ponte. Pedras não precisam dela; gente precisa.” / “Take the king what you heard, not borrowed certainty. There is still a bridge. Stones have no need of it; people do.”

**Aceitação:** caminho seguro ida/volta sem poderes não obtidos; pode ouvir o contraponto mesmo na rota de Seyrín; não libera Santuário sozinha; retrato mantém os traços enviados.

## Checklist final da outra conta

1. Conciliar base mais recente com o HTML original entregue; não voltar a versão antiga.
2. Integrar os sete conjuntos existentes e props-base do lote04; produzir os quatro cabelos coloridos/held/play faltantes do boneco/Ínys e revisar candidatos antes de ativar.
3. Colocar entidades faltantes e atualizar objetivos/mapas/checkpoints de avaliação para a nova consulta.
4. Traduzir todo texto novo pelo sistema TR atual, mantendo nomes e acentos.
5. Testar progressão, save/load, ambas as ordens de reino, três escolhas de evacuação e final. Os testes isolados são apoio, não substituto.
6. Publicar no site existente pela conta autorizada e registrar URL, hash e teste pós-publicação na passagem.


## Lote02 — estado atual consolidado

### Ações candidatas produzidas

`assets/action_candidates/{king_weigh,hag_herbs,governor_write,queen_ceremonial}.png`: 160×48, quatro quadros 40×48, pivô (20,47), GIFs de revisão. Timings: king 350 ms, hag 260 ms, governor 500 ms, queen 300 ms. Fonte `assets/generated_sources/four_adults_actions_source.png`; review `assets/actions-review.png`; script `normalize_actions.py`; manifesto `interaction_candidate`.

Todas são **candidatas sem aprovação em engine**. `king_weigh` foi corrigido na fonte final `assets/generated_sources/king_weigh_corrected_source.png` (2172×724,RGBA,alpha0–255):balança abaixada na mesma mão em quatro poses, só cabeça/mão livre variam. `normalize_actions.py` foi rerodado e manifesto atualizado. O erro evidente de troca de mão foi resolvido, mas **a ação segue candidata sem aprovação em engine**.

### Falas opcionais prontas como especificação

`specs/optional-dialogues-lote02.json`: 21 falas PT/EN, três por personagem, expressões sugeridas neutral/listening/reaction. Condições são notas humanas, não gatilhos executáveis. Gerador `specs/write_optional_dialogues.py`. Não substitui consultas/chave/evacuação.

### Ínys — especificação, não asset pronto

`specs/inys-carriage-doll.json`: três entidades, estados pull/stop/play/talk/turn, cordão por âncoras e rodas por deslocamento. Tinta só diálogo; não alterar visual de Ínys. Boneco usa artHairState: none→idhri_0, tempo→idhri_v, perc→idhri_o, tempo_then_perc→idhri_vo, perc_then_tempo→idhri_ov. RING_COL Tempo #b98cf5/#7d45c4; Percepção #ffc27a/#f4882f. O alvo antigo carruagem56×40 foi substituído pelo asset exportado64×40; boneco-base16×20 exportado, txnull. Estados coloridos/held/play e integração seguem pendentes obrigatórios.

### Pacotes

`fortune-fell-assets-passagem-lote01.zip` preserva a entrega anterior (9,72 MiB informados). Acumulado `fortune-fell-assets-passagem-lote02.zip` reúne lote01 e novas ações candidatas, falas, specs e documentação. Incluir `LOTE02.md`, `package_assets.py`, `specs/*.json` e scripts das specs. O nome principal `fortune-fell-assets-passagem.zip` pode servir como alias atualizado, conforme empacotador. Conferir arquivos/hashes no fechamento. Integração, testes em engine e publicação ficam com a outra conta.

## Âncora nativa para a integração

As células novas são40×48 com pivô(20,47), não30×40. Exemplo de desenho sem mudar a colisão: `ctx.drawImage(frame, Math.round(npc.x - G.cam.x - 20), Math.round(npc.y - G.cam.y - 47))`. O integrador deve usar esse pivô e revisar o apoio no piso, sem esticar a arte. O preview de 3× serve para inspecionar pixels, não indica escala de exibição no jogo.


## Fechamento lote04

Sete identidades agora têm idle/portraits produzidos; as animações candidatas ainda precisam revisão pela conta integradora. Halberd novo é branco/barbado30px, não o ruivo antigo. Em workshop, bigorna16/12 e ator19/12: mover o ator junto da bigorna antes da ação para não martelar à distância.

Carruagem/rodas/cordref/boneco-base e pull de Ínys estão exportados, mas o pull ainda tem fragmento de cordão na mão e precisa junção com engate. Assento27/28,engate42/31; usar assets/props/inys_carriage_manifest.json. Somente boneco branco sentado existe; quatro cores, held e play novo pendentes por quota429 na tentativa5hair. Ínys sem redesign/tinta visual.

Fontes lote04_* em generated_sources; normalize_lote04.py e normalize_inys_pull.py. Pacote04 incremental deve ser extraído SOBRE lote03, não usado isoladamente. Não houve implementação/teste de jogo nesta etapa. Príncipes Llewlás/Llúpin apenas na fila em FICHAS_PRINCIPES_EHREIN.md.

Aplicação do checkpoint04: pacote incremental SOBRE lote03, usando LEIA_PRIMEIRO.md/LOTE04.md e package_lote04.py. `specs/DOLL_HAIR_IMPLEMENTATION.md` contém alternativa futura por máscara/camadas; PNGs coloridos não produzidos. Sem geração em andamento após erro429. Pendências atuais: cores/held/play/stop/talk/turn Ínys, revisão dos candidatos, integração/testes/publicação outra conta. Príncipes seguem apenas na fila.
