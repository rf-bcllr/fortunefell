# Fortune Fell — passagem checkpoint04 parcial/exportado; integração pendente

Atualizado em 17 de novembro de 2026. **Escopo atual: produzir assets e instruções; integração, testes em engine e publicação ficam com a outra conta.** Ponytail full orienta o trabalho. O autor pediu não gastar a etapa atual investigando implementação/browser.

## Pendências obrigatórias atuais

- Estados coloridos do boneco (idhri_v/o/vo/ov), boneco held e nova animação play de Ínys: **não produzidos**; geração dos cinco estados falhou com HTTP429/usage_limit_reached. Não repetir até reset/liberação; não prometer horário de retomada.
- Pull de Ínys, walks e ações especiais agora possuem candidatos, mas exigem revisão de apoio/loop/props e junção do cordão. Idle isolado não encerra o comportamento completo.
- Integração do conjunto, estados, diálogos, topologia, saves e publicação ficam com a outra conta.

**Seyrín e Halberd já têm assets nativos no lote04**, conforme inventário abaixo; não manter o antigo bloqueio de referência. As três refs atuais reenviadas resolveram acesso. Halberd segue o design branco/barbado atual, não o artificer ruivo antigo.

## Estado consolidado: pronto × pendente

| Item | Estado atual |
|---|---|
| Lúgham, Bruxa, A'Maídhe, Ínys, Niobhán — idle | Cinco sheets 160×48, quatro poses 40×48, prontas como assets para revisão |
| Portraits desses cinco | Quinze PNGs128×128 (neutral/listening/reaction), cinco folhas384×128 e aliases neutros produzidos |
| Walks de king/hag/governor/queen | Quatro candidatos240×48/seis quadros, REVIEW REQUIRED; não ativar sem revisão |
| Ações king_weigh/hag_herbs/governor_write/queen_ceremonial | Quatro candidatos160×48/quatro quadros produzidos; fonte king corrigida e reexportada, revisão em engine pendente |
| Seyrín e Halberd — arte nova | Lote04: idle4, portraits3 cada, walks6 candidatos e ações4 candidatas exportados |
| Carruagem, boneco e puxar/brincar de Ínys | Lote04: carruagem/4rodas/cordref/boneco-base e pull6 candidato exportados; cores/held/play pendentes |
| Sete fichas de diálogo/posição/behaviour | Prontas em FICHAS_IMPLEMENTACAO.md |
| Falas opcionais lote02 | 21 falas PT/EN prontas como especificação; gatilhos não implementados |
| Consulta/chave/evacuação | Rascunho narrative.js, 12 testes isolados PASS; integração jogável pendente |
| Cabana da Bruxa — lote03 | Exterior modular e interior produzidos/normalizados; posição/mapa/colliders pendentes |
| Publicação | Não feita; sem rota suportada para atualizar o site nesta conta |

## Prioridades explícitas do autor

Preservar os sete designs enviados e o padrão artístico dos portraits in-game. Não usar conceitos grandes como sprites de movimentação. Não reutilizar outro personagem como substituto. Apenas o boneco de Ínys muda visualmente pelos anéis; tinta nas mãos é **somente diálogo**, sem mudança visual nela.

Regras de Éhrein:

1. Gileád primeiro/ponte destruída → Lúgham envia à Bruxa. Abre Charnecas, não Santuário.
2. Gileád depois/ponte intacta → consulta Seyrín antes de entregar chave.
3. Consulta correta + retorno ao rei → chave. Nova interação posterior permite evacuar/ficar/adiar.
4. Evacuação usa a ponte restante: Iomadh se Gileád caiu, Gileád caso contrário. Guardar destino para repercussões fora da demo, sem inventá-las agora.
5. Sem sugestão de evacuar, todos os habitantes de Éhrein morrem na queda. Essa decisão recente prevalece sobre o texto antigo que deixava destino pessoal em aberto.
6. Seyrín aconselha enigmaticamente contra a evacuação. Bruxa desaconselha confiar nela mesmo sem ser consulta oficial. Não revelar a natureza secreta de Seyrín.

Texto integral do escopo recebido: `/workspace/attachments/1be66bde-6583-4b9c-92d7-9df7a22f4a9f/Texto colado.txt`. Correções explícitas mais recentes do autor prevalecem.

## Arquivos de entrega

- `assets/native/{king,hag,governor,inys,queen}_idle.png`:160×48, quatro células40×48; pivô20/47. Adultos39px visíveis, Ínys25px. Durações350/220/180/220ms.
- `assets/native/portrait_{id}_{neutral,listening,reaction}.png`:128×128; `portrait_{id}_expressions.png`:384×128; `portrait_{id}.png`:alias neutro.
- Seeds e GIFs em assets/native; revisão `assets/native-review.png` e `assets/portraits-review.png`.
- `assets/walk_candidates/{king,hag,governor,queen}_walk_candidate.png`:240×48/seis quadros, com GIFs. Estado REVIEW REQUIRED: alternância, apoio, slide e props não aprovados. Ínys não está nessa sheet.
- `assets/action_candidates/{king_weigh,hag_herbs,governor_write,queen_ceremonial}.png`:160×48/quatro quadros, com GIFs; pivô20/47. Timings king350/hag260/governor500/queen300ms. Manifesto interaction_candidate; review `assets/actions-review.png`; normalização `normalize_actions.py`.
- Fontes em `assets/generated_sources/`: characters_reference_derived_atlas.png, five_characters_idle_source.png, portrait_expressions_source.png, four_adults_walk_source.png e four_adults_actions_source.png.
- `assets/manifest.json` e `assets/idle-qa.json`: dimensões, pivôs, quatro quadros distintos/alpha binário/escala única por sequência. QA estrutural não prova animação correta.
- `FICHAS_IMPLEMENTACAO.md`: sete identidades, posições verificadas, falas PT/EN, estados e critérios de integração.
- `specs/optional-dialogues-lote02.json`:21 falas PT/EN, três por personagem, suggested_expression neutral/listening/reaction. Condições são notas humanas, não código. Gerador `specs/write_optional_dialogues.py`.
- `specs/inys-carriage-doll.json`: especificação obrigatória de três entidades, não assets prontos.
- `narrative.js` e `test_narrative.cjs`: módulo em rascunho e testes isolados, não versão final jogável.

### king_weigh — fonte corrigida e reexportada

Fonte final `assets/generated_sources/king_weigh_corrected_source.png`:2172×724,RGBA com alpha0–255. Balança abaixada mantida na mesma mão nas quatro poses; só cabeça/mão livre variam. O erro evidente de troca de mão foi corrigido na fonte. `normalize_actions.py` foi rerodado e o manifesto king atualizado. **A ação permanece candidata para revisão em engine; não equivale a integração/aprovação final.** As outras três ações também são candidatas exportadas, sem teste em engine.

## Ínys — detalhes obrigatórios

Três entidades independentes e integradas: Ínys, carruagem e boneco. Sete rodas totais: três por lado e uma central dianteira; quatro visíveis em lateral. Cordão dourado, boneco sentado, estandarte branco. Movimento pull/stop/play/talk/turn, rodas por deslocamento e cordão por âncoras. Idle isolado não cumpre o pedido.

Estados reais do boneco: none→idhri_0; tempo→idhri_v; perc→idhri_o; tempo_then_perc→idhri_vo; perc_then_tempo→idhri_ov. Cores RING_COL Tempo #b98cf5/#7d45c4, Percepção #ffc27a/#f4882f. Não antecipar poderes. Carruagem56×40/boneco16×20 são dimensões sugeridas, não aprovadas; tx permanece null. Tinta apenas nas falas, não no visual de Ínys.

## Integração exata para a outra conta

1. Conciliar com a base mais recente, preservando mudanças da outra conta. Não substituir um projeto novo pelo HTML de trabalho antigo.
2. Carregar PNGs em ART_PNG e registrar ASSET_SPEC **antes de Art.preload**. Usar `Art.cell(assetId,frame,40,48,4)` nos idle, pivô20/47 e escala única. Walks seis quadros são candidatos separados.
3. Overrides precisam do mesmo escopo IIFE onde Art/npcSprite/NAMES/Talk/G existem; script externo solto não acessa esses símbolos. Manter fallback original quando asset ausente.
4. **Portrait loader:** FA_dialoguePortrait prefere `*_up`; novo PNG base pode não aparecer. Atualizar variante correspondente ou selecionar explicitamente chaves novas como `exp_portrait_{id}`. Conferir imagem realmente renderizada, sem esticar cabeça/rosto. As três expressões compartilham escala por personagem.
5. Posições existentes verificadas: workshop19/12 Halberd/artificer; gc29/11 Niobhán/queen; ic22/12 A'Maídhe/governor; ec29/11 Lúgham/king. Ínys usa garden, piso13, mas tx final não aprovado. Seyrín/Bruxa precisam pontos seguros definidos e entidades oracle/hag próprias.
6. narrative.js cria falas/flags, mas não insere NPCs oracle/hag; sem isso a consulta é inacessível. Preservar topologia da ponte restante e impedir em→ed antes da chave. Atualizar objetivo, checkpoints e saves antigos que já tenham auth_ehrein.
7. Flags escritas: moors_open, consultation_requested, consultation_required, consulted_oracle, consulted_hag, evacuation_decided, evacuation_ordered, evacuation_destination, ehrein_citizens_fate. A evacuação ainda é registro/fala, não cena ou deslocamento de cidadãos.
8. Revisar candidatos visuais em1× e cenário: pés, pivô, silhueta, props, loop, leg alternation, slide. Não ativar candidatos por terem hashes diferentes.
9. Rodar build/sintaxe/validação/solver e testes pertinentes da base real. Provar duas ordens, consulta correta/errada, chave, evacuar/ficar/adiar, save/load real, PT/EN e final. Só então publicar na conta autorizada.

## Testes realmente feitos e limites

- `node --check narrative.js`:PASS.
- `node test_narrative.cjs`:PASS12 combinações (duas rotas×PT/EN×evacuar/ficar/adiar), consulta errada sem chave, chave separada de evacuação, destino e flags serializadas. **Stubs de geradores/save; não jogo real.**
- Base original abriu em Chromium com menu e abertura; não houve run completa.
- Preview experimental **não validado visualmente para king**: asserts passaram, mas screenshot ainda mostrou portrait antigo. Não usar esse teste como aprovação. O autor pediu encerrar investigação browser nesta etapa.
- Não foram feitos integração final dos sete, save/load real da expansão, playtest completo ou teste pós-publicação.

## Base preservada e acesso

HTML original recebido: `/workspace/fortune-expansion/original.html`, SHA256 `434173f5a7e0e6377fe9d73dedc146c35368fab2e9cdabc7338dff540e580484`. Cópia de teste em `/workspace/fortune-playtest/index.html`. O ZIP original anexado excedeu32MiB e não foi recuperado; isso não impede testar o HTML, mas fontes completos ainda faltam nesta conta.

Site único: https://fortune-fell-recuperado.fragrantgear2.chatgpt.site/ . Handoff antigo cita project_id appgprj_6af13e6185b881919bbddacce60867a3; confirmar pela conta autorizada. Nesta conta não há Sites/hosting/deploy em ALL_TOOLS, /workspace/sites ou hosting.json; sites-preview status retornou preview relay unavailable. **Nenhuma publicação confirmada.** Não criar site substituto ou copiar credenciais.

## Pacotes e fechamento

- `fortune-fell-assets-passagem-lote01.zip`:pacote anterior preservado,9,72MiB informados.
- `fortune-fell-assets-passagem-lote02.zip`:acumulado lote02 a ser criado pelo agente principal; contém lote01 mais quatro ações candidatas corrigidas/exportadas,21 falas opcionais,spec Ínys e documentação atualizada. Conferir existência/hash na entrega.
- `LOTE02.md`:resumo do lote; `package_assets.py`:empacotador; incluir `specs/*.json` e scripts de geração das specs na passagem.
- `fortune-fell-assets-passagem.zip`:nome do acumulado principal. Só assets/fontes/manifestos/scripts/specs/docs e narrative/teste isolado; não incluir preview/browser como prova de integração.

Antes da entrega, conferir os ZIPs e registrar hashes. Documentação pronta antes do encerramento. A outra conta deve produzir os dois personagens faltantes e a carruagem/boneco, revisar candidatos, integrar e publicar. Não declarar pronto o que está apenas especificado.

## Lote03 — cabana das Charnecas

Exterior produzido/normalizado com refs reais do HTML `house_timber_near`, `shrine_ehrein`, `heather`:

- Corpo `assets/environment/witch_hut_body.png`:canvas176×144, arte150×131, âncora88,140. Escala uniforme baseada em porta46px; substitui o alvo antigo224×176.
- Porta `witch_hut_door.png`:32×48,pivô16,47; abertura≈24×46; âncora no corpo107,140.
- `witch_hut_door_mask.png`:máscara geométrica, não arte gerada; `witch_hut_closed.png`:composição fechada.
- `witch_hut_heather.png`:96×24,âncora48,24; `witch_hut_herbs_jars.png`:40×40,âncora20,40.
- Manifesto `assets/environment/witch_hut_manifest.json`; review do kit; fonte `assets/generated_sources/witch_hut_kit_source.png`1351×1164RGBA; script `normalize_hut.py`.
- Fonte atravessou grade do kit; recortes manuais preservaram corpo sem truncar. Não refatiar por grade automática.

Interior final produzido: `assets/environment/witch_hut_interior.png`,400×225RGB opaco,piso192. Fonte corrigida `witch_hut_interior_source.png`1672×941RGB; anterior preservada `witch_hut_interior_initial_source.png`. Script `normalize_hut_interior.py`:crop[36,0,1636,900],escala uniforme1/4. Manifesto `witch_hut_interior_manifest.json`. Porta interna≈30×51px (**não46 exatos**); hotspot/posição devem ser revistos pelo integrador. Arte sugere sala25×14tiles16,piso row12, mas não há mapa/colliders criados. `witch_hut_scale_reference.png` é composição estática com hero39/hag, **não screenshot de jogo**. Mapa previsto `em`,tx/ty não aprovados. Moors aberto não equivale a Shrine; cabana não entrega a chave nem contorna auth_ehrein. Consulte FICHA_CABANA.md. Sem testes de jogo nesta etapa. ZIPs lote01/lote02 preservados.

### Fechamento lote03

Cabana exterior e interior prontos como assets de cenário, com sources/manifestações/scripts e FICHA_CABANA.md. Pacote acumulado lote03 deve incluir `normalize_hut.py`, `normalize_hut_interior.py` e `LOTE03.md`; confirmar caminho/hash pelo empacotador. Nenhum mapa/collider/transição foi criado nem houve teste integrado. As pendências obrigatórias Seyrín/Halberd/carruagem+boneco permanecem no topo e não são encerradas pela cabana.

## Príncipes de Éhrein — adicionados à fila

`FICHAS_PRINCIPES_EHREIN.md` registra integralmente as instruções úteis do novo texto e as duas referências oficiais de Llewlás/Llúpin. **Queued, nenhum asset gerado e nenhuma implementação iniciada.** O texto prevê integração futura, mas o pedido atual é fila/instruções e retomada do lote04 obrigatório.

Llewlás39px atlético/louro, leão pessoal distinto da torre oficial, lança/corno, caça em em perto da Bruxa(tx/ty pendentes), aliado opcional com extensa lista de animações. **Não inferir morte definitiva dele pela flag genérica ehrein_citizens_fate.** Llúpin39px esguio/escuro/imberbe, anil/prata/lua, livro vermelho sem torre, óculos de leitura sem hastes e nunca no idle; substituir heir em ec20/12, ciclo13estados, sem combate. Irmãos afetuosos, não rivais.

## Lote04 — assets exportados e limites

### Halberd / artificer

- `assets/native/artificer_idle.png`:160×48,4×40×48,altura30px,pivô20/47,seed/GIF.
- Portraits `portrait_artificer_{neutral,listening,reaction}.png`:128×128; folha384×128; alias neutro.
- `assets/walk_candidates/artificer_walk_candidate.png`:240×48,6quadros,candidato com GIF.
- `assets/action_candidates/artificer_hammer.png`:192×48,4células48×48,pivô24/47,candidato com GIF.
- Oficina: bigorna existente16/12 e ator19/12. Antes de martelar, mover o ator para junto da bigorna e conferir contato da ferramenta; **não bater à distância**. Nenhuma colisão foi alterada nesta produção.

### Seyrín / oracle

- `assets/native/oracle_idle.png`:160×48,4×40×48,altura39px,pivô20/47,seed/GIF.
- Portraits `portrait_oracle_{neutral,listening,reaction}.png`:128×128; folha384×128; alias neutro.
- `assets/walk_candidates/oracle_walk_candidate.png`:240×48,6quadros,candidato com GIF.
- `assets/action_candidates/oracle_counsel.png`:160×48,4quadros,candidato com GIF.
- Identidade fiel à referência atual, sem revelar a natureza secreta. Posição final da entidade continua a definir pela conta integradora.

### Ínys / carruagem / boneco

- `assets/props/inys_carriage_body.png`:64×40,pivô32/39; quatro rodas separadas (3×8×8 e1×6×6), referência de cordão16×8, carruagem vazia completa de referência64×40.
- Manifesto `assets/props/inys_carriage_manifest.json`:assento27/28,engate42/31,centros das rodas20/35,27/35,34/35,41/36. Sete rodas totais/quatro visíveis preservadas.
- `assets/props/idhri_ragdoll_seated_0.png`:16×20,altura visível12px,pivô8/19; **somente boneco-base cabelo branco**.
- `assets/action_candidates/inys_pull_candidate.png`:240×48,6×40×48; manifesto/GIF; guias de grupo em assets/lote04-review. **Candidato:** ainda há fragmento curto do cordão na mão; junção runtime com engate exige revisão. Rodas devem girar por deslocamento real, não por relógio parado.
- Sem redesign ou tinta visual de Ínys. Cinco estados de cabelo continuam especificados pelo G.rings/ordem, mas os quatro coloridos não existem como PNGs; sem boneco held ou play novo.

### Fontes, scripts e revisão

Fontes `assets/generated_sources/lote04_{master_atlas,portraits_source,walks_source,idle_actions_source,inys_pull_guide_source}.png`. Scripts `normalize_lote04.py` e `normalize_inys_pull.py`. Revisões em assets/lote04-review. Arquivos normalizados são produção, **não aprovação em engine**; walks/ações/pull continuam candidatos.

### Quota e pacote

A geração dos cinco estados do boneco falhou com HTTP429/usage_limit_reached e não produziu arte. Não voltar ao bloqueio antigo de referência, já resolvido. O reset informado pela ferramenta não é garantia de disponibilidade; não prometer horário.

Lote04 é exportado como **incremental sobre o ZIP lote03** (base preservada19,42MiB), com docs atualizados, novos/alterados assets, scripts, manifesto e checksums. A conta receptora deve extrair lote03 primeiro e lote04 por cima, preservando lotes01..03. Usar checksums do ZIP03 como baseline e conferir checksums do pacote04. O pacote incremental não é acumulado completo; caminho/hash finais devem ser registrados pelo agente principal no fechamento. `package_lote04.py` reproduz o pacote; `LOTE04.md` e `LEIA_PRIMEIRO.md` descrevem a aplicação. `specs/DOLL_HAIR_IMPLEMENTATION.md` propõe futura implementação por máscara/camadas sem alterar Ínys; **os PNGs coloridos não existem**. Não confundir alternativa documentada com asset produzido.

## Pendências finais do checkpoint04

1. Quatro variantes coloridas de cabelo do boneco, held e ações específicas play/stop/talk/turn de Ínys não concluídas; quota de geração429 impede novas gerações nesta etapa.
2. Revisar candidatos walk/ações/pull, apoio, props e cordão; integrar os sete, expressões, cabana e missão na base real pela outra conta.
3. Llewlás/Llúpin apenas na fila: preservar fichas oficiais, sem alegar sprites produzidos; sem morte definitiva de Llewlás, óculos de Llúpin apenas leitura.
4. Rodar testes de implementação/playtest e publicar pela conta autorizada. Nenhuma publicação ou integração final foi feita nesta produção.

Referências atuais foram recebidas; não existe mais bloqueio de PNG de identidade. A documentação está fechada para empacotamento; sem pipeline de geração em execução após a falha de quota.
