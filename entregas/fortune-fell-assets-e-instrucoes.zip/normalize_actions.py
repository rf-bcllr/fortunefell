"""Export interaction poses from generated source strips. No gameplay integration."""
from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).resolve().parent
im=Image.open(R/'assets/generated_sources/four_adults_actions_source.png').convert('RGBA')
rows=[0,345,703,1060,im.height]
actions=[('king','weigh'),('hag','herbs'),('governor','write'),('queen','ceremonial')]
out=R/'assets/action_candidates';out.mkdir(exist_ok=True)
manifest=json.loads((R/'assets/manifest.json').read_text());review=Image.new('RGBA',(520,660),(30,24,38,255));d=ImageDraw.Draw(review)
for row,(name,action) in enumerate(actions):
 source=im;top,bottom=rows[row],rows[row+1]
 correction=R/'assets/generated_sources/king_weigh_corrected_source.png'
 if name=='king' and correction.exists():source=Image.open(correction).convert('RGBA');top,bottom=0,source.height
 crops=[]
 for col in range(4):
  cell=source.crop((round(col*source.width/4),top,round((col+1)*source.width/4),bottom));cell.putalpha(cell.getchannel('A').point(lambda v:255 if v>=128 else 0));crops.append(cell.crop(cell.getbbox()))
 scale=39/crops[0].height;strip=Image.new('RGBA',(160,48));frames=[]
 for col,crop in enumerate(crops):
  w,h=round(crop.width*scale),round(crop.height*scale)
  if w>40 or h>47:raise ValueError((name,col,w,h,'Source motion exceeds native cell; do not shrink a single frame'))
  crop=crop.resize((w,h),Image.Resampling.LANCZOS);crop.putalpha(crop.getchannel('A').point(lambda v:255 if v>=128 else 0));frame=Image.new('RGBA',(40,48));frame.alpha_composite(crop,((40-w)//2,47-h));strip.alpha_composite(frame,(col*40,0));frames.append(frame);review.alpha_composite(frame.resize((120,144),Image.Resampling.NEAREST),(col*128+4,row*164+16))
 strip.save(out/f'{name}_{action}.png');frames[0].save(out/f'{name}_{action}_review.gif',save_all=True,append_images=frames[1:],duration=[350,260,500,300],loop=0,disposal=2)
 note='Pose continuity, prop hand attachment, palette and game scale require final integrator review.'
 if name=='king' and correction.exists():note+=' Source revised: scales stay lowered in the same hand; only head/free hand gesture.'
 if name=='king' and not correction.exists():note+=' Uncorrected source appears to exchange scale hand; use corrected row when available.'
 manifest[name]['interaction_candidate']={'action':action,'file':f'assets/action_candidates/{name}_{action}.png','cell':[40,48],'frames':4,'pivot':[20,47],'duration_ms':[350,260,500,300],'source':str(correction.relative_to(R)) if name=='king' and correction.exists() else 'assets/generated_sources/four_adults_actions_source.png','status':'GENERATED_CANDIDATE; no engine integration','review_notes':note}
 d.text((4,row*164),name+' / '+action,fill='white')
review.save(R/'assets/actions-review.png');(R/'assets/manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print('Four interaction sheets160x48 and four review GIFs exported.')
