from pathlib import Path
from PIL import Image
import shutil,json
R=Path(__file__).resolve().parent
src=R/'assets/generated_sources/four_adults_walk_source.png'
im=Image.open(src).convert('RGBA');ids=['king','hag','governor','queen'];out=R/'assets/walk_candidates';out.mkdir(exist_ok=True)
m=json.loads((R/'assets/manifest.json').read_text())
for row,name in enumerate(ids):
 cells=[]
 for col in range(6):
  cell=im.crop((col*256,row*256,(col+1)*256,(row+1)*256));cell.putalpha(cell.getchannel('A').point(lambda v:255 if v>=128 else 0));cells.append(cell.crop(cell.getbbox()))
 scale=39/cells[0].height;strip=Image.new('RGBA',(240,48));frames=[]
 for col,cell in enumerate(cells):
  w,h=round(cell.width*scale),round(cell.height*scale);assert w<=40 and h<=47
  cell=cell.resize((w,h),Image.Resampling.LANCZOS);cell.putalpha(cell.getchannel('A').point(lambda v:255 if v>=128 else 0));frame=Image.new('RGBA',(40,48));frame.alpha_composite(cell,((40-w)//2,47-h));strip.alpha_composite(frame,(col*40,0));frames.append(frame)
 strip.save(out/f'{name}_walk_candidate.png');frames[0].save(out/f'{name}_walk_review.gif',save_all=True,append_images=frames[1:],duration=140,loop=0,disposal=2)
 m[name]['walk_candidate']={'file':f'assets/walk_candidates/{name}_walk_candidate.png','cell':[40,48],'frames':6,'duration_ms':140,'pivot':[20,47],'status':'REVIEW REQUIRED: support-leg alternation, foot sliding, motion and prop stability not validated. Do not enable automatically.'}
(R/'assets/manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n');print('Four six-frame walk candidates240x48 exported, explicitly unapproved for automatic integration.')
