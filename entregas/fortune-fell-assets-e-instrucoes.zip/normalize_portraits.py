from pathlib import Path
from PIL import Image,ImageDraw
import shutil,json
R=Path(__file__).resolve().parent
src=R/'assets/generated_sources/portrait_expressions_source.png'
im=Image.open(src).convert('RGBA');ids=['king','hag','governor','inys','queen'];labels=['neutral','listening','reaction']
bounds=[0,313,628,932,1253,im.height]
manifest=json.loads((R/'assets/manifest.json').read_text());review=Image.new('RGBA',(440,720),(30,24,38,255));d=ImageDraw.Draw(review)
for row,name in enumerate(ids):
 crops=[]
 for col in range(3):
  cell=im.crop((round(col*im.width/3),bounds[row],round((col+1)*im.width/3),bounds[row+1]))
  cell.putalpha(cell.getchannel('A').point(lambda v:255 if v>=128 else 0));crops.append(cell.crop(cell.getbbox()))
 scale=min(124/max(c.width for c in crops),124/max(c.height for c in crops));sheet=Image.new('RGBA',(384,128))
 for col,(label,crop) in enumerate(zip(labels,crops)):
  w,h=round(crop.width*scale),round(crop.height*scale);crop=crop.resize((w,h),Image.Resampling.LANCZOS);crop.putalpha(crop.getchannel('A').point(lambda v:255 if v>=128 else 0))
  final=Image.new('RGBA',(128,128));final.alpha_composite(crop,((128-w)//2,128-h));final.save(R/f'assets/native/portrait_{name}_{label}.png');sheet.alpha_composite(final,(col*128,0));review.alpha_composite(final,(col*140+5,row*142+14))
  if col==0:final.save(R/f'assets/native/portrait_{name}.png')
 sheet.save(R/f'assets/native/portrait_{name}_expressions.png');d.text((5,row*142),name,fill='white')
 manifest[name]['portrait_expressions']={label:f'assets/native/portrait_{name}_{label}.png' for label in labels};manifest[name]['portrait_sheet']=f'assets/native/portrait_{name}_expressions.png';manifest[name]['portrait_expression_cell']=[128,128];manifest[name]['portrait_scale_shared_within_character']=scale
(R/'assets/manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n');review.save(R/'assets/portraits-review.png');print('15 portraits128x128, five384x128 expression strips; shared scale per character.')
