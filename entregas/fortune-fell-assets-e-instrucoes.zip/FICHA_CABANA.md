# Cabana da Bruxa — Charnecas de Éhrein

**Lote03 em produção.** Esta ficha orienta um asset de cenário; ainda não há arquivo final confirmado. Não confundir especificação com mapa implementado ou arte aprovada em engine.

## Direção artística

Cabana humilde e isolada nas charnecas de Éhrein, úmida e envelhecida, em pedra/madeira e cobertura rústica. Ambiente melancólico, com urzes, árvores retorcidas, ervas, frascos e pequenos amuletos naturais; sem palácio, monumentalidade, eletrônica ou estética de outro reino. Usar a arte atual de Éhrein do HTML recebido como referência de materiais, contorno, densidade e paleta. A cabana complementa os assets existentes, não exige retile global.

Silhueta clara contra névoa e vegetação. A entrada deve ser legível sem brilho artificial. Desgaste e assimetria de construção podem existir sem deformar a perspectiva lateral do jogo. Não incluir a Bruxa pintada no cenário: a personagem é entidade independente.

## Partes previstas

- Corpo exterior da cabana.
- Porta/entrada independente para interação e estados.
- Elementos de frente/oclusão independentes quando necessários, preservando a leitura dos personagens e acesso.

Exterior produzido e normalizado, com referências reais extraídas do HTML: `house_timber_near`, `shrine_ehrein` e `heather`. Sem NPC pintado e sem heráldica monárquica. O alvo inicial224×176 foi substituído pela dimensão real medida abaixo; não usar o alvo antigo como tamanho de entrega.

| Arquivo em assets/environment | Tamanho / âncora | Finalidade |
|---|---|---|
| witch_hut_body.png | Canvas176×144; arte150×131; âncora88,140 | Corpo exterior com escala uniforme baseada em porta46px |
| witch_hut_door.png | 32×48; pivô16,47 | Folha da porta; abertura≈24×46 |
| witch_hut_door_mask.png | Conferir manifesto | Máscara de geometria, **não arte gerada** |
| witch_hut_closed.png | Composição do corpo/porta | Versão fechada de referência |
| witch_hut_heather.png | 96×24; âncora48,24 | Patch frontal de urzes |
| witch_hut_herbs_jars.png | 40×40; âncora20,40 | Ervas e jarros independentes |

Âncora da porta no corpo:107,140. Manifesto `assets/environment/witch_hut_manifest.json`; review PNG do kit no mesmo conjunto. Fonte `assets/generated_sources/witch_hut_kit_source.png`:1351×1164,RGBA. Script `normalize_hut.py`. O corpo atravessava a grade desenhada na fonte e foi recortado por boxes manuais sem truncar; não refatiar automaticamente pela grade2×2.

Porta de aproximadamente46px para Idhrí39px é a relação medida de composição. A aprovação visual no cenário e a posição de implantação continuam com a conta integradora. Não comprimir o corpo inteiro para forçar outra largura.

## Integração futura

Mapa previsto: `em` (Charnecas). **Ponto tx/ty final ainda não aprovado**. Escolher área segura e acessível antes do Santuário, sem sobrepor portas existentes, inimigos, checkpoints ou caminhos de progressão. A porta precisa permitir ida/volta sem novos poderes não disponíveis nessa etapa.

Acesso às Charnecas e acesso ao Santuário são estados distintos: `moors_open` permite alcançar a cabana; `auth_ehrein` só é concedido pelo rei após a consulta correta. A cabana não deve conceder a chave, abrir `ed` diretamente ou criar atalho que contorne essa regra. A Bruxa deve continuar oferecendo contraponto sobre Seyrín mesmo quando não é a consulta oficial.

Interior final produzido: `assets/environment/witch_hut_interior.png`,400×225RGB opaco,piso y192. Fonte corrigida `assets/generated_sources/witch_hut_interior_source.png`1672×941RGB; anterior preservada `witch_hut_interior_initial_source.png`. Script `normalize_hut_interior.py`:crop[36,0,1636,900],escala uniforme1/4. Manifesto `assets/environment/witch_hut_interior_manifest.json`. Porta interna aproximadamente30×51px, não46 exatos; hotspot e localização exigem revisão do integrador. A escala aparenta compatível com personagem39px na arte. Sugestão de sala25×14tiles16,piso row12 é somente orientação: **não há mapa nem colliders criados**. Definir sua criação e transição separadamente; um exterior produzido não comprova interior pronto. Manter personagem, porta e objetos interativos independentes. Usar camadas para não esconder o sprite atrás da fachada durante a conversa.

## Entrega e aceitação

Ao produzir, registrar caminhos, dimensões reais, alpha, pivôs, margens e ordem de camadas. Preservar master/source e versão nativa. A revisão em engine e o ponto de implantação ficam com a conta integradora; nesta etapa não executar testes de jogo.

**Estado atual:** exterior e interior produzidos/normalizados como assets. Nenhum mapa/collider criado ou posição/hotspot final aprovado. Aprovação em engine fica com a conta integradora. `witch_hut_scale_reference.png` é composição estática com hero39/hag, não screenshot de jogo. Lote03 acumulado inclui esta ficha, LOTE03.md e scripts normalize_hut.py/normalize_hut_interior.py. Não altera o estado pendente de Seyrín/Halberd/carruagem+boneco. Não alterar os ZIPs preservados lote01/lote02 ao preparar o lote03.
