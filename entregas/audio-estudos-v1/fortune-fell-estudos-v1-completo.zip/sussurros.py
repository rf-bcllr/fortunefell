"""Experimental articulated whispered phonemes; no human recording or meaningful words."""
from pathlib import Path
import numpy as np,json,math,wave,subprocess
from scipy.signal import butter,sosfilt,iirpeak,lfilter
from produzir import SR,write_wav
R=Path(__file__).resolve().parent;D=R/'eyes-of-iomadh';rng=np.random.default_rng(40918)
with wave.open(str(D/'mix.wav'),'rb') as f:
 raw=np.frombuffer(f.readframes(f.getnframes()),np.uint8).reshape(-1,3);v=raw[:,0].astype(np.int32)|(raw[:,1].astype(np.int32)<<8)|(raw[:,2].astype(np.int32)<<16);v=np.where(v&0x800000,v-0x1000000,v);music=v.astype(np.float32).reshape(-1,2)/8388608
forms={'a':[(760,180),(1220,210),(2780,350)],'e':[(550,150),(1910,240),(2950,360)],'i':[(350,140),(2420,280),(3250,420)],'o':[(580,160),(990,200),(2730,370)],'u':[(370,140),(1000,220),(2770,400)]}
def phoneme(p,dur,ratio):
 n=round(dur*SR);noise=rng.normal(0,1,n);source=sosfilt(butter(2,[180,10500],btype='bandpass',fs=SR,output='sos'),noise)
 if p in forms:
  x=np.zeros(n)
  for j,(freq,bw) in enumerate(forms[p]):
   b,a=iirpeak(freq*ratio,(freq/bw),fs=SR);x+=lfilter(b,a,source)*[1,.70,.32][j]
  x+=source*.018
 else:
  band={'h':[350,4300],'s':[4700,10800],'sh':[2100,7000],'f':[1100,7800]}[p];x=sosfilt(butter(3,np.array(band)*ratio,btype='bandpass',fs=SR,output='sos'),noise)*.14
 # Brief overlaps between phonemes preserve a continuous vocal-tract gesture.
 edge=min(round(.035*SR),n//3);env=np.ones(n);env[:edge]=np.linspace(0,1,edge);env[-edge:]=np.linspace(1,0,edge)
 x*=env;return x
sequences=[['h','a','sh','e','s','i'],['s','e','h','u','sh','a'],['f','i','sh','o','h','e'],['sh','a','s','u','h','i']]
def phrase(index,ratio):
 parts=[phoneme(p,float(rng.uniform(.10,.20) if p in forms else rng.uniform(.045,.10)),ratio) for p in sequences[index%4]]
 overlap=round(.02*SR);n=sum(len(p) for p in parts)-overlap*(len(parts)-1);x=np.zeros(n);pos=0
 for p in parts:x[pos:pos+len(p)]+=p;pos+=len(p)-overlap
 x/=max(1e-9,float(np.sqrt(np.mean(x*x))));return x
layer=np.zeros_like(music);cues=[]
# No words or directions are encoded. Sparse voices leave conversations/combat clear.
for i,(time,pan,level) in enumerate([(9,-.35,.009),(19,.30,.009),(32,-.55,.012),(42,.5,.011),(51,-.25,.011),(60,.35,.013),(68,-.5,.016),(76,.5,.015),(81,-.15,.014)]):
 x=phrase(i,[.91,1.08,1.0][i%3])*level;start=round(time*SR);left=math.cos((pan+1)*math.pi/4);right=math.sin((pan+1)*math.pi/4)
 for delay,amount in [(0,1),(.12,.25),(.26,.13),(.43,.07)]:
  a=start+round(delay*SR);b=min(len(layer),a+len(x));layer[a:b,0]+=x[:b-a]*left*amount;layer[a:b,1]+=x[:b-a]*right*amount
 cues.append({'time':time,'pan':pan,'voice_formant_ratio':[.91,1.08,1.0][i%3],'rms_target_before_pan':level,'content':'meaningless synthetic whispered phonemes'})
assert float(np.max(np.abs(layer)))<.3;mix=music+layer;assert float(np.max(np.abs(mix)))<.95
write_wav(D/'sussurros-experimentais.wav',layer);write_wav(D/'mix-com-sussurros.wav',mix)
for name in ['sussurros-experimentais','mix-com-sussurros']:
 for fmt,opts in [('mp3',['-c:a','libmp3lame','-b:a','192k']),('flac',['-c:a','flac','-compression_level','8'])]:subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(D/f'{name}.wav'),*opts,str(D/f'{name}.{fmt}')],check=True)
(D/'sussurros.json').write_text(json.dumps({'status':'experimental synthetic articulated whisper; not human recording, not final vocal production','user_direction':'overlapping whispered voices with indistinct words','words_or_lore_invented':False,'method':'unvoiced excitation, moving vowel formants and fricatives, crossfaded phonemes, three formant profiles','cues':cues,'music_unmodified_before_layer':True,'peak_layer':float(np.max(np.abs(layer))),'peak_mix':float(np.max(np.abs(mix)))},ensure_ascii=False,indent=2)+'\n');print('Experimental whispered-phoneme layer rendered; clean music preserved; peak',float(np.max(np.abs(mix))))
