from pathlib import Path
import ctypes as C,json,math,struct,wave,random,subprocess,hashlib
import numpy as np
from scipy.signal import fftconvolve
R=Path(__file__).resolve().parent;S=json.loads((R/'scores.json' if (R/'scores.json').exists() else R.parent/'scores.json').read_text());SR=44100
F=C.CDLL('libfluidsynth.so.3')
def api(n,ret,args):
 f=getattr(F,n);f.restype=ret;f.argtypes=args;return f
ptr=C.c_void_p;I=C.c_int;D=C.c_double;B=C.c_char_p
newset=api('new_fluid_settings',ptr,[]);setnum=api('fluid_settings_setnum',I,[ptr,B,D]);setint=api('fluid_settings_setint',I,[ptr,B,I]);newsynth=api('new_fluid_synth',ptr,[ptr]);load=api('fluid_synth_sfload',I,[ptr,B,I]);program=api('fluid_synth_program_change',I,[ptr,I,I]);on=api('fluid_synth_noteon',I,[ptr,I,I,I]);off=api('fluid_synth_noteoff',I,[ptr,I,I]);cc=api('fluid_synth_cc',I,[ptr,I,I,I]);write=api('fluid_synth_write_float',I,[ptr,I,ptr,I,I,ptr,I,I]);delete=api('delete_fluid_synth',None,[ptr]);delset=api('delete_fluid_settings',None,[ptr])
MODES={'dorian':[0,2,3,5,7,9,10],'aeolian':[0,2,3,5,7,8,10],'phrygian':[0,1,3,5,7,8,10],'harm':[0,2,3,5,7,8,11]}
INST={'cordas':(48,.72),'violoncelo':(42,.63),'flauta':(73,.80),'harpa':(46,.68),'acordeao':(21,.64),'gaita':(109,.48),'trompa':(60,.65),'timpanos':(47,.70),'coro':(52,.32)}
def midi_note(s,d,root=None,mode=None):
 sc=MODES[mode or s['mode']];i=d-1;return (root if root is not None else s['root'])+sc[i%7]+12*(i//7)
def vlq(n):
 a=[n&127];n>>=7
 while n:a.insert(0,(n&127)|128);n>>=7
 return bytes(a)
def chunk(k,data):return k+struct.pack('>I',len(data))+data

def build(kingdom):
 s=S[kingdom];rng=random.Random(147 if kingdom=='ehrein' else 318);events={k:[] for k in INST};sections=[];offset=.5;tick=0
 settings=[('Town',68,'aeolian'),('Moors',60,'aeolian'),('Shrine',72,'phrygian'),('Battle',112,'harm')] if kingdom=='ehrein' else [('Plaza',76,'dorian'),('Wilds',66,'dorian'),('Shrine',72,'dorian'),('Battle',112,'harm')]
 tempos=[]
 def note(inst,start,dur,pitch,vel,st,dt):
  assert 0<=pitch<=127 and dur>0
  jitter=rng.uniform(-.007,.007) if inst!='timpanos' else 0
  events[inst].append({'time':round(max(0,start+jitter),5),'duration':round(dur,5),'note':int(pitch),'velocity':max(1,min(110,int(vel+rng.uniform(-3,3)))),'tick':round(st),'ticks':max(1,round(dt))})
 for sec,(label,bpm,mode) in enumerate(settings):
  beat=60/bpm;e8=beat/2;start=offset;tempos.append((tick,bpm));steps=64
  sections.append({'context':label,'start_seconds':round(start,3),'end_seconds':round(start+steps*e8,3),'bpm':bpm,'mode':mode,'bars':8,'start_tick':tick})
  for bar in range(8):
   deg=s['chordAt'][bar%s['bars']];tones=[midi_note(s,deg+k,mode=mode) for k in [0,2,4]];t=start+bar*8*e8;bt=tick+bar*1920
   # Chord inversions, register and density distinguish the contexts.
   for k,m in enumerate(tones):
    voice=m+(12 if k==0 else 0)
    note('cordas',t,beat*3.88,voice,35+[0,-7,3,14][sec],bt,1860)
   if sec!=3:note('violoncelo',t,beat*3.8,tones[0]-12,44+[0,-6,4,9][sec],bt,1820)
   if sec in [0,1,2]:
    for j in [0,2,4,6]:
     m=tones[[0,1,2,1][j//2]]+12
     note('harpa',t+j*e8,e8*.65,m,40 if sec!=1 else 32,bt+j*240,156)
   if kingdom=='iomadh':
    # Accordion bellows: chord attacks with a breathing rest, not an unbroken pad.
    pos=[0,4] if sec!=1 else [0]
    for j in pos:
     for m in tones:note('acordeao',t+j*e8,e8*(3.5 if sec!=3 else 1.7),m-12,41+[4,-9,-5,8][sec],bt+j*240,840 if sec!=3 else 408)
   elif sec in [1,2]:
    # A restrained fifth drone; the GM bagpipe is a sketch timbre, not uilleann samples.
    note('gaita',t,beat*3.6,s['root'],30 if sec==1 else 26,bt,1728)
   if sec==2 and bar%2==0:
    for m in tones:note('coro',t,beat*7.7,m,29,bt,3696)
   if sec==3:
    for j in range(8):
     note('violoncelo',t+j*e8,e8*.72,tones[0]-12+(7 if j in [3,7] else 0),57 if j%2==0 else 43,bt+j*240,172)
    for j in [0,4]:note('timpanos',t+j*e8,beat*.8,40 if j==0 else 47,58 if j==0 else 42,bt+j*240,384)
    if bar in [0,3,6]:
     for m in tones:note('trompa',t,beat*2.8,m,49,bt,1344)
  tokens=s['tok']
  for step in range(steps):
   token=tokens[step%len(tokens)]
   if token in ['-','r']:continue
   n=1
   while n<16 and tokens[(step+n)%len(tokens)]=='-':n+=1
   # Phrase endings breathe; no wind instrument is held through the full section.
   dur=min(n*e8*.88,(8-step%8)*e8*.94)
   pitch=midi_note(s,int(token),mode=mode)+12
   t=start+step*e8;st=tick+step*240
   if kingdom=='ehrein':
    inst='gaita' if sec in [0,3] else 'flauta';vel=59 if sec==0 else 48 if sec==1 else 45 if sec==2 else 68
   else:
    inst='acordeao' if sec==0 or(sec==3 and step//8%2==0) else 'flauta';vel=56 if sec!=3 else 64
   # More open phrasing during exploration, avoiding constant foreground melody.
   if sec==1 and step//8%2==1:continue
   note(inst,t,dur,pitch,vel,st,max(1,int(dur/beat*480)))
  offset+=steps*e8;tick+=steps*240
 # Return to the home-mode tonic after the battle; not an in-game loop master.
 beat=60/68
 for j,m in enumerate([s['root'],midi_note(s,3),midi_note(s,5)]):note('cordas',offset,beat*7,m,33-j*3,tick,3360)
 sections.append({'context':'Coda','start_seconds':round(offset,3),'end_seconds':round(offset+beat*8,3),'bpm':68,'mode':s['mode'],'bars':2,'start_tick':tick});tempos.append((tick,68));duration=offset+beat*8+4
 return events,sections,tempos,duration

def render(inst,events,duration):
 settings=newset();setnum(settings,b'synth.sample-rate',SR);setnum(settings,b'synth.gain',.48);setint(settings,b'synth.reverb.active',0);setint(settings,b'synth.chorus.active',0)
 synth=newsynth(settings);assert synth;assert load(synth,b'/usr/share/sounds/sf2/TimGM6mb.sf2',1)>=0;assert program(synth,0,INST[inst][0])==0
 cc(synth,0,10,{'flauta':78,'harpa':40,'cordas':52,'violoncelo':70,'acordeao':60,'gaita':66,'trompa':42,'timpanos':64,'coro':64}[inst])
 count=math.ceil(duration*SR);out=np.zeros((count,2),np.float32);actions=[]
 for e in events:
  actions.append((round(e['time']*SR),True,e['note'],e['velocity']));actions.append((round((e['time']+e['duration'])*SR),False,e['note'],0))
 actions.sort(key=lambda e:(e[0],e[1]));pos=0
 def advance(end):
  nonlocal pos
  while pos<end:
   n=min(end-pos,16384);l=np.empty(n,np.float32);r=np.empty(n,np.float32);assert write(synth,n,l.ctypes.data,0,1,r.ctypes.data,0,1)==0;out[pos:pos+n,0]=l;out[pos:pos+n,1]=r;pos+=n
 for frame,active,pitch,vel in actions:
  frame=min(count,max(0,frame));advance(frame)
  (on(synth,0,pitch,vel) if active else off(synth,0,pitch))
 advance(count);delete(synth);delset(settings)
 # Shared soft room through early reflections, restrained to keep attacks legible.
 wet=np.zeros_like(out)
 for delay,gain in [(0.071,.12),(.113,.09),(.173,.06),(.251,.04),(.347,.025)]:
  n=round(delay*SR);wet[n:,0]+=out[:-n,1]*gain;wet[n:,1]+=out[:-n,0]*gain
 return (out+wet)*INST[inst][1]

def write_wav(path,a):
 peak=float(np.max(np.abs(a)));assert peak<=1
 with wave.open(str(path),'wb') as f:f.setnchannels(2);f.setsampwidth(3);f.setframerate(SR);v=np.round(a*8388607).astype('<i4');raw=v.view(np.uint8).reshape(-1,4)[:,:3].copy();f.writeframes(raw.tobytes())

def write_midi(path,events,sections,tempos):
 tracks=[];meta=[]
 for tick,bpm in tempos:meta.append((tick,b'\xff\x51\x03'+round(60000000/bpm).to_bytes(3,'big')))
 for s in sections:
  text=s['context'].encode();meta.append((s['start_tick'],b'\xff\x06'+vlq(len(text))+text))
 def track(ev):
  data=bytearray();last=0
  for t,msg in sorted(ev,key=lambda x:x[0]):data+=vlq(t-last)+msg;last=t
  return chunk(b'MTrk',bytes(data)+b'\x00\xff\x2f\x00')
 tracks.append(track(meta))
 for ch,(inst,notes) in enumerate(events.items()):
  if not notes:continue
  name=inst.encode();ev=[(0,b'\xff\x03'+vlq(len(name))+name),(0,bytes([0xc0+ch,INST[inst][0]]))]
  for e in notes:ev.extend([(e['tick'],bytes([0x90+ch,e['note'],e['velocity']])),(e['tick']+e['ticks'],bytes([0x80+ch,e['note'],0]))])
  tracks.append(track(ev))
 path.write_bytes(chunk(b'MThd',struct.pack('>HHH',1,len(tracks),480))+b''.join(tracks))

if __name__=='__main__':
 result={}
 for kingdom,title,stem in [('ehrein','Amidst Rain and Ruin','amidst-rain-and-ruin'),('iomadh','Eyes of Iomadh','eyes-of-iomadh')]:
  out=R/stem;out.mkdir(exist_ok=True);events,sections,tempos,duration=build(kingdom);mix=np.zeros((math.ceil(duration*SR),2),np.float32)
  for inst,notes in events.items():
   if notes:mix+=render(inst,notes,duration);print(kingdom,inst,len(notes),flush=True)
  # One documented master trim preserves the relative instrumental balance.
  peak=float(np.max(np.abs(mix)));gain=min(6.0,.82/max(peak,1e-9));mix*=gain
  fade=min(SR*3,len(mix));mix[-fade:]*=np.linspace(1,0,fade,dtype=np.float32)[:,None];mix[:SR//4]*=np.linspace(0,1,SR//4,dtype=np.float32)[:,None]
  write_wav(out/'mix.wav',mix);write_midi(out/'arranjo.mid',events,sections,tempos)
  data={'title':title,'status':'sampled GM arrangement study, not final orchestra','sample_bank':'TimGM6mb.sf2 installed; bank not bundled','sample_rate':SR,'pcm_bits':24,'duration':duration,'sections':sections,'programs':{k:v[0] for k,v in INST.items()},'master_gain':gain,'peak_before_master':peak,'peak_after_master':float(np.max(np.abs(mix))),'source':'Original R7 regional melody/chord material; new voicing, phrasing, instrumental roles, tempo map and coda','whispers':'not included; human whispered voices pending content and recording/generation source' if kingdom=='iomadh' else 'not applicable','events':events}
  (out/'arranjo.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');result[kingdom]={k:v for k,v in data.items() if k!='events'}
  for fmt,opts in [('mp3',['-c:a','libmp3lame','-b:a','192k']),('flac',['-c:a','flac','-compression_level','8'])]:subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(out/'mix.wav'),*opts,'-metadata','title='+title+' — estudo de arranjo v1',str(out/f'mix.{fmt}')],check=True)
  print(title,round(duration,2),'seconds',flush=True)
 (R/'manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
