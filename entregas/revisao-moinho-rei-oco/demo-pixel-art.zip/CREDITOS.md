# Créditos de terceiros

## Ícones da interface — game-icons.net

Os ícones das cartas de tarô, dos emblemas dos reinos no HUD, da oficina, da chancelaria e do Tesouro Real vêm de [game-icons.net](https://game-icons.net/) e estão sob a licença [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/). A tela inicial mostra uma linha de crédito.

| Uso no jogo | Ícone | Autor |
| --- | --- | --- |
| Myriadd | polar-star | Delapouite |
| Gileád | hourglass | Lorc |
| Iomadh | sheikah-eye | Lorc |
| Éhrein | stone-tower | Lorc |
| Airgeád | anvil | Lorc |
| Nemet | oak-leaf | Delapouite |
| Fiódhor | claw-slashes | Lorc |
| Morgwang | wave-crest | Lorc |
| Vida de Idhrí | heart-plus | Zeromancer |
| Carga de Myrdhórin | high-shot | Lorc |
| Corrente de Ouro | crossed-chains | Lorc |
| Corrente do Tempo | sands-of-time | Lorc |
| Recuperação | heart-bottle | Lorc |
| Continuar | play-button | Guard13007 |
| Novo jogo | sunrise | Delapouite |
| Pedidos | scroll-unfurled | Lorc |
| Controles | gamepad | Delapouite |
| Som | sound-on / sound-off | Delapouite |
| Tremor | earth-crack | Lorc |
| Modo assistido | angel-wings | Lorc |
| Idioma | conversation | Lorc |
| Sair | exit-door | Delapouite |
| Capítulos | book-cover | Lorc |
| Voltar | return-arrow | Lorc |
| Ouro, depósito | two-coins, pay-money, coins, cash | Delapouite, Lorc |
| Tesouro Real | locked-chest | Lorc |
| Cartas da chancelaria | envelope, tied-scroll | Lorc |
| Aprovação | laurels | Lorc |
| Confirmar / cancelar | check-mark / cancel | Delapouite / Sbed |
| Opção genérica | star-formation | Delapouite |
| Oficina | hammer-drop | Lorc |
| Anel do ouro | gold-bar | Willdabeast |
| Objetivo | compass | Lorc |
| Outros (coroa, lua, vela, cristal, olho) | crown, moon, candle-light, crystal-ball, all-seeing-eye | Lorc, Delapouite |

O coração do HUD é um desenho próprio.

## Fontes

- IM Fell English SC (títulos) — Igino Marini, SIL Open Font License, via Google Fonts.
- Alegreya (textos) — Huerta Tipográfica, SIL Open Font License, via Google Fonts.
- Pixelify Sans (já usada pelo jogo) — SIL Open Font License.
