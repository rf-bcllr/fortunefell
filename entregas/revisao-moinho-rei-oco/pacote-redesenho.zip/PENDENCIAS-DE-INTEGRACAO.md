# Próxima passada de cenário

- Fixar visualmente as tochas de parede à pedra com leve sobreposição da base. Orientar o suporte conforme a parede e testar o enquadramento dos dois lados. Manter as pilastras livres.
- Ajustar a profundidade dos guarda-corpos da ponte no Jardim de Myriadd para Idhrí passar por trás. A transição da margem à ponte deve manter a leitura do apoio.

## Objetivos e moinho

- Na interação com a mesa vazia de Pódhraic, Idhrí comenta que o chanceler saiu para acompanhar as eleições em Iomadh.
- Acionar o objetivo principal de encontrar Pódhraic no momento em que Idhrí fala disso na entrada da Mata Alta.
- Restaurar o desaparecimento do saco de tesouro do moinho quando atingido pela flecha.
- Conferir e corrigir as posições das plataformas invisíveis do moinho com a marcação indicada pelo autor.
