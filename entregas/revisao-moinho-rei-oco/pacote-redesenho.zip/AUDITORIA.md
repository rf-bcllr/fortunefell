# Fortune Fell · contorno e resolução

Prévia auditada em Chromium no commit `23cc73c`. Foram 288 enquadramentos nos 23 mapas, incluindo 150 enquadramentos direcionados a objetos, inimigos e encontros. A régua de contorno tem 97 quadros. O diagnóstico prioriza a leitura na escala do jogo e a fidelidade ao desenho aprovado. [Prévia de referência](https://github.com/rf-bcllr/fortunefell/commit/23cc73c1ae50ae0d1810a55fe120881d6d854dba)

## Reexportação com original localizado

Encontrei e comparei **20 originais maiores** com os desenhos ativos. O inventário registra o arquivo, a dimensão original, a dimensão em jogo e o caminho de integração. As fontes são os PNGs nos pacotes de originais, de fachadas aprovadas e dos Arquivos Reais. [Prancha dos 20 pares](03-reguas/originais-e-demo.jpg) · [Inventário com originais](inventario-de-assets.csv)

| Onde | O que pode ser reexportado |
| --- | --- |
| Gileád | Duas galerias dos Arquivos Reais, o fundo dos Arquivos, o segundo monumento e a casa B da capital |
| Iomadh | Duas fachadas residenciais, o arco de acesso à mata, a fachada do Conselho, o pavilhão, a banca, o poço, a porta interna e o plano intermediário do vilarejo |
| Éhrein | As duas casas da vila murada e a porta interna da corte |
| Myriadd | Fachada do palácio no Mirante, porta interna e plano intermediário do exterior |

As galerias dos Arquivos são exemplos diretos de 240 × 158 e 128 × 192 px desenhados no mesmo tamanho lógico. As fontes medem 1536 × 1024 e 1024 × 1536 px. O poço de Iomadh vai de 64 × 80 px em jogo a uma fonte de 1254 × 1254 px antes do recorte. A menor das duas casas de Éhrein já chega a 1,23× com a redução aplicada pelo motor, mas a fonte de 1448 × 1086 px permite extrair os detalhes a 2×. [Medições do renderizador](medicoes-do-renderizador.csv)

Nas casas, fachadas, planos intermediários e decorações incorporados ao mapa, a reexportação também pede uma mudança de integração. O motor desenha essas peças numa composição a 1×. Para o ganho chegar à tela, a nova imagem precisa entrar numa composição a 2× ou numa camada nativa no mesmo ponto da cena. O recorte, as portas, o pé da fachada e a ordem de desenho são as âncoras da conferência. [Prioridades por mapa](prioridades-por-mapa.csv)

## Redesenho ou reconstrução

**Guardiões e Rei Oco têm prioridade visual.** Os Guardiões de Gileád, Iomadh e Éhrein têm corpos e peças a 1×. As fontes localizadas repetem as dimensões da arte em uso. Iomadh usa seis máscaras de 28 × 28 px. Éhrein usa corpo de 120 × 160 px, com peitoral, ombreira e elmo desenhados à parte. Em Gileád, a mão tem 56 × 40 px e o núcleo 44 × 44 px. O núcleo fica condicionado à fase do combate. O Rei Oco usa células de 256 × 96 px ampliadas a 332,8 × 124,8 unidades, o caso mais claro de ampliação entre os personagens e inimigos auditados. O Cavaleiro Oco comum é outro asset e já tem folha de ação a 2×. Refazer cada peça em torno de seus encaixes, estados de Ouro e Tempo e áreas de interação permite manter o combate e o desenho original. [Capturas dos três Guardiões](02-em-jogo/amostras-em-jogo.jpg)

**Terreno pede reconstrução por módulos.** Em 22 mapas, o piso composto continua a 1×, com detalhes desenhados por cima a 2×. A cabana pintada é a exceção. A prancha de referência de terreno localizada tem módulos e composição diferentes do piso que o motor usa. O trabalho está nas bordas de pouso, quinas, emendas de pedra, madeira e grama e nas plataformas. Os primeiros conjuntos indicados são as bordas de pedra dos Arquivos, os galhos e apoios da Mata Alta e os recortes de nuvem dos Terraços. A geometria dos apoios, o contraste dos pontos de pouso e o encaixe com o fundo servem de referência. [Prioridades por mapa](prioridades-por-mapa.csv)

**Props com redesenho previsto.** Os santuários externos de Iomadh e Éhrein, as molduras de portais, a entrada fechada da cabana, as escadas e a composição das Três Graças dos Arquivos e o balcão jogável do jardim usam arte menor. As cópias e referências localizadas para esses desenhos não oferecem detalhe adicional suficiente. A planta camuflada de Iomadh também tem um quadro antigo a 1×, enquanto os quadros expostos estão a 2×. Nas demais peças com fonte a confirmar, o inventário conserva a incerteza. [Inventário de assets](inventario-de-assets.csv)

As fachadas principais de Gileád e Éhrein, a entrada do Santuário de Gileád, o conjunto maior do jardim, a mesa da Chancelaria, os espantalhos, os estandartes, as placas e os checkpoints já chegam à tela em 2× ou mais nas amostras. A ponte, o quiosque e a fonte do jardim aparecem a 2×. As pequenas aves de fundo e as faixas de água ficam como efeitos a conferir em movimento. [Medições do renderizador](medicoes-do-renderizador.csv)

## Contorno

A primeira faixa do contorno dos NPCs está consistente na escala nativa. A diferença aparece principalmente na **segunda faixa de pixels**. Ela está escura em cerca de 90% no repouso de Idhrí, entre 47% e 59% nos três espantalhos e tem mediana de 66% nos NPCs de repouso. A leitura dos espantalhos mostra que o contorno pode ser mais fino em objetos detalhados. O critério para personagem é separar cabelo, rosto, mãos e tecido do fundo em movimento. [Régua visual](03-reguas/regua-contornos.png) · [Medições por quadro](contornos.csv)

Os ajustes mais localizados são a gola e os tecidos claros de Ínys, o manto e o cabelo da Bruxa e as bordas das vestes do Sacerdote, de Halberd, Niobhán e Seyrín. A segunda faixa desses exemplos fica abaixo do restante do elenco. Trata-se de reforçar trechos que perdem leitura em cena, usando as folhas existentes a 2×. No outro extremo, o Aprendiz de Ferreiro tem borda interna escura próxima de Idhrí e uma terceira faixa mais pesada. Vale revisar a separação entre manga e mão em vez de aplicar mais contorno ao corpo todo. A’Maídhe, Pódhraic e os corvos figuram na régua para conferência lado a lado. [Régua visual](03-reguas/regua-contornos.png)

## Ordem de execução

1. Reexportar as galerias, o monumento e o fundo dos Arquivos, e as fachadas e props de Iomadh com fontes confirmadas. Validar a camada nativa em dois mapas antes de reaplicar a integração em outras cidades.
2. Redesenhar as peças dos Guardiões e a folha do Rei Oco, mantendo encaixes e estados. Em paralelo ao lote de arte, medir um conjunto de bordas do terreno por reino para confirmar a leitura de pouso.
3. Aplicar os ajustes de contorno localizados e avançar para os módulos restantes e props sem original maior confirmado.

A densidade informa quantos pixels da fonte entram por unidade lógica no desenho que aparece. O relatório usa chamadas observadas no canvas final e fontes que contribuem para as composições visíveis. Cópias temporárias de análise de alfa ficaram fora. Os 273 identificadores medidos incluem poses, camadas e efeitos. Os casos não visitados de diálogo, transição e combate precisam de conferência ao integrar seus respectivos lotes. [Medições do renderizador](medicoes-do-renderizador.csv)
