# R8 — Reexports de fontes maiores, sem alterarR7

**13candidatos produzidos:6portraits e7animações. Nenhum aplicado ao jogo.** R7/HTML/mapas/repositório permanecem fora deste trabalho. Os três recolors de Seyrín são outro lote, `review-r8-seyrin`, do agente integrador.

## Entrega e decisão visual

- `assets/`:13PNGsnativos. `before/`:comparação com seisportraits ativos e sete candidatos antigos ainda não integrados.
- `sources/`:5folhas originais realmente maiores, copiadas sem alteração. `manifest.json`:fonte/crop/escala/redutor/pivô/célula/chave sugerida/hashes/pendências por arquivo.
- `portraits-artificer-comparison.png`, `portraits-inys-comparison.png`:antes/depois2×nearest; `animations-comparison-1..3.png`:antes/depois2×; seteGIFs mostram os novos ciclos, não demonstram aprovação de movimento.
- `reexport_r8.py`:reproduz os candidatos das fontes existentes. Pillow é a única dependência artística; não houve chamada a geração de imagem/vídeo.

**Preservar os seis portraits ativos de Halberd e Ínys.** A reexportação de fonte maior foi feita, mas não oferece melhora visual inequívoca. Maior redução de cores não é motivo suficiente para substituir artes boas. Os seisPNGsexportados ficam como candidatos rastreáveis, não atualização obrigatória.

As seteanimações são seiswalks (Lúgham,Bruxa,A’Maídhe,Niobhán,Halberd,Seyrín) e umpull de Ínys. ÁreaBOXpremultiplicada, sem dither, alfa binário e uma paleta de64cores por tira preservam o desenho da fonte. A tentativa de usar a paleta40doidle foi descartada nesta revisão: achatava pele, cabelo e peles claras. A paleta final vem das próprias poses e precisa de harmonização visual com os idles atuais antes de qualquer ativação, sobretudo Seyrín.

## Contratos para o próximo Codex

Walks:240×48,6células40×48,140ms porframe, pivô[20,47]. Escala única por personagem; não ajustar cada pose para preencher a célula. Pés foram registrados na última linha47, alinhada aoidle ativo; os candidatos antigos deixavam essa linha vazia. Essa correção de1px está documentada, não deve ser duplicada no runtime.

As chaves sugeridas `exp_*_walk` ainda não existem no seletor ativo. Use somente quando o ator efetivamente se desloca; não substituir os idles/gestos atuais por animação de caminhada parada. É necessário revisar alternância de pernas, contato/pé deslizante, costura de loop, estabilidade da mão/props e transição idle↔walk. Não foi feito playtest dessas animações e nenhuma delas foi ativada.

Ínys:pull240×48,6células40×48,150ms,pivô[20,47], altura de referência28px comoidleR7. O candidato antigo tinha referência25px. Célula e pivô permanecem; a diferença de escala está explícita. Extração usa só a criança do guia, com registro pela mesma âncora de fonte[480,373], compensando o recorte transparente sem cortar membros.

**Carruagem,rodas e boneco permanecem separados.** A tira de Ínys conserva apenas o pequeno fragmento original de corda/borla junto à mão. Não desenhar outra corda completa por cima: conectar ao engate com âncoras porpose revisadas; a âncora do manifest é candidata. Rodas devem responder ao deslocamento e parar emidle. Nenhuma tinta nas mãos, marca nova, mudança de vestido/cabelo/laço ou estado novo do boneco foi criado. Held/play/stop/turn/talk específicos e cores do boneco continuam pendentes.

## O que não foi refeito por rotina

Os13idles/gestos já retrabalhados anteriormente, os14assets preservados na revisão de arquiteturas e os mapasR7 não foram tocados. Mesa/escada/estante não têm fonte maior nova; o limite registrado noR5 continua válido. Fonte denominada master no lote da arquivista tem resolução nativa, não recupera detalhe maior; a arquivista aprovada permanece.

Próximo lote elegível:5folhas reais maiores de militares em `originais_sem_reducao` doLote02, listadas emFILA_E_FONTES.json. Identidade/recortes precisam ser conferidos antes de processar. Não aplicar as15variantes automaticamente ou criar personagens a partir de referências sem autorização.
