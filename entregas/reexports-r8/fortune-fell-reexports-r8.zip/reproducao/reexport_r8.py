"""Existing high-resolution sources only; isolated candidates, no R7 writes."""
from pathlib import Path
from PIL import Image,ImageDraw
from collections import Counter
import re,json,base64,io,hashlib,math
R=Path(__file__).resolve().parent;BASE=R.parent;S=(R/'sources') if (R/'sources').exists() else Path('/workspace/fortune-expansion/assets/generated_sources');LEG=Path('/workspace/fortune-expansion/assets');R.joinpath('assets').mkdir(exist_ok=True);R.joinpath('before').mkdir(exist_ok=True)
base=BASE/'fortune-fell-retrabalho-v2.html';raw=base.read_bytes() if base.exists() else b'';text=raw.decode();match=re.search(r'const ART_PNG\s*=\s*',text);runtime=json.JSONDecoder().raw_decode(text[match.end():])[0] if match else {};baseline_hash=hashlib.sha256(raw).hexdigest() if raw else json.loads((R/'baseline-info.json').read_text())['baseline_html_sha256'];records={};portraits={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(key):return Image.open(io.BytesIO(base64.b64decode(runtime[key].split(',',1)[1]))) .convert('RGBA') if key in runtime else Image.open(R/'before'/f'{key}.png').convert('RGBA')
def cut(im,box):
 c=im.crop(box).convert('RGBA');c.putalpha(c.getchannel('A').point(lambda a:255 if a>=128 else 0));b=c.getbbox();assert b
 return c.crop(b),[box[0]+b[0],box[1]+b[1],box[0]+b[2],box[1]+b[3]]
def rgb_palette(images,limit):
 pixels=[]
 for c in images:
  sm=c.copy();sm.thumbnail((256,256),Image.Resampling.NEAREST);pixels.extend(p[:3] for p in sm.get_flattened_data() if p[3]>=128)
 w=min(512,len(pixels));h=math.ceil(len(pixels)/w);pool=Image.new('RGB',(w,h));pool.putdata(pixels+[pixels[-1]]*(w*h-len(pixels)));return pool.quantize(colors=limit,method=Image.Quantize.MEDIANCUT)
def runtime_palette(name):
 im=old('exp_'+name+'_idle');colors=list(Counter(p[:3] for p in im.get_flattened_data() if p[3]>=128));assert len(colors)<=256
 pal=Image.new('P',(1,1));pal.putpalette([v for c in colors+[colors[0]]*(256-len(colors)) for v in c]);return pal,len(colors)
def reduce(c,size,pal):
 # Premultiplied area sampling avoids dark alpha edges; source colors only.
 sm=c.convert('RGBa').resize(size,Image.Resampling.BOX).convert('RGBA');q=sm.convert('RGB').quantize(palette=pal,dither=Image.Dither.NONE).convert('RGBA');q.putalpha(sm.getchannel('A').point(lambda a:255 if a>=128 else 0));return q

def save(key,im,meta,before):
 path=R/'assets'/f'{key}.png';im.save(path);before.save(R/'before'/f'{key}.png');assert im.size==before.size;assert set(im.getchannel('A').get_flattened_data())<={0,255}
 meta.update(width=im.width,height=im.height,alpha=True,required=False,nativePixels=True,category='portrait' if 'portrait' in key else 'sprite',art_source='existing',sha256=digest(path),baseline_html_sha256=baseline_hash,status='candidate not integrated; review required',no_new_art=True)
 records[key]=meta

for name,file,row,bounds in [('artificer','lote04_portraits_source.png',0,[0,499,1024]),('inys','portrait_expressions_source.png',3,[0,313,628,932,1253,1619])]:
 source=S/file;im=Image.open(source).convert('RGBA');crops=[];boxes=[]
 for i in range(3):
  c,b=cut(im,(round(i*im.width/3),bounds[row],round((i+1)*im.width/3),bounds[row+1]));crops.append(c);boxes.append(b)
 scale=min(124/max(c.width for c in crops),124/max(c.height for c in crops));pal=rgb_palette(crops,256)
 for i,label in enumerate(['neutral','listening','reaction']):
  key=f'exp_portrait_{name}_{label}';c=crops[i];size=(round(c.width*scale),round(c.height*scale));out=Image.new('RGBA',(128,128));out.alpha_composite(reduce(c,size,pal),((128-size[0])//2,128-size[1]));save(key,out,dict(target_key=key,runtime_key_exists=True,source=str(source),source_sha256=digest(source),source_dimensions=list(im.size),source_region=boxes[i],source_visible_dimensions=list(c.size),shared_character_scale=scale,character=name,expression=label,pivot=[64,127],palette='one256-color source palette shared across expressions',resampler='premultiplied BOX/no dither/binary alpha',primary_requested=name in ['artificer','inys']),old(key));portraits.setdefault(name,[]).append(key)

anim_jobs=[]
im=Image.open(S/'four_adults_walk_source.png').convert('RGBA')
for row,name in enumerate(['king','hag','governor','queen']):anim_jobs.append((name,S/'four_adults_walk_source.png',(row*256,(row+1)*256),39))
for name,top,bottom,target in [('artificer',0,325,30),('oracle',325,724,39)]:anim_jobs.append((name,S/'lote04_walks_source.png',(top,bottom),target))
animation_keys=[]
for name,source,(top,bottom),target in anim_jobs:
 im=Image.open(source).convert('RGBA');cells=[];regions=[]
 for i in range(6):
  c,b=cut(im,(round(i*im.width/6),top,round((i+1)*im.width/6),bottom));cells.append(c);regions.append(b)
 scale=target/cells[0].height;pal=rgb_palette(cells,64);colors=64;sheet=Image.new('RGBA',(240,48));frames=[]
 for i,c in enumerate(cells):
  w,h=round(c.width*scale),round(c.height*scale);assert w<=40 and h<=47,(name,i,w,h)
  f=Image.new('RGBA',(40,48));f.alpha_composite(reduce(c,(w,h),pal),((40-w)//2,48-h));sheet.alpha_composite(f,(i*40,0));frames.append(f)
 key=f'candidate_{name}_walk';bp=LEG/'walk_candidates'/f'{name}_walk_candidate.png';before=Image.open(bp if bp.exists() else R/'before'/f'{key}.png').convert('RGBA');save(key,sheet,dict(target_key=f'exp_{name}_walk',runtime_key_exists=f'exp_{name}_walk' in runtime,source=str(source),source_sha256=digest(source),source_dimensions=list(im.size),source_regions=regions,source_visible_dimensions=[list(c.size) for c in cells],shared_scale=scale,cell=[40,48],frames=6,frame_order=list(range(6)),pivot=[20,47],visible_height_reference=target,duration_ms=140,palette='one64-color source palette shared across six frames; current idle palette reviewed as an alternate and rejected because it flattened fur/hair and skin',resampler='premultiplied BOX/no dither/binary alpha',anchor_note='Feet aligned to active R7 idle last pixel row47; legacy walk used bottom boundary47 leaving last row blank. No per-frame scale adjustment.',pending_checks=['Near/far leg alternation','Contact-foot sliding','Loop seam','Prop hand attachment','Body/head consistency with active idle']),before)
 frames[0].save(R/f'{key}.gif',save_all=True,append_images=frames[1:],duration=140,loop=0,disposal=2);animation_keys.append(key)

source=S/'lote04_inys_pull_guide_source.png';im=Image.open(source).convert('RGBA');cw,ch=im.width/3,im.height/2;regions=[];cells=[]
for i in range(6):
 gx,gy=round(i%3*cw),round(i//3*ch);box=[gx+378,gy+100,min(gx+590,im.width),min(gy+420,im.height)];c=im.crop(box);c.putalpha(c.getchannel('A').point(lambda a:255 if a>=128 else 0));cells.append(c);regions.append(box)
b=cells[0].getbbox();scale=28/(b[3]-b[1]);pal=rgb_palette(cells,64);colors=64;sheet=Image.new('RGBA',(240,48));frames=[]
for i,c in enumerate(cells):
 bb=c.getbbox();c=c.crop(bb);w,h=round(c.width*scale),round(c.height*scale);sm=reduce(c,(w,h),pal);xy=(round(20-(480-378-bb[0])*scale),round(47-(373-100-bb[1])*scale));f=Image.new('RGBA',(40,48));assert xy[0]>=0 and xy[1]>=0 and xy[0]+w<=40 and xy[1]+h<=48,(w,h,xy);f.alpha_composite(sm,xy);frames.append(f);sheet.alpha_composite(f,(i*40,0))
key='candidate_inys_pull';bp=LEG/'action_candidates/inys_pull_candidate.png';before=Image.open(bp if bp.exists() else R/'before'/f'{key}.png').convert('RGBA');save(key,sheet,dict(target_key='exp_inys_pull',runtime_key_exists='exp_inys_pull' in runtime,source=str(source),source_sha256=digest(source),source_dimensions=list(im.size),source_regions=regions,source_crop_each_cell=[378,100,590,420],source_anchor=[480,373],shared_scale=scale,cell=[40,48],frames=6,pivot=[20,47],duration_ms=150,visible_height_reference=28,legacy_visible_height_reference=25,scale_note='Display scale updated from pending25px to active R7 idle28px; cell/pivot unchanged. Candidate only.',palette='one64-color source palette shared across six pulling poses; keep green/gold and white hair from approved source',resampler='premultiplied BOX/no dither/binary alpha',cord_join_anchor_candidate=[round(20-(480-378)*scale),round(47-(373-292)*scale)],carriage_and_doll='Separate runtime props; not baked into this body strip. Approved composite source remains reference only.',identity_locks=['No paint on hands','No added markings','Same dress/hair/bow','Short original cord/tassel remains attached to hand'],pending_checks=['Cord-to-hand/hitch seam','Support feet and loop','Carriage wheel synchronization','Held/play/stop/turn/talk states still absent']),before)
frames[0].save(R/f'{key}.gif',save_all=True,append_images=frames[1:],duration=150,loop=0,disposal=2);animation_keys.append(key)

for name,keys in portraits.items():
 sheet=Image.new('RGBA',(552,3*284),'#352a52');d=ImageDraw.Draw(sheet)
 for i,key in enumerate(keys):
  d.text((8,i*284+2),key+' BEFORE / CANDIDATE',fill='white');o=Image.open(R/'before'/f'{key}.png').convert('RGBA');n=Image.open(R/'assets'/f'{key}.png').convert('RGBA');sheet.alpha_composite(o.resize((256,256),Image.Resampling.NEAREST),(8,i*284+24));sheet.alpha_composite(n.resize((256,256),Image.Resampling.NEAREST),(280,i*284+24))
 sheet.save(R/f'portraits-{name}-comparison.png')
for batch in range(math.ceil(len(animation_keys)/3)):
 subset=animation_keys[batch*3:(batch+1)*3];sheet=Image.new('RGBA',(1000,len(subset)*124),'#352a52');d=ImageDraw.Draw(sheet)
 for i,key in enumerate(subset):
  d.text((8,i*124+2),key+' BEFORE / CANDIDATE',fill='white');o=Image.open(R/'before'/f'{key}.png').convert('RGBA');n=Image.open(R/'assets'/f'{key}.png').convert('RGBA');sheet.alpha_composite(o.resize((480,96),Image.Resampling.NEAREST),(8,i*124+22));sheet.alpha_composite(n.resize((480,96),Image.Resampling.NEAREST),(512,i*124+22))
 sheet.save(R/f'animations-comparison-{batch+1}.png')
(R/'manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print('isolated candidates:',len(records),'portrait',sum('portrait' in k for k in records),'animations',len(animation_keys))
assert not base.exists() or base.read_bytes()==raw,'R7 modified externally during export; rerun audit before integration'

# Record conservative visual selection: never replace active assets automatically.
for key,record in records.items():
 record.update(source_original=record['source'],source='sources/'+Path(record['source']).name,output='assets/'+key+'.png',before='before/'+key+'.png',render_review='preserve_active_portrait' if 'portrait' in key else 'motion_candidate_only',apply_automatically=False,review_reason='Active portraits remain preserved; animations need gait/feet/runtime review before activation. No HTML or map edited.')
(R/'manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
