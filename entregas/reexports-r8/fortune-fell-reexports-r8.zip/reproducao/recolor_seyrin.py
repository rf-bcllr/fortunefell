from pathlib import Path
from PIL import Image,ImageDraw
from collections import Counter
import colorsys,json,hashlib
D=Path(__file__).resolve().parent;R=D.parent
ref=Image.open(R/'before/royal_gilead.png').convert('RGBA')
def hsv(p):return colorsys.rgb_to_hsv(*(v/255 for v in p[:3]))
def lum(p):return .2126*p[0]+.7152*p[1]+.0722*p[2]
counts=Counter(p[:3] for p in ref.getdata() if p[3]==255)
family=[c for c,n in counts.items() if n>=10 and .72<=hsv(c)[0]<=.99 and hsv(c)[1]<.5 and hsv(c)[2]>.25]
manifest={};review=Image.new('RGBA',(808,834),'#30243c');draw=ImageDraw.Draw(review)
for row,name in enumerate(['neutral','listening','reaction']):
 key='exp_portrait_oracle_'+name;im=Image.open(D/f'{key}-before.png').convert('RGBA');out=im.copy();pixels=[];changed=0
 for i,p in enumerate(im.getdata()):
  x,y=i%128,i//128;h,s,v=hsv(p)
  # Saturated cloth only. Exclude lower face/lips and pale hair entirely.
  cloth=((y<60) or (y<85 and x<31) or (y<67 and x>100) or (x<27 and y>=100))
  if p[3] and cloth and .70<=h<=.96 and s>=.35 and v>=.25:
   t=min(family,key=lambda c:abs(lum(c)-lum(p)));ratio=lum(p)/max(1,lum(t));t=tuple(min(255,round(c*ratio)) for c in t);q=tuple(round(c*.45+a*.55) for c,a in zip(p[:3],t))+(p[3],)
  else:q=p
  changed+=q!=p;pixels.append(q)
 out.putdata(pixels);assert out.getchannel('A').tobytes()==im.getchannel('A').tobytes();out.save(D/f'{key}.png')
 manifest[key]={'width':128,'height':128,'alpha':True,'nativePixels':True,'category':'portrait','changed_pixels':changed,'reference':'Same royal_gilead palette and 55% luminance-matched blend used by R7 oracle sprite','scope':'Selective saturated cloth only; face/lips, gold, ivory hair and alpha preserved','source':'R7 embedded portrait, unchanged geometry/expressions','sha256':hashlib.sha256((D/f'{key}.png').read_bytes()).hexdigest(),'status':'candidate; not integrated into R7'}
 for col,(label,img) in enumerate([('Antes',im),('Gilead',out)]):
  draw.text((col*268+4,row*278+3),name+' / '+label,fill='white');review.alpha_composite(img.resize((256,256),Image.Resampling.NEAREST),(col*268+4,row*278+19))
 sprite=Image.open(R/'assets-paleta/exp_oracle_idle.png').convert('RGBA').crop((0,0,40,48));review.alpha_composite(sprite.resize((160,192),Image.Resampling.NEAREST),(550,row*278+40));draw.text((550,row*278+19),'Sprite R7',fill='white')
review.save(D/'seyrin-comparison.png');(D/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print({k:v['changed_pixels'] for k,v in manifest.items()})
