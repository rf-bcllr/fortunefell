"""Apply only the three Seyrin portrait recolors to a separate copy of R7."""
import argparse,base64,hashlib,json,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('entrada',type=Path);p.add_argument('saida',type=Path);a=p.parse_args()
assert a.entrada.resolve()!=a.saida.resolve(),'Use a separate output; preserve the tested R7.'
raw=a.entrada.read_bytes();assert hashlib.sha256(raw).hexdigest()=='9e5768e126a8aed1a5c1efe93caef491c9779be34081c9127d74587c5f93350c','Expected exact approved R7 baseline'
s=raw.decode();m=re.search(r'const ART_PNG\s*=\s*',s);assets,end=json.JSONDecoder().raw_decode(s[m.end():]);before=assets.copy();root=Path(__file__).resolve().parent
for name in ['neutral','listening','reaction']:
 key='exp_portrait_oracle_'+name;assert key in assets;assets[key]='data:image/png;base64,'+base64.b64encode((root/'assets'/f'{key}.png').read_bytes()).decode()
assert sum(v!=before[k] for k,v in assets.items())==3
out=s[:m.end()]+json.dumps(assets,ensure_ascii=False,separators=(',',':'))+s[m.end()+end:]
a.saida.write_text(out);print(hashlib.sha256(out.encode()).hexdigest())
