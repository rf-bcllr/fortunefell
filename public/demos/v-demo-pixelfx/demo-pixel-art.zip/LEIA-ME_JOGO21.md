# Jogo 21: revisão

Código novo:
- `src/99_zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz_arcana_c_story.js`: história, objetivos, Tesouro, encerramento, título, capítulos e layout do HUD.
- `src/99_zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz_arcana_d_world.js`: ajustes de mapa e água.

Também foram editados:
- `85_lugham_consultation.js`: balança e Bruxa.
- `99_…arcana_b_ui.js`: pedido de Halberd.
- `70_main.js`: câmera do rio.

Para gerar o jogo: `node tools/build.mjs`.

| # | Pedido | O que foi feito |
|---|---|---|
| 1 | Final | A tela de título deu lugar a um encerramento próprio. Ao fundo, o arquipélago já sem Éhrein. Três cartas entram uma a uma: a primeira ponte, o povo de Éhrein (evacuar ou ficar, dizendo se Idhrí seguiu ou contrariou a Oráculo ou a Bruxa) e Llewlás. Tempo, ouro, Tesouro e derrotas ficam no cabeçalho, com “Jogar novamente” e “Voltar ao título” embaixo. Sem logo. |
| 2 | Tesouro Real | Fichas −10 −5 −1 +1 +5 +10, “Todo o ouro”, “Depositar N” e “Fechar o cofre”. O painel mostra ao vivo o ouro de Idhrí, o depósito e o Tesouro. Um mostrador “Tesouro” aparece ao lado do ouro no cofre, na chancelaria e perto de Pódhraic. Os dois mostradores atualizam a cada quadro, também com menus abertos (oficina inclusive). |
| 3 | Muro do Santuário de Gileád | O muro é a porta de contrapeso, que vai do chão ao teto do corredor; nenhuma plataforma passa por cima dela. Um trinco oculto ao lado dela, revelado pela Percepção, prende a porta aberta para quem vem pela estante. |
| 4 | Objetivos | Novos objetivos: “Encontre Pódhraic no rio da Mata Alta…”, “Consulte a Oráculo de Gileád” ou “Procure a Velha Bruxa”, “Volte à corte de Éhrein…” e “Aconselhe Lúgham…”. Idhrí comenta Pódhraic na primeira entrada da Mata Alta e repete a fala se tentar entrar no Santuário de Iomadh antes de achá-lo. |
| 5 | Pódhraic em Iomadh | Mercador Dvernara (ferramentas de Airgeád), criança, Morghara, guarda do portão, conselheiro Dvernara e sacerdote comentam a passagem dele, uma vez cada, enquanto ele não é encontrado. O sacerdote ganhou falas por lugar e um ciclo de quatro falas nas visitas seguintes. |
| 6 | Mercadora Aelvara | Fala sobre o cabelo de Idhrí depois do segundo anel, uma vez, com o seu texto. |
| 7 | Besouro nas copas | A patrulha passou a aceitar galhos de mão única como chão; o besouro não fica mais tremendo no lugar. |
| 8 | Posições | Niobhán à frente do trono e Seyrín atrás dele, ambas voltadas para a corte. Sacerdote no meio do espaço entre a segunda casa e a subida para o Conselho. |
| 9 | Topos cortados | O corte está na própria arte (`royal_gilead`, `royal_ehrein`). Pedido em `PEDIDO_DE_ARTE_CHATGPT.md`. |
| 10 | Santuário de Gileád | Já é desenhado sem ampliação; precisa de master melhor. Pedido em `PEDIDO_DE_ARTE_CHATGPT.md`. |
| 11 | Pedido de Halberd | Agora conta para Myriadd. |
| 12 | Balança | Só repousa depois da resposta de Lúgham, para o aviso não ficar sob a caixa de diálogo. |
| 13 | Saída da corte de Éhrein | Se Idhrí ainda não aconselhou Lúgham, pergunta antes de sair: “Voltar e falar com Lúgham” ou “Sair mesmo assim”. |
| 14 | Bruxa | Diz “a Oráculo de Gileád” em vez de Seyrín. Idhrí repete do mesmo jeito. |
| 15 | Éhrein | O mensageiro fala da mulher de Gileád que vive na clareira da Charneca e a curandeira dos boatos do Rei Oco, no lugar de duas falas soltas. |
| 16 | Água do rio | A faixa da frente do Rio da Mata Alta virou água que reflete a cena, com ondulação, linha d’água e brilhos. Longe do moinho, a câmera desce um pouco para a água aparecer. |

## Telas e layout

- **Título:** logo ao centro e as opções em leque de cartas verticais logo abaixo. Saiu a carta com o retrato.
- **Capítulos:** quatro colunas, uma por reino, com emblema e cor; logo escondido.
- **Layout do HUD:**
  - vida e objetivo em cima à esquerda;
  - ouro, Tesouro e modo assistido em cima à direita;
  - roda dos anéis embaixo à esquerda;
  - cartinhas de aprovação embaixo à direita.
- **Peças do HUD:** ficam translúcidas quando Idhrí passa por trás delas.
- **Sem carta dentro de carta:** a arte de cada opção virou um medalhão redondo.
- **Véu:** menus abertos durante o jogo ganham um véu suave para o texto não brigar com o cenário.

## Detalhes de mundo (aprovados pelo autor)

- Pódhraic comprou uma faca de bolso, deu uma moeda à criança para mostrar a trilha, bebeu do balde de Morghara, assistiu ao fundo da sessão do Conselho e foi abençoado pelo sacerdote.
- Falas novas do sacerdote: as preces em Éhrein, Gileád e Iomadh, e o ciclo de quatro falas.
- A mulher de Gileád chegou “há muitos invernos” e os pastores levam leite a ela.
- Os pastores viram o Rei Oco riscando as pedras com a lança.

## Rodada 2 (cartas, água e técnicas da SpriteCook)

- **Cartas mais limpas:**
  - Um só filete dourado por carta, sem a moldura interna.
  - Saíram o losango do canto e a constelação, que só ficou nas cartas do encerramento.
  - Os ícones ficaram soltos, sem círculo.
  - No título, os ícones são grandes, sobre o nome.
- **Água do Rio da Mata Alta:**
  - Usa só os tons da água que o mapa já tinha.
  - O reflexo é achatado a 55% e convertido em tons da paleta.
  - A ondulação desloca linhas inteiras: 0 px nas 3 primeiras linhas, 1 px até a 30ª e 2 px depois.
  - Tem anéis de 5 quadros, brilhos curtos e cristas na linha d’água.
  - Em volta de Idhrí, a água abre num dither Bayer 4×4 (raio 18, suavidade 16), e ele aparece ao pegar o baú da cachoeira.
- **Vida no rio:** peixes saltam a cada 3 a 6 segundos, com anéis na entrada e na saída. Três libélulas pairam sobre a água e fogem quando Idhrí chega perto. São pixels na paleta da água e podem virar sprites do ChatGPT depois.
- **Perspectiva atmosférica:** as camadas `mid` e `near` de cada reino misturam a cor média do céu na mesma linha, com mais névoa na camada distante (`mid` 0,26 + 0,16 para a base; `near` 0,07). É calculada uma vez por imagem.
- **Escala pixel-perfect:** a maior escala inteira passa a ser calculada em pixels físicos, considerando o zoom do sistema (125%, 150%).
- **Filtro CRT:** opcional, desligado por padrão, liga na pausa. Versão leve em CSS, com linhas de varredura, máscara RGB e vinheta.
- **Nobre dos jardins:** o retrato usa a arte do nobre loiro de casaco verde (`portrait_courtierB`), igual ao sprite.

### Fica para depois

- **Vento nas árvores:** a técnica pede cada copa separada em tufos, um sprite por tufo. Isso se faz no master da árvore, com o script do artigo ou um corte manual, e não no PNG final. Dá para pedir ao ChatGPT as árvores principais já separadas.
- **Normal maps e luz:** daria para gerar no navegador, mas mudaria o acabamento de toda a arte, que hoje tem sombra pintada à mão. Melhor testar primeiro numa cena só, como o santuário à luz de tochas, antes de aplicar no jogo todo.

## Rodada 3: bloom e gradação de cor

Inspirado no `WorldEnvironment` do template HD-2D da Meowa. O recurso é do Godot e não pode ser copiado, mas seus valores serviram de partida.

- **Bloom:**
  - Os pixels claros (ouro, tochas, cachoeira, arco de luz) vão para uma cópia 4× menor, onde os escuros são cortados.
  - A cópia é desfocada e somada por cima com “screen”, que não escurece nada.
  - Roda na placa de vídeo, com os filtros nativos do canvas, e é recalculado a cada 2 quadros.
- **Gradação:**
  - Contraste e saturação entre 1,02 e 1,06 por reino; o template usa 1,16, forte demais para esta arte.
  - Um véu de cor em “soft light” com opacidade baixa (lilás em Gileád, âmbar em Iomadh).
- **Onde está ligado:** em todos os mapas, aprovado depois do teste. Na pausa, “Brilho e cor” liga e desliga.
- **Ficou de fora:**
  - Tonemap filmic, que quase não muda arte sem HDR.
  - Luz ambiente lilás, que depende de iluminação 3D.

## Desempenho

A água da rodada 2 lia a imagem da placa de vídeo para o processador a cada quadro e custava ~24 ms; o bloom na primeira versão, também. As duas partes foram reescritas para rodar só na placa de vídeo, com o reflexo copiado em faixas, a paleta aplicada por composição e o dither como máscara pré-calculada.

Medido no navegador, em ms por quadro:

| Mapa | Antes | Agora | Limite para 60 fps |
|---|---|---|---|
| Rio da Mata Alta | ~24 | ~7 | 16 |
| Santuário de Gileád com bloom | ~23 | ~3–5 | 16 |
