# Fortune Fell • Auditoria de sprites para a próxima produção

**Escopo.** Base de personagens publicada na versão 69, lida na cópia de trabalho da revisão de interface. A prioridade é reconstruir o movimento de Llewlás e calibrar o elenco com os sprites efetivamente desenhados pela demo. Esta auditoria preserva as fichas de design aprovadas.

## O que foi medido

No Chromium, após o carregamento da arte e a instalação final dos renderizadores, capturei as imagens retornadas por cada renderizador de ator, a lista de entidades por mapa e os recursos decodificados. Para cada quadro medi a caixa do conteúdo com alfa ≥128, em pixels lógicos, antes da ampliação da tela. Armas, coroas, chapéus e capas entram nessa medida. Ela não substitui a altura anatômica dos pés ao crânio.

| Cobertura | Resultado |
|---|---|
| Recursos decodificados | 590, zero falhas de carregamento na sessão |
| NPCs e figurantes | 91 aparências, oito amostras por aparência; 64 têm colocação direta por aparência, 27 constam no catálogo sem colocação direta identificada |
| Idhrí | Cinco variantes de cabelo/ordem dos anéis, doze poses por variante |
| Llewlás | Nove quadros, incluindo o desenho alternativo sem a lança |
| Inimigos | Onze tipos, dois quadros base por tipo |
| Guardiões | Gileád, Iomadh e Éhrein, registrados separadamente por serem compostos por partes |
| Total | 819 amostras individuais de personagens, além do inventário de recursos |

**Arquivos.** AUDITORIA-ATORES.csv lista um personagem ou aparência por linha, com identificador, mapa, medida e ação recomendada. AUDITORIA-QUADROS.csv contém medidas e âncoras por estado amostrado. AUDITORIA-ASSETS.csv identifica cada recurso efetivamente carregado, tamanho, origem detectada e a precedência dos pacotes. AUDITORIA-ATORES.png serve para localizar aparências pelo nome; alguns atores grandes foram reduzidos para caber na célula. AUDITORIA-LLEWLAS.png usa escala única em todas as poses, com a mesma linha de chão.

## P0 — Llewlás

Em repouso, Idhrí ocupa **22 × 39 px**. Llewlás ocupa **27 × 46 px com lança**, ou **20 × 41 px sem lança**. O quadro em pé com a lança tem 18% mais altura de silhueta que Idhrí. A prancha também revela rosto menos legível, corpo com massas de cor diferentes e discrepância de tamanho entre as duas versões do próprio príncipe. O jogador vê essas diferenças em sequência no mesmo plano.

| Quadro | Uso atual | Silhueta |
|---|---|---|
| 0 | Repouso com lança | 27 × 46 |
| 1 | Examinar rastros | 35 × 43 |
| 2 e 3 | Passadas | 32 × 44 e 31 × 44 |
| 4 | Corrida | 45 × 40 |
| 5 | Salto em toda a trajetória | 43 × 34 |
| 6 | Estocada | 53 × 36 |
| 7 | Reação a contato | 39 × 39 |
| 8 | Durante o voo da lança | 20 × 41 |

**Causas concretas na arte e no código.**

1. A pose 8 tem três pixels transparentes sob os pés. As demais chegam à última linha da célula. A troca desloca o apoio, e a pose usa outra fonte gráfica. Redesenhar preparo, soltura e recuperação como poses do mesmo corpo e recusar deriva involuntária da linha dos pés.
2. A corrida rápida alterna a pose 4 com uma passada de caminhada (pose 2). Os quadros 2 e 3, vistos lado a lado, apresentam apoio e contorno de pernas muito semelhantes. Isso gera deslizamento visual. Desenhar contatos opostos e intercalar passagem/impulsão, sincronizados com deslocamento no mundo.
3. A lógica de estocada observa apenas o intervalo do contador de recarga. O contador do arremesso também atravessa esse intervalo e pode disparar uma estocada visual tardia sem novo ataque. Separar a ação em curso da recarga, usar quadro de contato para aplicar o golpe e encerrar a ação antes de retomar a locomoção.
4. Há uma única pose aérea, usada na subida e na queda. Pouso, partida, preparo da lança, arremesso e recuperação não possuem transições desenhadas correspondentes. Usar as fases reais de velocidade vertical e contato com o solo para dirigir as poses.
5. O companheiro pode ser reposicionado na coordenada do jogador depois de uma queda ou grande separação, assim que Idhrí toca o chão. Esse reposicionamento também pode parecer um salto de animação. Testar separadamente perseguição, retorno e resgate no terreno.
6. As massas de cabelo, ombreira, braço, capa e lança precisam continuar reconhecíveis na resolução nativa. Usar as pranchas aprovadas para manter o rabo de cavalo louro, ombreira de leão, chifre de caça, torre dourada e azul de Éhrein.

## Ordem de trabalho sugerida para o outro Codex

1. **Idhrí como controle.** Revisar rosto, mãos, linha dos olhos, sola, largura dos ombros e o contato do pé nos quadros idle0/idle1/run0–3. O repouso é estável, e as poses correndo têm 37–39 px. Só abrir um redesenho do herói se a avaliação visual revelar um defeito próprio. Caso seja necessário, reconstruir as cinco variantes a partir do mesmo corpo mestre, mantendo a leitura dos anéis.
2. **Llewlás.** Escolher uma altura corporal usando Idhrí ao lado, pés no mesmo chão e lança em camada de conferência separada. Primeiro aprovar repouso, uma passada e estocada a 1×. Só então propagar o corpo para todas as ações. Comparar em jogo antes de publicar, com e sem lança.
3. **Revisar os novos individualmente.** Llúpin em Éhrein mede 43–44 px. Compará-lo com o irmão e Idhrí antes de alterar a relação entre os três. Ínys mede 30 px; as crianças de Iomadh e do palácio medem 29–30 px, portanto a altura por si só não justifica alteração. Halberd mede 30 px; manter a leitura de adulto Dvern, braços e tórax robustos. Conferir a Bruxa curvada (35 px), o volume do cabelo e a rede. Conferir também A’Maídhe (36–37), Lúgham (37–38), Niobhán (38), Seyrín, Sacerdote, Pódhraic e Arquivista. A guardiã aprovada usa a aparência vaultkeeper_new (38 px); a chave vaultkeeper solta corresponde a outra imagem.
4. **NPCs de fundo e guardas.** Processar cada linha restante por reino e mapa. Conferir o povo e a idade antes de escolher o corpo de referência. Quando um recurso aparece sem colocação direta, pesquisar interação, cinemática, troca de identidade e fallback antes de gastar produção nele. Uma aparição no catálogo não prova que o jogador o encontra.
5. **Inimigos e chefes.** Revisar inimigos com suas caixas e sinais de ataque. O Hollow é deliberadamente maior que um humano; o renderizador inclui ações contextuais além dos dois quadros base. Conferir guardiões na arena, com rodas, máscaras, placas, hitboxes e telegráficos montados. A altura de uma peça individual não mede a altura do chefe.

## Como conferir cada entrega

Comparar o repouso lado a lado com um ator de mesma faixa etária/espécie e com Idhrí. Registrar altura do corpo sem adereços e coordenadas da sola, dos olhos e da mão que segura a arma. Guardar a folha original integral e a exportação de jogo; alinhar pivôs antes da redução. Verificar cada transição nos dois sentidos, em terreno plano e plataformas, incluindo diálogo, mudança de mapa e retorno. Para Llewlás, testar desnível, corrida longa, estocada, arremesso sem lança duplicada e retorno ao grupo.

**Limites.** Os dados dos NPCs são amostras temporais do renderizador final, não uma gravação de todas as interações de cada indivíduo. Efeitos contextuais, roupas por luz, partículas, douramento em combate, sprites montados por código, cavalete da oficina e entidades adicionadas em tempo de execução podem exigir inspeção em cena. A planilha de recursos inclui retratos e cenários para rastreamento; as conclusões de proporção são sobre personagens. Um segundo artista deve julgar anatomia e fidelidade das expressões contra a ficha aprovada.

### Alterações posteriores à medição (v70)
Os inventários e pranchas acima registram a v69 para referência de produção. Na v70, Llewlás recebeu oito quadros novos em llewlas_stride, escala de repouso reduzida, alinhamento dos pés no arremesso e separação entre recarga e estocada. A reprodução do problema de conversa foi feita a 29 px de distância no mesmo chão: na v69 a patrulha se afastava; na correção ele para, oferece interação e responde à tecla E antes e depois de aceitar o convite. Reavaliar as proporções na versão 70 antes de redesenhar.
